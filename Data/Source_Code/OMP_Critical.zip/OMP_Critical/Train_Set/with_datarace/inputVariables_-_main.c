int gi = 0;
static int m = 1;
double mm[117];
double mm2[117];
#pragma omp threadprivate(m,mm);
int main(void)
{
  int i = 0;
  int cont;
  int nthreads = 0;
  int tid;
  float arreglo[6];
  omp_set_nested(1);
  #pragma omp parrallel
  {
    #pragma omp sections
    {
      #pragma omp section
      {
        #pragma omp critical
        {
          #pragma omp parallel num_threads(4) shared(cont, nthreads, tid)
          {
            nthreads = omp_get_num_threads();
            printf("NT: %d\n", nthreads);
            tid = omp_get_thread_num();
            printf("Num t: %d\n", tid);
            printf("i = %d\n", i);
            #pragma omp atomic
            cont++;
          }
        }
      }
      #pragma omp section
      {
        #pragma omp parallel num_threads(6) shared(i, arreglo, tid, nthreads)
        {
          tid = omp_get_thread_num();
          nthreads = omp_get_num_threads();
          arreglo[tid] = rand_r(&tid) % 100;
        }
        float temp = 0;
        float prom = 1;
        for (i = 0; i < 6; i++)
        {
          printf("Pos %d valor = %f\n", i, arreglo[i]);
          temp += arreglo[i];
          prom = temp / 6;
        }

        printf("Promedio: %f\nSumatiora: %f\n", prom, temp);
        printf("Iteraciones: %d\n", nthreads);
      }
    }
  }

  int i;
  int k_3;
  int gj = 0;
  int j = 5;
  mm[0] = 9.0;
  k_3 = 7 + mm[0];
  #pragma omp parallel private (i) firstprivate(k_3) reduction(+:gi,gj) copyin(mm)
  {
    int k = 1;
    printf("Hello,world!\n");
    gi = ((i + j) + k) + k_3;
    gi += i;
    #pragma omp atomic
    j++;
    gj += m + mm[1];
    foo(mm - 1);
    foo(mm2 - 1);
  }
  printf("gi is %d,gj is %d\n", gi, gj);
  return 0;
}

