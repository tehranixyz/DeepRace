double maxeps = 0.1e-7;
int itmax = 100;
int i;
int j;
int k;
double eps;
double A[225][225][225];
void relax();
void init();
void verify();
void relax()
{
  for (i = 1; i <= (225 - 2); i++)
    #pragma omp parallel for private(j, k)

  for (j = 1; j <= (225 - 2); j++)
    for (k = 1; k <= (225 - 2); k++)
  {
    A[i][j][k] = (A[i - 1][j][k] + A[i + 1][j][k]) / 2.;
  }


  for (j = 1; j <= (225 - 2); j++)
    #pragma omp parallel for private(i, k)

  for (i = 1; i <= (225 - 2); i++)
    for (k = 1; k <= (225 - 2); k++)
  {
    A[i][j][k] = (A[i][j - 1][k] + A[i][j + 1][k]) / 2.;
  }


  for (k = 1; k <= (225 - 2); k++)
    #pragma omp parallel for private(i, j)

  for (i = 1; i <= (225 - 2); i++)
    for (j = 1; j <= (225 - 2); j++)
  {
    double e;
    e = A[i][j][k];
    A[i][j][k] = (A[i][j][k - 1] + A[i][j][k + 1]) / 2.;
    e = fabs(e - A[i][j][k]);
    if (eps < e)
    {
      eps = e;
    }

  }


}

