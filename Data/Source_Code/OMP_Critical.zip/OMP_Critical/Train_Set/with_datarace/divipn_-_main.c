int main()
{
  int c;
  int n;
  int vc[10];
  int vn[10];
  int i;
  int ini;
  int inc;
  int k;
  for (i = 0; i < 10; i++)
  {
    vc[i] = 0;
    vn[i] = 0;
  }

  double k = omp_get_wtime();
  int tn = omp_get_thread_num();
  #pragma omp parallel for private(c, i, ini, inc, n) schedule(runtime)
  for (n = 1; n <= 100000; n++)
  {
    c = 1;
    if ((n % 2) == 0)
    {
      ini = 2;
      inc = 1;
    }
    else
    {
      ini = 3;
      inc = 2;
    }

    for (i = ini; i <= n; i += inc)
    {
      if ((n % i) == 0)
        c++;

    }

    if ((c > vc[10 - 1]) || ((c == vc[10 - 1]) && (n < vn[10 - 1])))
    {
      if ((c > vc[10 - 1]) || ((c == vc[10 - 1]) && (n < vn[10 - 1])))
      {
        for (i = 10 - 1; (i > 0) && ((c > vc[i - 1]) || ((c == vc[i - 1]) && (n < vn[i - 1]))); i--)
        {
          vc[i] = vc[i - 1];
          vn[i] = vn[i - 1];
        }

        vc[i] = c;
        vn[i] = n;
      }

    }

  }

  k = omp_get_wtime() - k;
  printf("Los %d enteros con más divisores hasta %d son:\n", 10, 100000);
  for (l = 0; l < 10; l++)
  {
    printf(" %d, con %d divisores\n", vn[l], vc[l]);
  }

  #pragma omp parallel
  int nt = omp_get_num_threads();
  printf("Time: %.2f seconds\n Number of Threads: %d\n", k, nt);
  return 0;
}

