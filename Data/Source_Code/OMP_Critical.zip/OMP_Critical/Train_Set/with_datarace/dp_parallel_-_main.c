int n;
int p;
double **adjacencyMatrix;
double **dp;
int startVertex;
int startVertexBitMask;
double globalMinCost = 1e18;
int main(int argc, char *argv[])
{
  struct timespec start_e2e;
  struct timespec end_e2e;
  struct timespec start_alg;
  struct timespec end_alg;
  struct timespec e2e;
  struct timespec alg;
  clock_gettime(CLOCK_MONOTONIC, &start_e2e);
  if (argc < 3)
  {
    printf("Usage: %s n p \n", argv[0]);
    return -1;
  }

  n = atoi(argv[1]);
  p = atoi(argv[2]);
  int i;
  int j;
  adjacencyMatrix = malloc(n * (sizeof(double *)));
  dp = malloc(n * (sizeof(double *)));
  int secondDimension = 1 << n;
  for (i = 0; i < n; i++)
  {
    adjacencyMatrix[i] = malloc(n * (sizeof(double)));
    dp[i] = malloc(secondDimension * (sizeof(double)));
    for (j = 0; j < n; j++)
      scanf("%lf", &adjacencyMatrix[i][j]);

  }

  for (i = 0; i < n; i++)
    for (j = 0; j < secondDimension; j++)
    dp[i][j] = -1;


  startVertex = 0;
  startVertexBitMask = 1 << startVertex;
  char *problem_name = "travelling_salesman_problem";
  char *approach_name = "dp";
  char outputFileName[50];
  sprintf(outputFileName, "output/%s_%s_%s_%s_output.txt", problem_name, approach_name, argv[1], argv[2]);
  clock_gettime(CLOCK_MONOTONIC, &start_alg);
  double start_time = omp_get_wtime();
  #pragma omp parallel private(i) num_threads(p)
  {
    int id = omp_get_thread_num();
    double minAns = 1e18;
    for (i = id; i < n; i += p)
    {
      if ((i != startVertex) && ((startVertexBitMask & (1 << i)) == 0))
      {
        double tempAns = adjacencyMatrix[startVertex][i] + tsp_dp(i, startVertexBitMask | (1 << i));
        if (tempAns < minAns)
        {
          minAns = tempAns;
          dp[i][startVertexBitMask | (1 << i)] = minAns;
        }

      }

    }

    {
      if (minAns < globalMinCost)
        globalMinCost = minAns;

    }
  }
  printf("Minimum Path: %lf\n", globalMinCost);
  double end_time = omp_get_wtime();
  printf("%lf\n", end_time - start_time);
  clock_gettime(CLOCK_MONOTONIC, &end_alg);
  clock_gettime(CLOCK_MONOTONIC, &end_e2e);
  e2e = diff(start_e2e, end_e2e);
  alg = diff(start_alg, end_alg);
  return 0;
}

