import os
import re, mmap
cwd = os.getcwd()
i = 1
buggy_files = []
safe_files = []
for file in os.listdir(cwd):
    filename = os.fsdecode(file)
    if filename.endswith(".c") or filename.endswith(".C"):
        if i < 301:
            buggy_files.append(filename)
            i = i + 1
        else:
            i = 1
            break
    else:
        continue
for file in os.listdir(cwd + '/safed'):
    filename = os.fsdecode(file)
    if filename.endswith(".c") or filename.endswith(".C"):
        if i < 301:
            safe_files.append(filename)
            i = i + 1
        else:
            break
    else:
        continue

for x in range(0, 151):
    file_buggy = open(buggy_files[x], 'r')
    file_safe = open('safed/' + safe_files[x], 'r')
    content_buggy = file_buggy.read()
    content_safe = file_safe.read()
    start = content_safe.find('{')
    end = content_safe.rfind('}')
    content_safe = content_safe[start + 1:end]

    start = content_buggy.find('{')
    content_buggy = content_buggy[:start + 1] + content_safe + content_buggy[start + 1:]
    f = open('neutralized/' + buggy_files[x], 'w')
    f.write(content_buggy)
    f.close

for x in range(151, 300):
    file_buggy = open(buggy_files[x], 'r')
    file_safe = open('safed/' + safe_files[x], 'r')
    content_buggy = file_buggy.read()
    content_safe = file_safe.read()
    start = content_safe.find('{')
    end = content_safe.rfind('}')
    content_safe = content_safe[start + 1:end]

    end = content_buggy.rfind('}')
    content_buggy = content_buggy[:end] + content_safe + content_buggy[end:]
    f = open('neutralized/' + buggy_files[x], 'w')
    f.write(content_buggy)
    f.close

#content = content_buggy.replace("{", "{\n" + )

# file_buggy = open(buggy_files[1], 'r')
# file_safe = open('safed/' + safe_files[1], 'r')
# content_buggy = file_buggy.read()
# content_safe = file_safe.read()
# print(content_buggy)
# print(content_safe)
# start = content_safe.find('{')
# end = content_safe.rfind('}')
# content_safe = content_safe[start + 1:end]
#
# start = content_buggy.find('{')
# content_buggy = content_buggy[:end] + content_safe + content_buggy[end:]
