static long NUM_STEP = 100000000;
double STEP;
void main()
{
  int i;
  int nthreads;
  double pi;
  double STEP = 1.00 / ((double) NUM_STEP);
  double start = omp_get_wtime();
  omp_set_num_threads(4);
  #pragma omp parallel
  {
    int i;
    int id;
    int nthrds;
    double x;
    double sum;
    nthrds = omp_get_num_threads();
    id = omp_get_thread_num();
    if (id == 0)
      nthreads = nthrds;

    for (i = id, sum = 0.0; i < NUM_STEP; i = i + nthrds)
    {
      x = (i + 0.5) * STEP;
      sum += 4.0 / (1.0 + (x * x));
    }

    pi += sum * STEP;
  }
  printf("Time for this omp process is : \t %f \n", omp_get_wtime() - start);
  printf("the simulated psi is %f\n", pi);

  int i;
  my_dist[tid] = add_dist(my_path);
  if (depth == 1)
  {
    if (my_dist[tid] < min_dist)
    {
      #pragma omp critical
      {
        min_dist = my_dist[tid];
        for (i = 0; i < num; i++)
        {
          best_path[i] = my_path[(tid * num) + i];
        }

      }
    }

  }
  else
    if ((my_dist[tid] <= min_dist) || (depth > (num / 2)))
  {
    tid = omp_get_thread_num();
    for (i = 1; i < depth; i++)
    {
      int tmp = my_path[((tid * num) + depth) - 1];
      my_path[((tid * num) + depth) - 1] = my_path[(tid * num) + i];
      my_path[(tid * num) + i] = tmp;
      ts(depth - 1, tid);
      tmp = my_path[((tid * num) + depth) - 1];
      my_path[((tid * num) + depth) - 1] = my_path[(tid * num) + i];
      my_path[(tid * num) + i] = tmp;
    }

  }


}

