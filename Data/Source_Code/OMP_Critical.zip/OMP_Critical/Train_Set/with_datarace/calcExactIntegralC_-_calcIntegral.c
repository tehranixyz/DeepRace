double calcIntegral(double *X, double *y, int lenY, int *T, int lenT, int dim, double *AdSave, double *GdSave)
{
  double integral = 0;
  #pragma omp parallel num_threads(NUMCORES)
  {
    int i;
    int j;
    int k;
    double Gd;
    double Ad;
    double integralLocal = 0;
    double *yTmp = malloc((dim + 1) * (sizeof(double)));
    double *Xtmp = malloc((dim * dim) * (sizeof(double)));
    int dimT = dim + 1;
    double wkopt;
    double *work;
    ptrdiff_t N = dim;
    ptrdiff_t n = dim;
    ptrdiff_t lda = dim;
    ptrdiff_t ldvl = dim;
    ptrdiff_t ldvr = dim;
    ptrdiff_t info;
    ptrdiff_t lwork;
    double *wr = malloc(N * (sizeof(double)));
    double *wi = malloc(N * (sizeof(double)));
    double *vl = malloc((N * dim) * (sizeof(double)));
    double *vr = malloc((N * dim) * (sizeof(double)));
    double wrCurr;
    double wiCurr;
    #pragma omp for
    for (i = 0; i < lenT; i++)
    {
      for (j = 0; j < (dim + 1); j++)
      {
        yTmp[j] = y[T[(i * dimT) + j]];
      }

      qsort(yTmp, dim + 1, sizeof(double), comp);
      Gd = calcGD(yTmp, dim + 1);
      for (j = 0; j < dim; j++)
      {
        for (k = 0; k < dim; k++)
        {
          Xtmp[(j * dim) + k] = X[(T[((i * dimT) + j) + 1] * dim) + k] - X[(T[i * dimT] * dim) + k];
        }

      }

      lwork = -1;
      dgeev("N", "N", &n, Xtmp, &lda, wr, wi, vl, &ldvl, vr, &ldvr, &wkopt, &lwork, &info);
      lwork = (int) wkopt;
      work = (double *) malloc(lwork * (sizeof(double)));
      dgeev("N", "N", &n, Xtmp, &lda, wr, wi, vl, &ldvl, vr, &ldvr, work, &lwork, &info);
      for (j = 1; j < dim; j++)
      {
        wrCurr = wr[j];
        wiCurr = wi[j];
        wr[j] = (wr[j - 1] * wrCurr) - (wi[j - 1] * wiCurr);
        wi[j] = (wr[j - 1] * wiCurr) + (wi[j - 1] * wrCurr);
      }

      Ad = fabs(wr[dim - 1]);
      integralLocal += Ad * Gd;
      free(work);
      AdSave[i] = Ad;
      GdSave[i] = Gd;
    }

    {
      integral += integralLocal;
    }
    free(yTmp);
    free(Xtmp);
    free(wr);
    free(wi);
    free(vl);
    free(vr);
  }
  return integral;
}

