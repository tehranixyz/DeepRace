int main(int argc, char *argv[])
{
  int *a;
  int *h_s;
  int *h_p;
  int i;
  int hilos;
  double start;
  double stop;
  hilos = atoi(argv[1]);
  a = (int *) malloc((sizeof(int)) * 100000000);
  h_s = (int *) malloc((sizeof(int)) * 5);
  h_p = (int *) malloc((sizeof(int)) * 5);
  srand((unsigned int) time(0));
  for (i = 0; i < 100000000; i++)
  {
    a[i] = rand() % 5;
  }

  for (i = 0; i < 5; i++)
  {
    h_s[i] = 0;
    h_p[i] = 0;
  }

  start = omp_get_wtime();
  for (i = 0; i < 100000000; i++)
  {
    h_s[a[i]]++;
  }

  stop = omp_get_wtime();
  printf("Tiempo serial: %f\n", stop - start);
  omp_set_num_threads(hilos);
  start = omp_get_wtime();
  #pragma omp parallel
  {
    int h_p_a[5];
    for (i = 0; i < 5; i++)
    {
      h_p_a[i] = 0;
    }

    #pragma omp for
    for (i = 0; i < 100000000; i++)
    {
      h_p_a[a[i]]++;
    }

    for (i = 0; i < 5; i++)
    {
      h_p[i] += h_p_a[i];
    }

  }
  stop = omp_get_wtime();
  printf("Tiempo paralelo: %f\n", stop - start);
  for (i = 0; i < 5; i++)
    printf("%d.-%d ", i, h_s[i]);

  printf("\n");
  for (i = 0; i < 5; i++)
    printf("%d.-%d ", i, h_p[i]);

  return 0;
}

