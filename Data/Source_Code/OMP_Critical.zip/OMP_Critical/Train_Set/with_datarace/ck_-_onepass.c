{
  unsigned key;
  unsigned value;
} keyvalue;
{
  unsigned n_max;
  unsigned n;
  unsigned *pt;
  keyvalue *kv;
} bheap;
{
  unsigned s;
  unsigned t;
} edge;
{
  unsigned n;
  unsigned e;
  unsigned n2;
  unsigned e2;
  edge *edges;
  unsigned *d0;
  unsigned *cd0;
  unsigned *adj0;
  unsigned *rank;
  unsigned core;
  unsigned *d;
  unsigned *cd;
  unsigned *adj;
} sparse;
unsigned long long *onepass(sparse *g, unsigned kmax)
{
  unsigned e;
  unsigned u;
  unsigned v;
  unsigned k;
  unsigned *merge;
  unsigned *size;
  unsigned long long *nck = calloc(kmax, sizeof(unsigned long long));
  unsigned long long *nck_p;
  nck[0] = g->n;
  nck[1] = g->e;
  if (kmax > 2)
  {
    #pragma omp parallel private(merge,size,nck_p,e,u,v,k)
    {
      size = malloc(((kmax - 2) * (sizeof(unsigned))) + ((sizeof(int)) * 16));
      nck_p = calloc(kmax, (sizeof(unsigned long long)) + ((sizeof(int)) * 16));
      if (kmax == 3)
      {
        #pragma omp for schedule(dynamic, 1) nowait
        for (e = 0; e < g->e2; e++)
        {
          u = g->edges[e].s;
          v = g->edges[e].t;
          size[0] = merging2(&g->adj[g->cd[u]], g->d[u], &g->adj[g->cd[v]], g->d[v]);
          nck_p[2] += size[0];
        }

      }
      else
      {
        merge = malloc((((kmax - 2) * g->core) * (sizeof(unsigned))) + ((sizeof(int)) * 16));
        #pragma omp for schedule(dynamic, 1) nowait
        for (e = 0; e < g->e2; e++)
        {
          u = g->edges[e].s;
          v = g->edges[e].t;
          size[0] = merging(&g->adj[g->cd[u]], g->d[u], &g->adj[g->cd[v]], g->d[v], merge);
          nck_p[2] += size[0];
          recursion(kmax, 3, merge, size, g, nck_p);
        }

        free(merge);
      }

      free(size);
      {
        for (k = 2; k < kmax; k++)
        {
          nck[k] += nck_p[k];
        }

        free(nck_p);
      }
    }
  }

  return nck;
}

