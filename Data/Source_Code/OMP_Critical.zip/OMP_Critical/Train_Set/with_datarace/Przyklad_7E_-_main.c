int main()
{
  long silnia = 1;
  long silnia_loc = 1;
  long i;
  #pragma omp parallel firstprivate(silnia_loc)
  {
    #pragma omp for
    for (i = 1; i <= 10; i++)
    {
      silnia_loc = silnia_loc * i;
    }

    {
      silnia = silnia_loc * silnia;
    }
  }
  printf("%d!=%ld\n", 10, silnia);
  return 0;
}

