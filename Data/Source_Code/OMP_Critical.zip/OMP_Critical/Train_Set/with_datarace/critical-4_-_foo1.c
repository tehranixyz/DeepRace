extern void bar(int);
void foo1(void)
{
  bar(0);
}

