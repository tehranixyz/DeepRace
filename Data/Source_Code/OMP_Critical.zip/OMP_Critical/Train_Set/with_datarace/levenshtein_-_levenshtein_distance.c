int levenshtein_distance(const int *s1, size_t len1, const int *s2, size_t len2)
{
  int th_id;
  int nthreads;
  int **bounds;
  int n;
  while (((len1 > 0) && (len2 > 0)) && ((*s1) == (*s2)))
  {
    len1--;
    len2--;
    s1++;
    s2++;
  }

  while (((len1 > 0) && (len2 > 0)) && (s1[len1 - 1] == s2[len2 - 1]))
  {
    len1--;
    len2--;
  }

  if (len1 == 0)
    return len2;

  if (len2 == 0)
    return len1;

  if (len1 < len2)
  {
    const int *tmp;
    tmp = s1;
    s1 = s2;
    s2 = tmp;
    len1 ^= len2;
    len2 ^= len1;
    len1 ^= len2;
  }

  #pragma omp parallel private(th_id) shared(bounds, n, nthreads)
  {
    size_t chunk_size;
    size_t idx;
    int i;
    int j;
    int *r;
    int *p;
    int x1;
    int x2;
    th_id = 0;
    nthreads = 1;
    #pragma omp barrier
    chunk_size = len1 / nthreads;
    idx = th_id * chunk_size;
    if (th_id == (nthreads - 1))
    {
      chunk_size = len1 - idx;
    }

    #pragma omp master
    bounds = malloc(nthreads * (sizeof(int *)));
    #pragma omp barrier
    bounds[th_id] = malloc((len2 + 1) * (sizeof(int)));
    for (j = 0; j <= len2; ++j)
    {
      bounds[th_id][j] = -1;
    }

    #pragma omp barrier
    n = ((*s1) != (*s2)) ? (1) : (0);
    r = (int *) malloc((sizeof(int)) * (chunk_size + 1));
    for (i = 0, p = r; i <= chunk_size; ++i)
      *(p++) = idx + i;

    for (j = 1; j <= len2; ++j)
    {
      x2 = r[0] + 1;
      do
      {
        x1 = (th_id) ? (bounds[th_id - 1][j]) : (j);
      }
      while (x1 == (-1));
      r[0] = x1;
      for (i = 1; i <= chunk_size; ++i)
      {
        x2 -= s1[(idx + i) - 1] == s2[j - 1];
        if ((++x1) > x2)
        {
          x1 = x2;
        }

        x2 = r[i] + 1;
        if (x1 > x2)
        {
          x1 = x2;
        }

        r[i] = x1;
      }

      bounds[th_id][j] = r[chunk_size];
    }

    n = r[chunk_size];
    free(r);
    #pragma omp barrier
    free(bounds[th_id]);
    #pragma omp master
    free(bounds);
  }
  return n;

  double *data;
  double *result;
  double *result_blas;
  dgemm_initialize(&data, &result, &result_blas, max_size);
  int test_status = TEST_SUCCESS;
  unsigned char offseta;
  unsigned char offsetb;
  test_print_header(output_file);
  #pragma omp parallel default(shared)
  {
    struct test_statistics_t test_stat;
    test_papi_initialize(&test_stat);
    int tid = omp_get_thread_num();
    unsigned int i;
    unsigned int j;
    for (i = min_size; i < max_size; i++)
    {
      #pragma omp single
      {
        for (j = 0; j < (i * i); j++)
          result[j] = (result_blas[j] = 0.0);

        offseta = rand() % (max_size * max_size);
        offsetb = rand() % (max_size * max_size);
      }
      int retval;
      test_stat.elapsed_time = PAPI_get_real_usec();
      if ((retval = PAPI_reset(test_stat.event_set)) != PAPI_OK)
        test_fail("dgemm_unittest.c", 69, "PAPI_reset", retval);

      dgemm(i, i, i, data + offseta, data + offsetb, result);
      if ((retval = PAPI_read(test_stat.event_set, test_stat.counters)) != PAPI_OK)
        test_fail("dgemm_unittest.c", 74, "PAPI_read", retval);

      test_stat.elapsed_time = PAPI_get_real_usec() - test_stat.elapsed_time;
      #pragma omp critical
      test_print_statistic(tid, i, test_stat, output_file);
      #pragma omp single
      {
        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, i, i, i, -1.0, data + offseta, i, data + offsetb, i, 1.0, result_blas, i);
        double result_norm;
        double result_blas_norm;
        result_norm = LAPACKE_dlange(LAPACK_ROW_MAJOR, '1', i, i, result, i);
        result_blas_norm = LAPACKE_dlange(LAPACK_ROW_MAJOR, '1', i, i, result_blas, i);
        if (abs(result_norm - result_blas_norm) > MACH_ERROR)
          test_status = TEST_FAIL;

      }
    }

    test_papi_destroy(&test_stat);
  }
  free(data);
  free(result);
  free(result_blas);
  return test_status;
}

