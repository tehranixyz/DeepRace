static char rcsid[] = "$Id$";
int errors = 0;
int thds;
enum x {
  int *q;
  int pos;
  int size;
} Q;
int getWork(struct Q *workQ, int *work)
{
  int rc;
  #pragma omp critical
  {
    if (workQ->pos > (-1))
    {
      *work = workQ->q[workQ->pos];
      workQ->pos--;
      rc = 1;
    }
    else
    {
      rc = 0;
    }

  }
  return rc;
ZERO = 0, ONE, TWO, THREE};
enum x prvt;
void func(int t)
{
  int i;
  #pragma omp for schedule(static,1) lastprivate (prvt)
  for (i = 0; i < thds; i++)
  {
    prvt = (enum x) i;
    barrier(t);
    if (prvt != ((enum x) i))
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(enum x)))
    {
      errors += 1;
    }

    if (i == 0)
    {
      waittime(1);
    }

    prvt = (enum x) i;
  }

  if (prvt != ((enum x) (thds - 1)))
  {
    errors += 1;
  }

}

