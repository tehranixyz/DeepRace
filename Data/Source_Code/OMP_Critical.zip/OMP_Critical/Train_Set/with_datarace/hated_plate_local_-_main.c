int main(int argc, char *argv[]);
int main(int argc, char *argv[])
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = (org = 1);
  #pragma omp parallel default(shared) copyin (prvt)
  {
    if (prvt != org)
    {
      #pragma omp critical
      errors += 1;
    }

  }
  prvt = (org = 2);
  #pragma omp parallel default(none) shared(org,errors) copyin (prvt)
  {
    if (prvt != org)
    {
      #pragma omp critical
      errors += 1;
    }

  }
  if (errors == 0)
  {
    printf("copyin 018 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("copyin 018 : FAILED\n");
    return 1;
  }


  double diff;
  double epsilon = 0.001;
  int i;
  int iterations;
  int iterations_print;
  int j;
  double mean;
  double my_diff;
  double u[700][700];
  double w[700][700];
  double wtime;
  printf("\n");
  printf("HEATED_PLATE_OPENMP\n");
  printf("  C/OpenMP version\n");
  printf("  A program to solve for the steady state temperature distribution\n");
  printf("  over a rectangular plate.\n");
  printf("\n");
  printf("  Spatial grid of %d by %d points.\n", 700, 700);
  printf("  The iteration will be repeated until the change is <= %e\n", epsilon);
  printf("  Number of processors available = %d\n", omp_get_num_procs());
  printf("  Number of threads =              %d\n", omp_get_max_threads());
  mean = 0.0;
  omp_set_schedule(omp_sched_static, 0);
  #pragma omp parallel shared ( w ) private ( i, j )
  {
    #pragma omp for schedule(runtime)
    for (i = 1; i < (700 - 1); i++)
    {
      w[i][0] = 100.0;
    }

    #pragma omp for schedule(runtime)
    for (i = 1; i < (700 - 1); i++)
    {
      w[i][700 - 1] = 100.0;
    }

    #pragma omp for schedule(runtime)
    for (j = 0; j < 700; j++)
    {
      w[700 - 1][j] = 100.0;
    }

    #pragma omp for schedule(runtime)
    for (j = 0; j < 700; j++)
    {
      w[0][j] = 0.0;
    }

    #pragma omp for schedule(runtime) reduction ( + : mean )
    for (i = 1; i < (700 - 1); i++)
    {
      mean = (mean + w[i][0]) + w[i][700 - 1];
    }

    #pragma omp for schedule(runtime) reduction ( + : mean )
    for (j = 0; j < 700; j++)
    {
      mean = (mean + w[700 - 1][j]) + w[0][j];
    }

  }
  mean = mean / ((double) (((2 * 700) + (2 * 700)) - 4));
  printf("\n");
  printf("  MEAN = %f\n", mean);
  omp_set_schedule(omp_sched_static, 0);
  #pragma omp parallel shared ( mean, w ) private ( i, j )
  {
    printf("dins\n");
    #pragma omp for schedule(runtime)
    for (i = 1; i < (700 - 1); i++)
    {
      for (j = 1; j < (700 - 1); j++)
      {
        w[i][j] = mean;
      }

    }

  }
  iterations = 0;
  iterations_print = 1;
  printf("\n");
  printf(" Iteration  Change\n");
  printf("\n");
  wtime = omp_get_wtime();
  diff = epsilon;
  while (epsilon <= diff)
  {
    omp_set_schedule(omp_sched_static, 0);
    #pragma omp parallel shared ( u, w ) private ( i, j )
    {
      #pragma omp for schedule(runtime)
      for (i = 0; i < 700; i++)
      {
        for (j = 0; j < 700; j++)
        {
          u[i][j] = w[i][j];
        }

      }

      #pragma omp for schedule(runtime)
      for (i = 1; i < (700 - 1); i++)
      {
        for (j = 1; j < (700 - 1); j++)
        {
          w[i][j] = (((u[i - 1][j] + u[i + 1][j]) + u[i][j - 1]) + u[i][j + 1]) / 4.0;
        }

      }

    }
    diff = 0.0;
    omp_set_schedule(omp_sched_static, 0);
    #pragma omp parallel shared ( diff, u, w ) private ( i, j, my_diff )
    {
      my_diff = 0.0;
      #pragma omp for schedule(runtime)
      for (i = 1; i < (700 - 1); i++)
      {
        for (j = 1; j < (700 - 1); j++)
        {
          if (my_diff < fabs(w[i][j] - u[i][j]))
          {
            my_diff = fabs(w[i][j] - u[i][j]);
          }

        }

      }

      {
        if (diff < my_diff)
        {
          diff = my_diff;
        }

      }
    }
    iterations++;
    if (iterations == iterations_print)
    {
      printf("  %8d  %f\n", iterations, diff);
      iterations_print = 2 * iterations_print;
    }

  }

  wtime = omp_get_wtime() - wtime;
  printf("\n");
  printf("  %8d  %f\n", iterations, diff);
  printf("\n");
  printf("  Error tolerance achieved.\n");
  printf("  Wallclock time = %f\n", wtime);
  printf("\n");
  printf("HEATED_PLATE_OPENMP:\n");
  printf("  Normal end of execution.\n");
  return 0;
}

