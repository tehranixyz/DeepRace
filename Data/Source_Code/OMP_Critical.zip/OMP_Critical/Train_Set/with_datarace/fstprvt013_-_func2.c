static char rcsid[] = "$Id$";
int errors = 0;
int thds;
struct x
{
  int i;
  double d;
};
struct x prvt;
void func2(int magicno)
{
  static int err;
  int id = omp_get_thread_num();
  if (prvt.i != magicno)
  {
    errors += 1;
  }

  if (prvt.d != (magicno + 1))
  {
    errors += 1;
  }

  #pragma omp barrier
  prvt.i = id;
  err = 0;
  #pragma omp barrier
  if (prvt.i != id)
  {
    err += 1;
  }

  #pragma omp barrier
  #pragma omp master
  if (err != (thds - 1))
  {
    errors++;
  }

}

