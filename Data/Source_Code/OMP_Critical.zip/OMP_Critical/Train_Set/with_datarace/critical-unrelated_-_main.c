int main(int argc, char *argv[])
{
  int var = 0;
  #pragma omp parallel num_threads(2) shared(var)
  {
    {
    }
    var++;
  }
  fprintf(stderr, "DONE\n");
}

