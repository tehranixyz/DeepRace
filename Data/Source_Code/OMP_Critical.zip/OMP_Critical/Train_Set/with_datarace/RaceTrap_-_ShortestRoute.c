{
  int x;
  int y;
} Coord;
{
  double length;
  unsigned char nPlaced;
  unsigned char path[0];
} RouteDefinition;
int nBags = 0;
Coord *bagCoords;
double **distanceTable;
double maxRouteLen = 10E100;
double globalBest = 10E100;
int done = 0;
RouteDefinition *ShortestRoute(RouteDefinition *route)
{
  int i;
  RouteDefinition *bestRoute;
  if (route->nPlaced == nBags)
  {
    route->length += distanceTable[route->path[route->nPlaced - 1]][route->path[0]];
    return route;
  }

  bestRoute = Alloc_RouteDefinition();
  bestRoute->length = maxRouteLen;
  #pragma omp parallel for private(done)
  for (i = route->nPlaced; i < nBags; i++)
  {
    done++;
    double newLength = route->length + distanceTable[route->path[route->nPlaced - 1]][route->path[i]];
    RouteDefinition *newRoute;
    if (newLength >= globalBest)
      continue;

    newRoute = Alloc_RouteDefinition();
    memcpy(newRoute->path, route->path, nBags);
    newRoute->path[route->nPlaced] = route->path[i];
    newRoute->path[i] = route->path[route->nPlaced];
    newRoute->nPlaced = route->nPlaced + 1;
    newRoute->length = newLength;
    if (done > 1)
      newRoute = ShortestRoute2(newRoute);
    else
      newRoute = ShortestRoute(newRoute);

    if (newRoute->length < bestRoute->length)
    {
      free(bestRoute);
      bestRoute = newRoute;
      {
        if (bestRoute->length < globalBest)
        {
          globalBest = bestRoute->length;
        }

      }
    }
    else
    {
      free(newRoute);
    }

  }

  free(route);
  return bestRoute;

  int i;
  double sum = 0.0;
  double pi;
  double x_i;
  double step = 1.0 / 10000;
  #pragma omp parallel num_threads(NUM_THREADS) private(i, x_i)
  {
    int id = omp_get_thread_num();
    int nths = omp_get_num_threads();
    double local_sum = 0.0;
    for (i = id; i < 10000; i += nths)
    {
      x_i = (i + 0.5) * step;
      local_sum = local_sum + (4.0 / (1.0 + (x_i * x_i)));
    }

    #pragma omp critical
    sum = sum + local_sum;
  }
  pi = sum * step;
  printf("Pi: %.15e\n", pi);
  return 0;
}

