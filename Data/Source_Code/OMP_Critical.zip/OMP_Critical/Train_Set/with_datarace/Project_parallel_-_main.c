int main(int argc, char *argv[])
{
  double mySquare = 0.0;
  double globalSquare = 0.0;
  #pragma omp parallel
  {
    int myRank = omp_get_thread_num();
    int threadCount = omp_get_num_threads();
    int nPerProcess = n / threadCount;
    if (myRank < (threadCount - 1))
    {
      for (int i = myRank * nPerProcess; i < ((myRank * nPerProcess) + nPerProcess); i++)
      {
        norm[i] = A[(i * (n + 1)) + n];
      }

      for (int i = myRank * nPerProcess; i < ((myRank * nPerProcess) + nPerProcess); i++)
      {
        temp[i] = 0;
        #pragma omp simd
        for (int j = 0; j < n; j++)
        {
          temp[i] += A[(i * (n + 1)) + j] * x[j];
        }

      }

      for (int i = myRank * nPerProcess; i < ((myRank * nPerProcess) + nPerProcess); i++)
      {
        norm[i] -= temp[i];
      }

      for (int i = myRank * nPerProcess; i < ((myRank * nPerProcess) + nPerProcess); i++)
      {
        mySquare += norm[i] * norm[i];
      }

      if (myRank == 0)
      {
        printf("Available Cores: %d\n", omp_get_num_procs());
        printf("Number of Threads: %d\n", omp_get_num_threads());
        getrusage(RUSAGE_SELF, &usage);
        userTime = usage.ru_utime;
        systemTime = usage.ru_stime;
        userT = 0.0;
        sysT = 0.0;
        userT += 1000000 * userTime.tv_sec;
        userT += userTime.tv_usec;
        sysT += 1000000 * systemTime.tv_sec;
        sysT += systemTime.tv_usec;
        printf("User CPU Time: %.8lf seconds\n", userT / 1000000);
      }

    }
    else
    {
      for (int i = myRank * nPerProcess; i < n; i++)
      {
        norm[i] = A[(i * (n + 1)) + n];
      }

      for (int i = myRank * nPerProcess; i < n; i++)
      {
        temp[i] = 0;
        #pragma omp simd
        for (int j = 0; j < n; j++)
        {
          temp[i] += A[(i * (n + 1)) + j] * x[j];
        }

      }

      for (int i = myRank * nPerProcess; i < n; i++)
      {
        norm[i] -= temp[i];
      }

      for (int i = myRank * nPerProcess; i < n; i++)
      {
        mySquare += norm[i] * norm[i];
      }

    }

  }
  #pragma omp critical
  globalSquare += mySquare;
  globalSquare = sqrt(globalSquare);
  printf("Value of L^2 norm: %.10e\n", globalSquare);

  int M = 500;
  int N = 500;
  double diff;
  double err_tol = 0.001;
  int i;
  int itr;
  int itr_print;
  int j;
  double mean;
  double obtd_diff;
  double u[M][N];
  double w[M][N];
  double wtime;
  printf("\n");
  printf("HEATED_PLATE_OPENMP\n");
  printf("  Parallel version\n");
  printf("A program to solve the steady state temperature distribution in a 2D rectangular plate\n");
  printf("\n");
  printf("  Spatial grid of %d by %d points.\n", M, N);
  printf("  The iteration will be repeated until the change is <= %e\n", err_tol);
  omp_set_num_threads(4);
  #pragma omp parallel
  #pragma omp master
  {
    printf("  Number of threads available =%d\n", omp_get_num_threads());
  }
  mean = 0.0;
  #pragma omp parallel shared ( w ) private ( i, j )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j] = 0.0;
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = (mean + w[i][0]) + w[i][N - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = (mean + w[M - 1][j]) + w[0][j];
    }

  }
  mean = mean / ((double) (((2 * M) + (2 * N)) - 4));
  printf("\n");
  printf("  Mean Temperature = %f\n", mean);
  #pragma omp parallel shared ( mean, w ) private ( i, j )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      for (j = 1; j < (N - 1); j++)
      {
        w[i][j] = mean;
      }

    }

  }
  itr = 0;
  itr_print = 1;
  printf("\n");
  printf(" Iteration  Change in temperature\n");
  printf("\n");
  wtime = omp_get_wtime();
  diff = err_tol;
  while (err_tol <= diff)
  {
    #pragma omp parallel shared ( u, w ) private ( i, j )
    {
      #pragma omp for
      for (i = 0; i < M; i++)
      {
        for (j = 0; j < N; j++)
        {
          u[i][j] = w[i][j];
        }

      }

      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          w[i][j] = (((u[i - 1][j] + u[i + 1][j]) + u[i][j - 1]) + u[i][j + 1]) / 4.0;
        }

      }

    }
    diff = 0.0;
    #pragma omp parallel shared ( diff, u, w ) private ( i, j, obtd_diff )
    {
      obtd_diff = 0.0;
      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          if (obtd_diff < fabs(w[i][j] - u[i][j]))
          {
            obtd_diff = fabs(w[i][j] - u[i][j]);
          }

        }

      }

      {
        if (diff < obtd_diff)
        {
          diff = obtd_diff;
        }

      }
    }
    itr++;
    if (itr == itr_print)
    {
      printf("  %8d  %f\n", itr, diff);
      itr_print = 2 * itr_print;
    }

  }

  wtime = omp_get_wtime() - wtime;
  printf("\n");
  printf("  %8d  %f\n", itr, diff);
  printf("\n");
  printf("  Error tolerance achieved.\n");
  printf("  Wallclock time = %f\n", wtime);
  printf("\n");
  printf("HEATED_PLATE_OPENMP:\n");
  printf("  Normal end of execution.\n");
  return 0;
}

