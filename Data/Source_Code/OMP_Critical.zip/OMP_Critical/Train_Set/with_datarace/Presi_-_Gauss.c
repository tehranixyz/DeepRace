int Gauss(float A[4000][4000 + 1])
{
  int i;
  int j;
  int k;
  int n;
  n = 4000 - 1;
  float c;
  float sum = 0.0;
  float x[n];
  for (j = 1; j <= n; j++)
  {
    #pragma omp parallel for private(c)
    for (i = 1; i <= n; i++)
    {
      if (i > j)
      {
        c = A[i][j] / A[j][j];
        for (k = 1; k <= (n + 1); k++)
        {
          A[i][k] = A[i][k] - (c * A[j][k]);
        }

      }

    }

  }

  x[n] = A[n][n + 1] / A[n][n];
  for (i = n - 1; i >= 1; i--)
  {
    sum = 0;
    #pragma omp parallel for
    for (j = 1; j <= n; j++)
    {
      if (j > i)
      {
        sum = sum + (A[i][j] * x[j]);
      }

      x[i] = (A[i][n + 1] - sum) / A[i][i];
    }

  }

  printf("\nx%d=%f\t", i, x[n]);
  float Fr = A[1][0] * x[1];
  printf("\nThe solution is: Fr= %f \n", Fr);
  return 0;
}

