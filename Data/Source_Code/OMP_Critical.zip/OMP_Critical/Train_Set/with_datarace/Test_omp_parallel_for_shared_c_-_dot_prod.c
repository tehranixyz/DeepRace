float dot_prod(float *a, float *b, int N)
{
  float sum = 0.0;
  int i;
  #pragma omp parallel for shared(sum)
  for (i = 0; i < N; i++)
  {
    sum += a[i] * b[i];
  }

  return sum;
}

