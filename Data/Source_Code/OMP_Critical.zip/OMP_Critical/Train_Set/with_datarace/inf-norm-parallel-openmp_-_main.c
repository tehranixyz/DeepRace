int main(int argc, char *argv[])
{
  int p;
  int q;
  int return_value_counter;
  int counter;
  int thread_count;
  int current_row = 0;
  int column;
  int i;
  int j;
  int k;
  int number_of_rows;
  int numberOfThreads;
  int N;
  int MAXTHREADS;
  int start;
  int end;
  double time_start;
  double time_end;
  double memoryused = 00;
  double mynorm = 0;
  double myRowSum;
  double sum;
  double **A;
  double **B;
  double **C;
  double NormRow = 0;
  struct timeval tv1;
  struct timeval tv2;
  struct timezone tz;
  if (argc < 3)
  {
    fprintf(stderr, "\t\t Not enough Arguments\n ");
    fprintf(stderr, "\t\t usage : %s <N> <numberOfThreads>\n", argv[0]);
    exit(-1);
  }
  else
  {
    sscanf(argv[1], "%d", &N);
    sscanf(argv[2], "%d", &numberOfThreads);
    MAXTHREADS = omp_get_num_procs() * 8;
    omp_set_num_threads(numberOfThreads);
  }

  fprintf(stdout, "\n\t\t Input Parameters ::");
  fprintf(stdout, "\n\t\t Size of Matrix      :  %d", N);
  fprintf(stdout, "\n\t\t Number of CPU       :  %d", omp_get_num_procs());
  fprintf(stdout, "\n\t\t Max # of Threads    :  %d", MAXTHREADS);
  fprintf(stdout, "\n\t\t #Threads To be Used :  %d", numberOfThreads);
  fprintf(stdout, "\n");
  if ((N % numberOfThreads) != 0)
  {
    fprintf(stderr, "\n Number of numberOfThreads must evenly divide N\n");
    exit(0);
  }

  if (numberOfThreads > N)
  {
    fprintf(stderr, "\nNumber of numberOfThreads should be <= %d", N);
    exit(0);
  }

  A = allocate2dArray(N, N);
  B = allocate2dArray(N, N);
  C = allocate2dArray(N, N);
  if (((A == 0) || (B == 0)) || (C == 0))
  {
    fprintf(stderr, "\n Not sufficient memory to accomodate the size of %d * %d Matrix", N, N);
    exit(0);
  }

  memoryused = 3 * ((N * N) * (sizeof(double)));
  initMat(0, N, N, A);
  initMat(0, N, N, B);
  cleanMat(N, N, C);
  number_of_rows = N / numberOfThreads;
  gettimeofday(&tv1, &tz);
  #pragma omp parallel shared(A,B,C,NormRow) private(thread_count,start,end,i,j,k,myRowSum,mynorm))
  {
    thread_count = omp_get_thread_num();
    start = ((thread_count + 1) - 1) * number_of_rows;
    end = ((thread_count + 1) * number_of_rows) - 1;
    myRowSum = 0.0;
    for (i = start; i <= end; i++)
    {
      for (j = 0; j < N; j++)
      {
        sum = 00;
        for (k = 0; k < N; k++)
        {
          sum += A[i][k] * B[k][j];
        }

        C[i][j] = sum;
        myRowSum += sum;
        if (mynorm < myRowSum)
        {
          mynorm = myRowSum;
        }

        if (NormRow < mynorm)
        {
          NormRow = mynorm;
        }

      }

    }

  }
  gettimeofday(&tv2, &tz);
  double elapsed = ((double) (tv2.tv_sec - tv1.tv_sec)) + (((double) (tv2.tv_usec - tv1.tv_usec)) * 1e-6);
  fprintf(stdout, "\n\t\t Row Wise partitioning - Infinity Norm of a Square MatrixDone ");
  deallocate2dArray(N, N, A);
  deallocate2dArray(N, N, B);
  deallocate2dArray(N, N, C);
  fprintf(stdout, "\n");
  fprintf(stdout, "\n\t\t INF-Norm Answer       :  %lf", NormRow);
  fprintf(stdout, "\n\t\t Memory Used           :  %lf MB", memoryused / (1024 * 1024));
  fprintf(stdout, "\n\t\t Time in  Seconds (T)  :  %lfs", elapsed);
  fprintf(stdout, "\n\t\t\n");
}

