void calc_area(double start, double end, double h, double *area)
{
  double i;
  double x;
  double local_area = 0.0;
  for (i = start; i < end; i = i + h)
  {
    local_area += f(i);
  }

  local_area = local_area * h;
  printf("\nlocal area[%d]: %.10lf\n", omp_get_thread_num(), local_area);
  *area += local_area;
STOP, RUN} generator_state_ = STOP;
const size_t CHUNKS_COUNT = 5000;
const size_t CHUNK_SIZE = 5000;
double **chunks_;
size_t chunk_num_ = 0;
long long summary_time_ = 0;
int finised_in_b_ = 0;
double laps_time_ = 0.0;
int a_;
int b_;
int x_;
int N_;
size_t num_threads_;
double p_;
double *getNewChunk()
{
  if (num_threads_ == 1)
  {
    return generateNewChunk();
  }

  double *new_chunk = 0;
  #pragma omp critical
  {
    while (chunks_[chunk_num_] == 0)
    {
    }

    new_chunk = chunks_[chunk_num_];
    chunks_[chunk_num_] = 0;
    chunk_num_++;
    if (chunk_num_ >= CHUNKS_COUNT)
    {
      chunk_num_ -= CHUNKS_COUNT;
    }

  }
  return new_chunk;
}

