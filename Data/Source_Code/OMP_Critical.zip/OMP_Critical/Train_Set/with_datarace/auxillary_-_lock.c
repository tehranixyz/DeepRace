void lock(int i, bool *locks)
{
  bool locked;
  for (locked = 0; locked == 0;)
  {
    {
      locked = ((!locks[i - 1]) && (!locks[i])) && (!locks[i + 1]);
      if (locked)
      {
        locks[i - 1] = 1;
        locks[i] = 1;
        locks[i + 1] = 1;
      }

    }
  }

}

