enum {VolumeError = -1, QStopError = -2};
double *m_x;
double *m_y;
double *m_z;
double *m_xd;
double *m_yd;
double *m_zd;
double *m_xdd;
double *m_ydd;
double *m_zdd;
double *m_fx;
double *m_fy;
double *m_fz;
double *m_nodalMass;
int *m_symmX;
int *m_symmY;
int *m_symmZ;
int *m_nodeElemCount;
int *m_nodeElemStart;
int *m_nodeElemCornerList;
int *m_matElemlist;
int *m_nodelist;
int *m_lxim;
int *m_lxip;
int *m_letam;
int *m_letap;
int *m_lzetam;
int *m_lzetap;
int *m_elemBC;
double *m_dxx;
double *m_dyy;
double *m_dzz;
double *m_delv_xi;
double *m_delv_eta;
double *m_delv_zeta;
double *m_delx_xi;
double *m_delx_eta;
double *m_delx_zeta;
double *m_e;
double *m_p;
double *m_q;
double *m_ql;
double *m_qq;
double *m_v;
double *m_volo;
double *m_vnew;
double *m_delv;
double *m_vdov;
double *m_arealg;
double *m_ss;
double *m_elemMass;
double m_dtfixed;
double m_time;
double m_deltatime;
double m_deltatimemultlb;
double m_deltatimemultub;
double m_stoptime;
double m_u_cut;
double m_hgcoef;
double m_qstop;
double m_monoq_max_slope;
double m_monoq_limiter_mult;
double m_e_cut;
double m_p_cut;
double m_ss4o3;
double m_q_cut;
double m_v_cut;
double m_qlc_monoq;
double m_qqc_monoq;
double m_qqc;
double m_eosvmax;
double m_eosvmin;
double m_pmin;
double m_emin;
double m_dvovmax;
double m_refdens;
double m_dtcourant;
double m_dthydro;
double m_dtmax;
int m_cycle;
int m_sizeX;
int m_sizeY;
int m_sizeZ;
int m_numElem;
int m_numNode;
inline static void CalcHydroConstraintForElems(int p_matElemlist[91125], double p_vdov[91125])
{
  int i;
  double dthydro = 1.0e+20;
  int hydro_elem = -1;
  double dvovmax = m_dvovmax;
  int length = m_numElem;
  #pragma omp parallel for private(i) firstprivate(length) shared(dthydro,hydro_elem)
  for (i = 0; i < length; ++i)
  {
    int indx = p_matElemlist[i];
    if (p_vdov[indx] != 0.)
    {
      double dtdvov = dvovmax / (FABS8(p_vdov[indx]) + 1.e-20);
      if (dthydro > dtdvov)
      {
        {
          dthydro = dtdvov;
          hydro_elem = indx;
        }
      }

    }

  }

  if (hydro_elem != (-1))
  {
    m_dthydro = dthydro;
  }

  return;

  double t_start;
  double t_end;
  *local_sense = !(*local_sense);
  #pragma omp critical
  {
    t_start = omp_get_wtime();
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

    t_end = omp_get_wtime();
  }
  *local_cc_time = ((*local_cc_time) + t_end) - t_start;
  while ((*sense) != (*local_sense))
  {
  }

  ;
}

