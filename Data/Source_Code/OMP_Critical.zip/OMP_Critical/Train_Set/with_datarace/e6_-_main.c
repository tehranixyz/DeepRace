int mem[20];
int main(int argc, const char *argv[])
{
  double *dx;
  dx = (double *) calloc(n, sizeof(double));
  int i;
  int j;
  int k;
  int id;
  int jstart;
  int jstop;
  int dnp = n / p;
  double dxi;
  for (k = 0; k < maxit; k++)
  {
    double sum = 0.0;
    for (i = 0; i < n; i++)
    {
      dx[i] = b[i];
      #pragma omp parallel shared(A,x) private(id,j,jstart,jstop,dxi)
      {
        id = omp_get_thread_num();
        jstart = id * dnp;
        jstop = jstart + dnp;
        dxi = 0.0;
        for (j = jstart; j < jstop; j++)
          dxi += A[i][j] * x[j];

        #pragma omp critical
        dx[i] -= dxi;
      }
      dx[i] /= A[i][i];
      x[i] += dx[i];
      sum += (dx[i] >= 0.0) ? (dx[i]) : (-dx[i]);
    }

    printf("%4d : %.3e\n", k, sum);
    if (sum <= epsilon)
      break;

  }

  *numit = k + 1;
  free(dx);

  srand(time(0));
  int thread_count = 8;
  int pos_prod = 0;
  int pos_cons = 0;
  #pragma omp parallel num_threads(thread_count)
  for (int t = 0; t < thread_count; ++t)
  {
    sleep(omp_get_thread_num());
    if ((omp_get_thread_num() % 2) == 0)
    {
      while (1)
      {
        if (mem[pos_prod] == 0)
        {
          mem[pos_prod] = (rand() % 100) + 1;
          printf("id:%d produce %d en posicion %d\n", omp_get_thread_num(), mem[pos_prod], pos_prod + 1);
          pos_prod = (pos_prod + 1) % 20;
          printf("Elementos al producir: ");
          for (int i = 0; i < 20; ++i)
            printf("%d ", mem[i]);

          printf("\n\n");
          sleep(1);
        }
        else
          printf("Productor id:%d en espera\n\n", omp_get_thread_num());

        sleep(1);
      }

    }
    else
    {
      while (1)
      {
        if (mem[pos_cons] != 0)
        {
          mem[pos_cons] = 0;
          pos_cons = (pos_cons + 1) % 20;
          printf("id:%d consume en posicion %d\n", omp_get_thread_num(), pos_cons + 1);
          printf("id:%d Elementos al consumir: ", omp_get_thread_num());
          for (int i = 0; i < 20; ++i)
            printf("%d ", mem[i]);

          printf("\n\n");
          sleep(2);
        }
        else
          printf("Consumidor id:%d en espera\n\n", omp_get_thread_num());

        sleep(2);
      }

    }

  }

  return 0;
}

