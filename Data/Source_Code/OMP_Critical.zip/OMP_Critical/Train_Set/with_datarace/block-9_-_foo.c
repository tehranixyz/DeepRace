void foo(int i)
{
  int sum = 0;
  int sum0 = 0;
  int known_sum;
  int i;
  int i0 = -1;
  #pragma omp parallel firstprivate(sum0)
  {
    #pragma omp for schedule(static,7)
    for (i = 1; i <= LOOPCOUNT; i++)
    {
      sum0 = sum0 + i;
      i0 = i;
    }

    #pragma omp critical
    {
      sum = sum + sum0;
    }
  }
  known_sum = (LOOPCOUNT * (LOOPCOUNT + 1)) / 2;
  return (known_sum == sum) && (i0 == LOOPCOUNT);

  int j;
  switch (i)
  {
    #pragma omp parallel
    {
      case 0:
        ;

    }
    #pragma omp for
    for (j = 0; j < 10; ++j)
    {
      case 1:
        ;

    }

    {
      case 2:
        ;

    }
    #pragma omp master
    {
      case 3:
        ;

    }
    #pragma omp sections
    {
      case 4:
        ;

      #pragma omp section
      {
        case 5:
          ;

      }
    }
    #pragma omp ordered
    {
      default:
        ;

    }
  }

}

