double maxeps = 0.1e-7;
int itmax = 100;
int i;
int j;
int k;
double eps;
double A[256][256][256];
void relax();
void init();
void verify();
void wtime();
void relax()
{
  if (random_array && contador)
  {
    int size = SIZE_VEC / THREAD_SIZE;
    int id = omp_get_thread_num();
    int init = id * size;
    int fin = init + size;
    for (int i = init; i < fin; ++i)
    {
      #pragma omp critical
      ++contador[max_integer(random_array[i])];
    }

  }


  #pragma omp parallel for ordered schedule(static, 1) private(i, j, k) shared(A)
  for (i = 1; i <= (256 - 2); i++)
  {
    #pragma omp ordered
    {
      for (j = 1; j <= (256 - 2); j++)
        for (k = 1; k <= (256 - 2); k++)
      {
        A[i][j][k] = (A[i - 1][j][k] + A[i + 1][j][k]) / 2.;
      }


    }
  }

  #pragma omp parallel for schedule(guided) private(i, j, k) shared(A)
  for (i = 1; i <= (256 - 2); i++)
    for (j = 1; j <= (256 - 2); j++)
    for (k = 1; k <= (256 - 2); k++)
  {
    A[i][j][k] = (A[i][j - 1][k] + A[i][j + 1][k]) / 2.;
  }



  #pragma omp parallel for schedule(guided) private(i,j,k) shared(A, eps)
  for (i = 1; i <= (256 - 2); i++)
  {
    double eps_loc = .0;
    for (j = 1; j <= (256 - 2); j++)
      for (k = 1; k <= (256 - 2); k++)
    {
      double e;
      e = A[i][j][k];
      A[i][j][k] = (A[i][j][k - 1] + A[i][j][k + 1]) / 2.;
      eps_loc = (eps_loc > fabs(e - A[i][j][k])) ? (eps_loc) : (fabs(e - A[i][j][k]));
    }


    {
      eps = (eps > eps_loc) ? (eps) : (eps_loc);
    }
  }

}

