int main()
{
  int iam = 0;
  int np = 1;
  int datos[100];
  int i = 0;
  int j = 0;
  #pragma omp parallel num_threads(4) private(iam, np,i) shared(j)
  {
    iam = omp_get_thread_num();
    for (i = 0; i < 5; i++)
    {
      {
        j++;
      }
    }

    printf("\tSoy el thread %d, valor actual de j: %d\n", iam, j);
  }
  printf("\t\tSoy el thread %d, valor FINAL de j: %d\n", iam, j);

  int i;
  long sum = 0;
  #pragma omp parallel for
  for (i = 0; i < n; i++)
    #pragma omp critical

  sum += a[i];
  return sum;
}

