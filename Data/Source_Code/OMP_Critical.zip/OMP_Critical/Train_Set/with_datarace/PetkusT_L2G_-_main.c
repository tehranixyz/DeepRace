int main(int argc, char **argv)
{
  #pragma omp critical
  *shrd += 1;
  #pragma omp barrier
  if ((*shrd) != thds)
  {
    #pragma omp critical
    errors += 1;
  }

  if ((sizeof(*shrd)) != (sizeof(double)))
  {
    #pragma omp critical
    errors += 1;
  }


  int c = 10;
  int c_change_counter = 0;
  int d = 100;
  int d_change_counter = 0;
  int total_output_count = 0;
  int output_count[5];
  int i = 0;
  for (i = 0; i < 5; i += 1)
  {
    output_count[i] = 0;
  }

  int maxGijuSk = 5;
  int gijosNr = omp_get_thread_num();
  printf("***************************************************\n");
  printf("%8s %8s %8s\n", "Proces.", "c", "d");
  printf("---------------------------------------------------\n");
  omp_set_num_threads(maxGijuSk);
  #pragma omp parallel private(gijosNr)
  {
    gijosNr = omp_get_thread_num();
    if (gijosNr < 2)
    {
      while (total_output_count < 30)
      {
        {
          c = c + 10;
          c_change_counter += 1;
          d = d - 2;
          d_change_counter += 1;
        }
      }

    }

    if (gijosNr >= 2)
    {
      while (output_count[gijosNr] < 10)
      {
        {
          if ((c_change_counter >= 2) && (d_change_counter >= 2))
          {
            printf("%8d %8d %8d\n", gijosNr + 1, c, d);
            c_change_counter = 0;
            d_change_counter = 0;
            output_count[gijosNr] += 1;
            total_output_count += 1;
          }

        }
      }

    }

  }
  printf("***************************************************\n");
  printf("Programa baigė darbą - bendras procesų išvedimų skaičius: %3d \n", total_output_count);
}

