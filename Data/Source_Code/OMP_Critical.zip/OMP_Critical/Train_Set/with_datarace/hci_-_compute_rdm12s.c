void compute_rdm12s(int norb, int neleca, int nelecb, uint64_t *strs, double *civec, uint64_t ndet, double *rdm1a, double *rdm1b, double *rdm2aa, double *rdm2ab, double *rdm2bb)
{
  #pragma omp parallel default(none) shared(norb, neleca, nelecb, strs, civec, ndet, rdm1a, rdm1b, rdm2aa, rdm2ab, rdm2bb)
  {
    size_t ip;
    size_t jp;
    size_t p;
    size_t q;
    size_t r;
    size_t s;
    int nset = (norb + 63) / 64;
    double ci_sq = 0.0;
    double *rdm1a_private = malloc(((sizeof(double)) * norb) * norb);
    double *rdm1b_private = malloc(((sizeof(double)) * norb) * norb);
    double *rdm2aa_private = malloc(((((sizeof(double)) * norb) * norb) * norb) * norb);
    double *rdm2ab_private = malloc(((((sizeof(double)) * norb) * norb) * norb) * norb);
    double *rdm2bb_private = malloc(((((sizeof(double)) * norb) * norb) * norb) * norb);
    for (p = 0; p < (norb * norb); ++p)
    {
      rdm1a_private[p] = 0.0;
      rdm1b_private[p] = 0.0;
    }

    for (p = 0; p < (((norb * norb) * norb) * norb); ++p)
    {
      rdm2aa_private[p] = 0.0;
      rdm2ab_private[p] = 0.0;
      rdm2bb_private[p] = 0.0;
    }

    #pragma omp for schedule(static)
    for (ip = 0; ip < ndet; ++ip)
    {
      for (jp = 0; jp < ndet; ++jp)
      {
        uint64_t *stria = strs + ((ip * 2) * nset);
        uint64_t *strib = (strs + ((ip * 2) * nset)) + nset;
        uint64_t *strja = strs + ((jp * 2) * nset);
        uint64_t *strjb = (strs + ((jp * 2) * nset)) + nset;
        int n_excit_a = n_excitations(stria, strja, nset);
        int n_excit_b = n_excitations(strib, strjb, nset);
        if (ip == jp)
        {
          int *occsa = compute_occ_list(stria, nset, norb, neleca);
          int *occsb = compute_occ_list(strib, nset, norb, nelecb);
          ci_sq = civec[ip] * civec[ip];
          for (p = 0; p < neleca; ++p)
          {
            int k = occsa[p];
            int kk = (k * norb) + k;
            rdm1a_private[kk] += ci_sq;
          }

          for (p = 0; p < nelecb; ++p)
          {
            int k = occsb[p];
            int kk = (k * norb) + k;
            rdm1b_private[kk] += ci_sq;
          }

          for (p = 0; p < neleca; ++p)
          {
            int k = occsa[p];
            for (q = 0; q < neleca; ++q)
            {
              int j = occsa[q];
              int kjkj = (((((k * norb) * norb) * norb) + ((j * norb) * norb)) + (k * norb)) + j;
              int kjjk = (((((k * norb) * norb) * norb) + ((j * norb) * norb)) + (j * norb)) + k;
              rdm2aa_private[kjkj] += ci_sq;
              rdm2aa_private[kjjk] -= ci_sq;
            }

            for (q = 0; q < nelecb; ++q)
            {
              int j = occsb[q];
              int kjkj = (((((k * norb) * norb) * norb) + ((j * norb) * norb)) + (k * norb)) + j;
              rdm2ab_private[kjkj] += ci_sq;
            }

          }

          for (p = 0; p < nelecb; ++p)
          {
            int k = occsb[p];
            for (q = 0; q < nelecb; ++q)
            {
              int j = occsb[q];
              int kjkj = (((((k * norb) * norb) * norb) + ((j * norb) * norb)) + (k * norb)) + j;
              int kjjk = (((((k * norb) * norb) * norb) + ((j * norb) * norb)) + (j * norb)) + k;
              rdm2bb_private[kjkj] += ci_sq;
              rdm2bb_private[kjjk] -= ci_sq;
            }

          }

          free(occsa);
          free(occsb);
        }
        else
          if ((n_excit_a + n_excit_b) == 1)
        {
          int *ia;
          if (n_excit_b == 0)
          {
            ia = get_single_excitation(stria, strja, nset);
            int i = ia[0];
            int a = ia[1];
            double sign = compute_cre_des_sign(a, i, stria, nset);
            int *occsa = compute_occ_list(stria, nset, norb, neleca);
            int *occsb = compute_occ_list(strib, nset, norb, nelecb);
            ci_sq = (sign * civec[ip]) * civec[jp];
            rdm1a_private[(a * norb) + i] += ci_sq;
            for (p = 0; p < neleca; ++p)
            {
              int k = occsa[p];
              int akik = (((((a * norb) * norb) * norb) + ((k * norb) * norb)) + (i * norb)) + k;
              int akki = (((((a * norb) * norb) * norb) + ((k * norb) * norb)) + (k * norb)) + i;
              int kaki = (((((k * norb) * norb) * norb) + ((a * norb) * norb)) + (k * norb)) + i;
              int kaik = (((((k * norb) * norb) * norb) + ((a * norb) * norb)) + (i * norb)) + k;
              rdm2aa_private[akik] += ci_sq;
              rdm2aa_private[akki] -= ci_sq;
              rdm2aa_private[kaik] -= ci_sq;
              rdm2aa_private[kaki] += ci_sq;
            }

            for (p = 0; p < nelecb; ++p)
            {
              int k = occsb[p];
              int akik = (((((a * norb) * norb) * norb) + ((k * norb) * norb)) + (i * norb)) + k;
              rdm2ab_private[akik] += ci_sq;
            }

            free(occsa);
            free(occsb);
          }
          else
            if (n_excit_a == 0)
          {
            ia = get_single_excitation(strib, strjb, nset);
            int i = ia[0];
            int a = ia[1];
            double sign = compute_cre_des_sign(a, i, strib, nset);
            int *occsa = compute_occ_list(stria, nset, norb, neleca);
            int *occsb = compute_occ_list(strib, nset, norb, nelecb);
            ci_sq = (sign * civec[ip]) * civec[jp];
            rdm1b_private[(a * norb) + i] += ci_sq;
            for (p = 0; p < nelecb; ++p)
            {
              int k = occsb[p];
              int akik = (((((a * norb) * norb) * norb) + ((k * norb) * norb)) + (i * norb)) + k;
              int akki = (((((a * norb) * norb) * norb) + ((k * norb) * norb)) + (k * norb)) + i;
              int kaki = (((((k * norb) * norb) * norb) + ((a * norb) * norb)) + (k * norb)) + i;
              int kaik = (((((k * norb) * norb) * norb) + ((a * norb) * norb)) + (i * norb)) + k;
              rdm2bb_private[akik] += ci_sq;
              rdm2bb_private[akki] -= ci_sq;
              rdm2bb_private[kaik] -= ci_sq;
              rdm2bb_private[kaki] += ci_sq;
            }

            for (p = 0; p < neleca; ++p)
            {
              int k = occsa[p];
              int kaki = (((((k * norb) * norb) * norb) + ((a * norb) * norb)) + (k * norb)) + i;
              rdm2ab_private[kaki] += ci_sq;
            }

            free(occsa);
            free(occsb);
          }


          free(ia);
        }
        else
          if ((n_excit_a + n_excit_b) == 2)
        {
          int i;
          int j;
          int a;
          int b;
          if (n_excit_b == 0)
          {
            int *ijab = get_double_excitation(stria, strja, nset);
            i = ijab[0];
            j = ijab[1];
            a = ijab[2];
            b = ijab[3];
            double sign;
            int baij = (((((b * norb) * norb) * norb) + ((a * norb) * norb)) + (i * norb)) + j;
            int baji = (((((b * norb) * norb) * norb) + ((a * norb) * norb)) + (j * norb)) + i;
            int abij = (((((a * norb) * norb) * norb) + ((b * norb) * norb)) + (i * norb)) + j;
            int abji = (((((a * norb) * norb) * norb) + ((b * norb) * norb)) + (j * norb)) + i;
            if ((a > j) || (i > b))
            {
              sign = compute_cre_des_sign(b, i, stria, nset);
              sign *= compute_cre_des_sign(a, j, stria, nset);
              ci_sq = (sign * civec[ip]) * civec[jp];
              rdm2aa_private[baij] += ci_sq;
              rdm2aa_private[baji] -= ci_sq;
              rdm2aa_private[abij] -= ci_sq;
              rdm2aa_private[abji] += ci_sq;
            }
            else
            {
              sign = compute_cre_des_sign(b, j, stria, nset);
              sign *= compute_cre_des_sign(a, i, stria, nset);
              ci_sq = (sign * civec[ip]) * civec[jp];
              rdm2aa_private[baij] -= ci_sq;
              rdm2aa_private[baji] += ci_sq;
              rdm2aa_private[abij] += ci_sq;
              rdm2aa_private[abji] -= ci_sq;
            }

            free(ijab);
          }
          else
            if (n_excit_a == 0)
          {
            int *ijab = get_double_excitation(strib, strjb, nset);
            i = ijab[0];
            j = ijab[1];
            a = ijab[2];
            b = ijab[3];
            double v;
            double sign;
            int baij = (((((b * norb) * norb) * norb) + ((a * norb) * norb)) + (i * norb)) + j;
            int baji = (((((b * norb) * norb) * norb) + ((a * norb) * norb)) + (j * norb)) + i;
            int abij = (((((a * norb) * norb) * norb) + ((b * norb) * norb)) + (i * norb)) + j;
            int abji = (((((a * norb) * norb) * norb) + ((b * norb) * norb)) + (j * norb)) + i;
            if ((a > j) || (i > b))
            {
              sign = compute_cre_des_sign(b, i, strib, nset);
              sign *= compute_cre_des_sign(a, j, strib, nset);
              ci_sq = (sign * civec[ip]) * civec[jp];
              rdm2bb_private[baij] += ci_sq;
              rdm2bb_private[baji] -= ci_sq;
              rdm2bb_private[abij] -= ci_sq;
              rdm2bb_private[abji] += ci_sq;
            }
            else
            {
              sign = compute_cre_des_sign(b, j, strib, nset);
              sign *= compute_cre_des_sign(a, i, strib, nset);
              ci_sq = (sign * civec[ip]) * civec[jp];
              rdm2bb_private[baij] -= ci_sq;
              rdm2bb_private[baji] += ci_sq;
              rdm2bb_private[abij] += ci_sq;
              rdm2bb_private[abji] -= ci_sq;
            }

            free(ijab);
          }
          else
          {
            int *ia = get_single_excitation(stria, strja, nset);
            int *jb = get_single_excitation(strib, strjb, nset);
            i = ia[0];
            a = ia[1];
            j = jb[0];
            b = jb[1];
            double sign = compute_cre_des_sign(a, i, stria, nset);
            sign *= compute_cre_des_sign(b, j, strib, nset);
            ci_sq = (sign * civec[ip]) * civec[jp];
            int abij = (((((a * norb) * norb) * norb) + ((b * norb) * norb)) + (i * norb)) + j;
            rdm2ab_private[abij] += ci_sq;
            free(ia);
            free(jb);
          }


        }



      }

    }

    {
      for (p = 0; p < (norb * norb); ++p)
      {
        rdm1a[p] += rdm1a_private[p];
        rdm1b[p] += rdm1b_private[p];
      }

      for (p = 0; p < (((norb * norb) * norb) * norb); ++p)
      {
        rdm2aa[p] += rdm2aa_private[p];
        rdm2ab[p] += rdm2ab_private[p];
        rdm2bb[p] += rdm2bb_private[p];
      }

    }
    free(rdm1a_private);
    free(rdm1b_private);
    free(rdm2aa_private);
    free(rdm2ab_private);
    free(rdm2bb_private);
  }
}

