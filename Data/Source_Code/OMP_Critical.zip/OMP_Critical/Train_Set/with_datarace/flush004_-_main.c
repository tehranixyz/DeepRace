static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int a;
int b;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  clear();
  #pragma omp parallel
  {
    a = 0;
    #pragma omp barrier
    if (omp_get_thread_num() == 0)
    {
      waittime(1);
      a = 1;
      #pragma omp barrier
    }
    else
    {
      #pragma omp barrier
      if (a == 0)
      {
        errors += 1;
      }

    }

    #pragma omp barrier
  }
  clear();
  #pragma omp parallel
  func_flush();
  if (errors == 0)
  {
    printf("flush 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("flush 004 : FAILED\n");
    return 1;
  }

}

