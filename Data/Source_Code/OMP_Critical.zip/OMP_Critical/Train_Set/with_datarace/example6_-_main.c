int main(int argc, char *argv[])
{
  int i;
  int acum;
  int j;
  double ms;
  printf("Starting...\n");
  ms = 0;
  for (j = 0; j <= N; j++)
  {
    start_timer();
    acum = 0;
    #pragma omp parallel for private(i) shared(acum)
    for (i = 1; i <= 100000; i++)
    {
      acum = acum + i;
    }

    ms += stop_timer();
  }

  printf("acum = %i\n", acum);
  printf("avg time = %.5lf\n", ms / N);
  return 0;
}

