int variavel_global = 0;
void soma_id(void)
{
  int *vals;
  int size;
};
struct stack
{
  int ***list;
  int size;
  int capacity;
};
struct queue
{
  int ***list;
  int start;
  int size;
  int capacity;
};
int **solveSudoku(int **input)
{
  struct queue *q = malloc(sizeof(struct queue));
  initQueue(q);
  pushQueue(q, makeCopy(input));
  int r_num;
  int c_num;
  int i;
  if (SIZE <= 9)
    thread_count = 1;
  else
    if ((SIZE <= 16) && (thread_count >= 2))
    thread_count = 2;
  else
    if ((SIZE > 16) && (thread_count >= 4))
    thread_count = 4;



  while ((q->size < thread_count) && (!isEmptyQueue(q)))
  {
    int **curr = popQueue(q);
    int break1 = 0;
    for (r_num = 0; r_num < SIZE; r_num++)
    {
      for (c_num = 0; c_num < SIZE; c_num++)
      {
        if (curr[r_num][c_num] == 0)
        {
          long long possible_vals = getPossibleValues(curr, r_num, c_num);
          for (i = 0; i < SIZE; i++)
          {
            if (possible_vals & (1 << i))
            {
              int **curr_child = makeCopy(curr);
              curr_child[r_num][c_num] = i + 1;
              pushQueue(q, curr_child);
            }

          }

          break1 = 1;
          break;
        }

      }

      if (break1)
        break;

    }

  }

  omp_set_num_threads(thread_count);
  #pragma omp parallel for
  for (i = 0; i < q->size; i++)
  {
    int **temp;
    int found = 0;
    #pragma omp critical
    {
      if (global_output)
      {
        found = 1;
      }

    }
    if (!found)
    {
      temp = solveSudokuRec(q->list[(i + q->start) % q->capacity]);
      #pragma omp critical
      if (isValid(input, temp))
        global_output = temp;

    }

  }

  if (!global_output)
    global_output = input;

  return global_output;

  int my_rank = omp_get_thread_num();
  int thread_count = omp_get_num_threads();
  variavel_global += my_rank;
}

