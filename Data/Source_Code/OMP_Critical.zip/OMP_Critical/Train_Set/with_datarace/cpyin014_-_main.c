static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int org[1024];
int prvt[1024];
#pragma omp threadprivate(prvt);
int main()
{
  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  for (i = 0; i < 1024; i++)
  {
    prvt[i] = (org[i] = i - 1);
  }

  #pragma omp parallel copyin (prvt) private(i)
  {
    for (i = 0; i < 1024; i++)
    {
      if (prvt[i] != org[i])
      {
        errors += 1;
      }

    }

    if ((sizeof(prvt)) != ((sizeof(int)) * 1024))
    {
      errors += 1;
    }

  }
  for (i = 0; i < 1024; i++)
  {
    prvt[i] = (org[i] = i);
  }

  #pragma omp parallel copyin (prvt) private(i)
  {
    for (i = 0; i < 1024; i++)
    {
      if (prvt[i] != org[i])
      {
        errors += 1;
      }

    }

    if ((sizeof(prvt)) != ((sizeof(int)) * 1024))
    {
      errors += 1;
    }

  }
  for (i = 0; i < 1024; i++)
  {
    prvt[i] = (org[i] = i + 1);
  }

  #pragma omp parallel copyin (prvt) private(i)
  {
    for (i = 0; i < 1024; i++)
    {
      if (prvt[i] != org[i])
      {
        errors += 1;
      }

    }

    if ((sizeof(prvt)) != ((sizeof(int)) * 1024))
    {
      errors += 1;
    }

  }
  if (errors == 0)
  {
    printf("copyin 014 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("copyin 014 : FAILED\n");
    return 1;
  }

}

