int main()
{
  const int N = 100;
  const int ITERATIONS = 10;
  unsigned int arr[N];
  int i;
  int iter;
  unsigned int result;
  struct timeval start;
  struct timeval stop;
  for (i = 0; i < N; i++)
  {
    arr[i] = i;
  }

  iter = 0;
  gettimeofday(&start, 0);
  while ((iter++) < ITERATIONS)
  {
    result = 0;
    #pragma omp parallel for
    for (i = 0; i < N; i++)
    {
      result += arr[i];
    }

  }

  gettimeofday(&stop, 0);
  double total_time = timer_to_sec(start, stop);
  printf("Result: %i, which took %fs to compute all iterations.\nPer iteration: %f\n", result, total_time, total_time / ITERATIONS);
}

