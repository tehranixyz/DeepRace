int inicial[7][7] = {{0, 0, 1, 1, 1, 0, 0}, {0, 0, 1, 1, 1, 0, 0}, {1, 1, 1, 1, 1, 1, 1}, {1, 1, 1, 2, 1, 1, 1}, {1, 1, 1, 1, 1, 1, 1}, {0, 0, 1, 1, 1, 0, 0}, {0, 0, 1, 1, 1, 0, 0}};
int alvo[7][7] = {{0, 0, 2, 2, 2, 0, 0}, {0, 0, 2, 2, 2, 0, 0}, {2, 2, 2, 2, 2, 2, 2}, {2, 2, 2, 1, 2, 2, 2}, {2, 2, 2, 2, 2, 2, 2}, {0, 0, 2, 2, 2, 0, 0}, {0, 0, 2, 2, 2, 0, 0}};
struct nodo
{
  int valor;
  int estado[7][7];
  struct nodo *proximo;
};
int pulaDown(int origemX, int origemY, Nodo *nodo, Nodo *I[], Nodo *E[])
{
  if ((origemX > 1) && (origemX <= 6))
  {
    if ((nodo->estado[origemX - 1][origemY] == 1) && (nodo->estado[origemX - 2][origemY] == 1))
    {
      Nodo *filho;
      {
        filho = criar_nodo(nodo->estado, nodo, valor(nodo->estado));
      }
      filho->estado[origemX][origemY] = 1;
      filho->estado[origemX - 1][origemY] = 2;
      filho->estado[origemX - 2][origemY] = 2;
      filho->valor = valor(filho->estado);
      if (valida(I, filho->estado) == 1)
      {
        insere_ordenado(filho, E);
        return 1;
      }

    }

  }

  return -1;
}

