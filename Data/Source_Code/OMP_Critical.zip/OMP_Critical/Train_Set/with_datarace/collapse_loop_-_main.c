extern void dsrand(unsigned int);
extern double drand();
{
  double real;
  double imag;
} Compl;
Compl lowerLeft;
Compl upperRight;
int MAX_ITERATE = 20000;
double threshold = 2.0;
double stride = 0.001;
int main(int argc, char *argv)
{
  uint64_t seed;
  Compl z;
  Compl c;
  Compl tmp;
  int i;
  int j;
  int N1;
  int N0;
  double etime0;
  double etime1;
  double cptime;
  double A;
  double r;
  int n;
  lowerLeft.real = -2.0;
  lowerLeft.imag = 0;
  upperRight.real = 0.5;
  upperRight.imag = 1.125;
  omp_set_dynamic(0);
  #pragma omp parallel
  dsrand(12345);
  N1 = (N0 = 0);
  timing(&etime0, &cptime);
  #pragma omp parallel firstprivate(j, n, c, z, tmp, stride) shared(i, N0, N1, lowerLeft, upperRight, threshold, MAX_ITERATE)
  #pragma omp for schedule(static, 10) collapse(2)
  for (i = 0; i < ((int) ((upperRight.real - lowerLeft.real) / stride)); i++)
  {
    for (j = 0; j < ((int) ((upperRight.imag - lowerLeft.imag) / stride)); j++)
    {
      if (((i == 0) && (j == 0)) && (omp_get_thread_num() == 0))
        printf("Threads: %d\n", omp_get_num_threads());

      c.real = lowerLeft.real + ((drand() + i) * stride);
      c.imag = lowerLeft.imag + ((drand() + j) * stride);
      z = c;
      for (n = 0; n < MAX_ITERATE; n++)
      {
        multiply(&z, &c, &tmp);
        z = tmp;
        if (lengthsq(&z) > (threshold * threshold))
        {
          break;
        }

      }

      if (n == MAX_ITERATE)
      {
        N1++;
      }
      else
      {
        N0++;
      }

    }

  }

  timing(&etime1, &cptime);
  A = (((2.0 * N1) / (N0 + N1)) * (upperRight.real - lowerLeft.real)) * (upperRight.imag - lowerLeft.imag);
  printf("area is %f, time elapsed is %f, total cell: %d\n", A, etime1 - etime0, N1 + N0);
}

