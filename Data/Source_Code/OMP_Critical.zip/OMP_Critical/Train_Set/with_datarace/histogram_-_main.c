void Gen_data(float min_meas, float max_meas, float data[], int data_count);
void Gen_bins(float min_meas, float max_meas, float bin_maxes[], int bin_counts[], int bin_count);
int Which_bin(float data, float bin_maxes[], int bin_count, float min_meas);
void print_histogram(float bin_maxes[], int bin_counts[], int bin_count, float min_meas);
int main(int argc, char *argv[])
{
  int thread_count;
  int bin_count;
  int i;
  int bin;
  float min_meas;
  float max_meas;
  float *bin_maxes;
  int *bin_counts;
  int data_count;
  float *data;
  bin_count = strtol(argv[1], 0, 10);
  min_meas = strtof(argv[2], 0);
  max_meas = strtof(argv[3], 0);
  data_count = strtol(argv[4], 0, 10);
  thread_count = strtol(argv[5], 0, 10);
  bin_maxes = malloc(bin_count * (sizeof(float)));
  bin_counts = malloc(bin_count * (sizeof(int)));
  data = malloc(data_count * (sizeof(float)));
  Gen_data(min_meas, max_meas, data, data_count);
  Gen_bins(min_meas, max_meas, bin_maxes, bin_counts, bin_count);
  #pragma omp parallel for num_threads(thread_count) default(none) shared(data_count, data, bin_maxes, bin_count, min_meas, bin_counts) private(bin, i)
  for (i = 0; i < data_count; i++)
  {
    bin = Which_bin(data[i], bin_maxes, bin_count, min_meas);
    bin_counts[bin]++;
  }

  print_histogram(bin_maxes, bin_counts, bin_count, min_meas);
  free(data);
  free(bin_maxes);
  free(bin_counts);
  return 0;
}

