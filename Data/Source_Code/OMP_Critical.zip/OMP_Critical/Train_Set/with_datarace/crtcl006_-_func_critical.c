static char rcsid[] = "$Id$";
int thds;
int errors = 0;
int data;
void func_critical()
{
  int id = omp_get_thread_num();
  int i;
  #pragma omp barrier
  switch (id)
  {
    case 0:
    {
      i = read_data();
      waittime(1);
      write_data(i + 1);
    }
      break;

    case 1:
    {
      i = read_data();
      waittime(1);
      write_data(i + 1);
    }
      break;

    case 2:
    {
      i = read_data();
      waittime(1);
      write_data(i + 1);
    }
      break;

    case 3:
    {
      i = read_data();
      waittime(1);
      write_data(i + 1);
    }
      break;

    default:
      break;

  }

}

