void work()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  shrd = 0;
  #pragma omp parallel default(shared)
  {
    #pragma omp critical
    {
      shrd += 1;
    }
  }
  if (shrd != thds)
  {
    errors += 1;
  }

  if (errors == 0)
  {
    printf("default 001 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("default 001 : FAILED\n");
    return 1;
  }


  int i;
  i = 10;
  #pragma omp task shared(i)
  {
    int tid;
    tid = omp_get_thread_num();
    printf("In Task %d, i = %d\n", tid, i);
  }
  #pragma omp taskwait
}

