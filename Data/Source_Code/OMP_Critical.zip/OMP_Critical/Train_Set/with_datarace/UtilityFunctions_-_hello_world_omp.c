void hello_world_omp()
{
  printf("Welcome to hello world with OMP!\n");
  #pragma omp parallel default(none)
  {
    {
      printf("Hello from thread %d out of %d\n", omp_get_thread_num(), omp_get_num_threads());
    }
  }
}

