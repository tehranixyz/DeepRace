void parallel_min(float *min_out, float *X, int N, int col)
{
  int j;
  *min_out = FLT_MAX;
  int index;
  #pragma omp parallel shared(X,min_out,N) private(j)
  {
    float min = FLT_MAX;
    #pragma omp for schedule(guided) nowait
    for (j = 0; j < N; j++)
    {
      index = (j * DIM) + col;
      if (min > X[index])
      {
        min = X[index];
      }

    }

    {
      if (min < (*min_out))
        *min_out = min;

    }
  }
}

