static char rcsid[] = "$Id$";
int errors = 0;
int thds;
struct x
{
  int i;
  double d;
};
struct x prvt;
void func1(int magicno, struct x *prvt)
{
  int id = omp_get_thread_num();
  if (prvt->i != magicno)
  {
    errors += 1;
  }

  if (prvt->d != (magicno + 1))
  {
    errors += 1;
  }

  prvt->i = id;
  prvt->d = id - 1;
  #pragma omp barrier
  if (prvt->i != id)
  {
    errors += 1;
  }

  if (prvt->d != (id - 1))
  {
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(struct x)))
  {
    errors += 1;
  }

}

