int games;
{
  char num_dice;
  char triple;
  char face[6];
} dice_t;
{
  int cutoff;
  long long *inplay_throws;
  long long *inplay_points;
  long long *inplay_duds;
  int *turns;
} args_s;
long long max_turns;
long long min_turns;
int max_cutoff;
int min_cutoff;
int totalturns;
long long *cutoffturns;
int *finished_games;
long long *total_inplay_throws;
long long *total_inplay_points;
long long *total_inplay_duds;
void *play_game_wrapper(int games, int mincutoff, int maxcutoff, int num_threads)
{
  omp_set_num_threads(num_threads);
  int current_cutoff = mincutoff;
  int current_game = 0;
  int current_game_tag = 0;
  int my_cutoff;
  int my_game_number;
  int my_game_index;
  int thread_id;
  long long inplay_duds[7];
  long long inplay_throws[7];
  long long inplay_points[7];
  #pragma omp parallel private(my_cutoff, my_game_number, my_game_index, thread_id, inplay_duds, inplay_throws, inplay_points) shared(games, maxcutoff, current_cutoff, current_game, current_game_tag, cutoffturns, finished_games, total_inplay_throws, total_inplay_points, total_inplay_duds, max_turns, min_turns, max_cutoff, min_cutoff)
  {
    thread_id = omp_get_thread_num();
    #pragma omp while
    while (1)
    {
      {
        my_cutoff = current_cutoff;
        my_game_number = current_game;
        current_game += 1;
        my_game_index = current_game_tag;
        if (current_game == games)
        {
          current_game = 0;
          current_cutoff += 50;
          current_game_tag = (current_game_tag + 1) % num_threads;
          cutoffturns[current_game_tag] = 0;
          finished_games[current_game_tag] = 0;
        }

      }
      if (my_cutoff > maxcutoff)
      {
        break;
      }

      for (int i = 1; i < 7; i++)
      {
        inplay_duds[i] = 0;
        inplay_throws[i] = 0;
        inplay_points[i] = 0;
      }

      int turns = play_game(my_cutoff, inplay_throws, inplay_points, inplay_duds, &thread_id);
      {
        for (int i = 1; i < 7; i++)
        {
          total_inplay_throws[i] += inplay_throws[i];
          total_inplay_points[i] += inplay_points[i];
          total_inplay_duds[i] += inplay_duds[i];
        }

        cutoffturns[my_game_index] += turns;
        finished_games[my_game_index] += 1;
        if (finished_games[my_game_index] == games)
        {
          if (cutoffturns[my_game_index] > max_turns)
          {
            max_turns = cutoffturns[my_game_index];
            max_cutoff = my_cutoff;
          }
          else
            if (cutoffturns[my_game_index] < min_turns)
          {
            min_turns = cutoffturns[my_game_index];
            min_cutoff = my_cutoff;
          }


        }

      }
    }

  }
  return 0;
}

