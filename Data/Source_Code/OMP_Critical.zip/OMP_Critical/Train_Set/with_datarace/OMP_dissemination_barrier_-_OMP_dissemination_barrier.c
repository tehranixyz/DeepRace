int NUM_THREADS;
int NUM_BARRIERS;
{
  HsStablePtr globalDataPtr;
  int *intArrays[2000];
  int referenceResult[2000];
  int taskResult[2000];
  unsigned int execTasksCurrent[1000];
  unsigned int execTasks[10000][1000];
  int counterValue;
  void (*counterFunction)(HsStablePtr ptr, int val);
} gl_taskData;
static int task_exec_count = 0;
void task1(unsigned int index);
void generateExecTasks();
void runTasks_1(int);
void runTasks_2(int);
void runTasks_3(int);
void runTasks_4(int);
void counterFunctionCSide(HsStablePtr ptr, int val);
void counterFunctionLockedCSide(HsStablePtr ptr, int val);
void initExecTaskCurrent(int);
void initArrays();
static int issue_count = 0;
void task1(unsigned int value)
{
  int *ptr = gl_taskData.intArrays[value];
  int result = 0;
  int end = 1000 / 10;
  int dataOrig[1000 / 10];
  int data[1000 / 10];
  {
    #pragma omp critical
    memcpy(data, ptr, (sizeof(int)) * (1000 / 10));
  }
  memcpy(dataOrig, data, (sizeof(int)) * (1000 / 10));
  for (int i = 0; i < end; i++)
  {
    data[i] = data[i] + data[(end - i) - 1];
    result += data[i];
  }

  for (int i = 0; i < end; i++)
  {
    if (0)
    {
      ptr[i] = data[i];
    }
    else
    {
      int success = __sync_bool_compare_and_swap(ptr + i, dataOrig[i], data[i]);
      if (!success)
      {
        {
          #pragma omp atomic write
          issue_count = +1;
        }
      }

    }

  }

  int *resultLoc = &gl_taskData.taskResult[value];
  {
    #pragma omp atomic write
    *resultLoc = result;
  }
  (*gl_taskData.counterFunction)(gl_taskData.globalDataPtr, ptr[0]);

  int myflags[2][10000];
  int *partnerflags[2][10000];
} flags;
flags *allnodes;
void OMP_dissemination_barrier(int *sense, int *parity)
{
  int round;
  int total_rounds;
  int thread_id = omp_get_thread_num();
  if (thread_id == 0)
  {
  }

  flags *localflags = allnodes + thread_id;
  total_rounds = ceil(log(NUM_THREADS) / log(2));
  for (round = 0; round < total_rounds; round++)
  {
    {
      *localflags->partnerflags[*parity][round] = *sense;
    }
    while (localflags->myflags[*parity][round] != (*sense))
      ;

  }

  if ((*parity) == 1)
  {
    *sense = !(*sense);
  }

  *parity = 1 - (*parity);
}

