int n;
int k;
double dunn = 0.0;
int no_of_clusters;
double **data;
double **center_array;
int *output;
void main(int argc, char **argv)
{
  double *grad_st_tmp = calloc(nH * (dim + 1), sizeof(double));
  double *aGamma = malloc((dim * nH) * (sizeof(double)));
  double *bGamma = malloc(nH * (sizeof(double)));
  int dimnH = dim * nH;
  int i;
  int j;
  int k;
  double factor = 1 / gamma;
  double *gridLocal = malloc(dim * (sizeof(double)));
  double epsCalcExp = -25;
  double TermALocal;
  double TermBLocal;
  for (k = 0; k < dim; k++)
  {
    gridLocal[k] = grid[k];
  }

  for (i = 0; i < nH; i++)
  {
    for (j = 0; j < dim; j++)
    {
      aGamma[i + (j * nH)] = gamma * a[i + (j * nH)];
    }

    bGamma[i] = gamma * b[i];
    influence[i] = 0;
  }

  for (i = 0; i < (nH * (dim + 1)); i++)
  {
    gradA[i] = 0;
    gradB[i] = 0;
  }

  TermALocal = 0;
  *TermA = 0;
  #pragma omp parallel num_threads(NUMCORES)
  {
    double ftInnerMax;
    double sum_ft;
    double sum_ft_inv;
    double *ft = calloc(nH, sizeof(double));
    double *ftInner = calloc(nH, sizeof(double));
    double *grad_ft_private = calloc(nH * (dim + 1), sizeof(double));
    int *idxElements = malloc(nH * (sizeof(int)));
    int numElements;
    int idxSave;
    double ftTmp;
    #pragma omp for schedule(dynamic) private(i,k) reduction(+:TermALocal)
    for (j = 0; j < N; j++)
    {
      ftInnerMax = -DBL_MAX;
      numElements = 0;
      for (i = 0; i < nH; i++)
      {
        ftTmp = bGamma[i] + (aGamma[i] * X[j]);
        for (k = 1; k < dim; k++)
        {
          ftTmp += aGamma[i + (k * nH)] * X[j + (k * N)];
        }

        if (ftTmp > (ftInnerMax - 25))
        {
          if (ftTmp > ftInnerMax)
          {
            ftInnerMax = ftTmp;
          }

          ftInner[numElements] = ftTmp;
          idxElements[numElements++] = i;
        }

      }

      sum_ft = 0;
      for (i = 0; i < numElements; i++)
      {
        ft[i] = exp(ftInner[i] - ftInnerMax);
        sum_ft += ft[i];
      }

      TermALocal += (XW[j] * (ftInnerMax + log(sum_ft))) * factor;
      sum_ft_inv = (1 / sum_ft) * XW[j];
      for (i = 0; i < numElements; i++)
      {
        idxSave = idxElements[i];
        for (k = 0; k < dim; k++)
        {
          grad_ft_private[idxSave + (k * nH)] += (ft[i] * X[j + (k * N)]) * sum_ft_inv;
        }

        grad_ft_private[idxSave + (dim * nH)] += ft[i] * sum_ft_inv;
      }

    }

    #pragma omp critical
    {
      for (i = 0; i < (nH * (dim + 1)); i++)
      {
        gradA[i] += grad_ft_private[i];
      }

    }
    free(ft);
    free(ftInner);
    free(grad_ft_private);
    free(idxElements);
  }
  *TermA = TermALocal;
  TermBLocal = 0;
  *TermB = 0;
  #pragma omp parallel num_threads(NUMCORES)
  {
    double *Ytmp = calloc(dim, sizeof(double));
    double stInnerMax;
    double stInnerCorrection = 0;
    double sum_st;
    double sum_st_inv;
    double tmpVal;
    double sum_st_inv2;
    double *st = calloc(nH, sizeof(double));
    double *stInner = calloc(nH, sizeof(double));
    double *grad_st_private = calloc(nH * (dim + 1), sizeof(double));
    double *influencePrivate = calloc(nH, sizeof(double));
    int *idxElements = malloc(nH * (sizeof(int)));
    int numElements;
    int idxSave;
    double stTmp;
    #pragma omp for schedule(dynamic) private(i,k) reduction(+:TermBLocal)
    for (j = 0; j < M; j++)
    {
      stInnerMax = -DBL_MAX;
      numElements = 0;
      for (k = 0; k < dim; k++)
      {
        Ytmp[k] = gridLocal[k] + (delta[k] * YIdx[k + (j * dim)]);
      }

      for (i = 0; i < nH; i++)
      {
        stTmp = bGamma[i] + (aGamma[i] * Ytmp[0]);
        for (k = 1; k < dim; k++)
        {
          stTmp += aGamma[i + (k * nH)] * Ytmp[k];
        }

        if (stTmp > (stInnerMax - 25))
        {
          if (stTmp > stInnerMax)
          {
            stInnerMax = stTmp;
          }

          stInner[numElements] = stTmp;
          idxElements[numElements++] = i;
        }

      }

      sum_st = 0;
      for (i = 0; i < numElements; i++)
      {
        st[i] = exp(stInner[i] - stInnerMax);
        sum_st += st[i];
      }

      stInnerCorrection = exp((-stInnerMax) * factor);
      tmpVal = pow(sum_st, -factor) * stInnerCorrection;
      TermBLocal += tmpVal;
      sum_st_inv2 = 1 / sum_st;
      sum_st_inv = tmpVal * sum_st_inv2;
      for (i = 0; i < numElements; i++)
      {
        idxSave = idxElements[i];
        influencePrivate[idxSave] += st[i] * sum_st_inv2;
        st[i] *= sum_st_inv;
        grad_st_private[idxSave] += Ytmp[0] * st[i];
        for (k = 1; k < dim; k++)
        {
          grad_st_private[idxSave + (k * nH)] += Ytmp[k] * st[i];
        }

        grad_st_private[idxSave + dimnH] += st[i];
      }

    }

    #pragma omp critical
    {
      for (i = 0; i < nH; i++)
      {
        influence[i] += influencePrivate[i];
      }

      for (i = 0; i < (nH * (dim + 1)); i++)
      {
        grad_st_tmp[i] += grad_st_private[i];
      }

    }
    free(Ytmp);
    free(st);
    free(stInner);
    free(grad_st_private);
    free(influencePrivate);
    free(idxElements);
  }
  *TermB = TermBLocal * weight;
  for (i = 0; i < (nH * (dim + 1)); i++)
  {
    gradB[i] -= grad_st_tmp[i] * weight;
  }

  free(grad_st_tmp);
  free(gridLocal);
  free(aGamma);
  free(bGamma);

  no_of_clusters = 22;
  int iterations = 10;
  int i;
  int j;
  int x;
  double input_start = omp_get_wtime();
  takeDataInput();
  double input_stop = omp_get_wtime();
  double center_start = omp_get_wtime();
  chooseCenterPointsRandom();
  double center_stop = omp_get_wtime();
  double distance;
  double min_distance;
  int rank;
  int max_threads;
  double cluster_start = omp_get_wtime();
  do
  {
    #pragma omp parallel shared(output,no_of_clusters,center_array,max_threads,data,k,n) private(i,j,x,rank,distance,min_distance) default(none)
    {
      rank = omp_get_thread_num();
      max_threads = omp_get_num_threads();
      for (i = rank; i < n; i += max_threads)
      {
        min_distance = 32767;
        for (x = 0; x < no_of_clusters; x++)
        {
          distance = 0.0;
          for (j = 0; j < k; j++)
          {
            distance += (center_array[x][j] - data[i][j]) * (center_array[x][j] - data[i][j]);
          }

          distance = sqrt(distance);
          if (distance < min_distance)
          {
            min_distance = distance;
            output[i] = x;
          }

        }

        for (j = 0; j < k; j++)
        {
          center_array[output[i]][j] = (center_array[output[i]][j] + data[i][j]) / 2.0;
        }

      }

    }
    iterations--;
  }
  while (iterations > 0);
  #pragma omp for
  for (i = 0; i < n; i++)
    output[i]++;

  double cluster_stop = omp_get_wtime();
  dunn = Dunn_index();
  for (i = 0; i < n; i++)
  {
    if (i != (n - 1))
      printf("%d, ", output[i]);
    else
      printf("%d\n", output[i]);

  }

}

