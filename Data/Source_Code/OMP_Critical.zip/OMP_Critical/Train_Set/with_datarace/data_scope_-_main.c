void main()
{
  int a = 1;
  int b = 2;
  printf("shared(a,b)\n");
  #pragma omp parallel shared(a,b)
  {
    a++;
    b++;
    printf("a=%d b=%d\n", a, b);
  }
  printf("----------------------------\n");
  printf("a=%d b=%d\n", a, b);
  printf("----------------------------\n");
  printf("private(a)\n");
  #pragma omp parallel private(a)
  {
    a++;
    {
      b++;
    }
    printf("a=%d b=%d\n", a, b);
  }
  printf("----------------------------\n");
  printf("a=%d b=%d\n", a, b);
  printf("----------------------------\n");
  printf("firstprivate(a) private(b)\n");
  #pragma omp parallel firstprivate(a) private(b)
  {
    a++;
    b++;
    printf("a=%d b=%d\n", a, b);
  }
  printf("----------------------------\n");
  printf("a=%d b=%d\n", a, b);
  printf("----------------------------\n");
  int i;
  printf("lastprivate(a) firstprivate(b)\n");
  #pragma omp parallel for lastprivate(a) firstprivate(b)
  for (i = 0; i < 4; i++)
  {
    a = i;
    b++;
    printf("a=%d b=%d i=%d\n", a, b, i);
  }

  printf("----------------------------\n");
  printf("a=%d b=%d\n", a, b);
  printf("----------------------------\n");
}

