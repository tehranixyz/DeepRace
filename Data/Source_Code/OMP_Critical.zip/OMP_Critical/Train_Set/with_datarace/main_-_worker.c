void worker(double x_start, double x_end, int num_bins, double *result)
{
  int comm_sz = atoi(argv[2]);
  char *pEnd;
  int N = strtol(argv[1], &pEnd, 10);
  int localN = N / comm_sz;
  double *shared = (double *) malloc(((2 * comm_sz) - 2) * (sizeof(double)));
  int end = 120;
  if ((N % comm_sz) != 0)
  {
    printf("ERROR N must be divisible by comm_sz. Terminating.");
    exit(1);
  }

  if (localN < 2)
  {
    printf("ERROR N (%d) must be at least twice as large as number of processes (%d). Terminating.", N, comm_sz);
    exit(1);
  }

  #pragma omp parallel num_threads(comm_sz)
  {
    double *f0 = (double *) malloc(localN * (sizeof(double)));
    double *f1 = (double *) malloc(localN * (sizeof(double)));
    double *f2 = (double *) malloc(localN * (sizeof(double)));
    double *temp;
    int my_rank = omp_get_thread_num();
    double localx0 = ((1.0 / (N - 1)) * my_rank) * localN;
    int i;
    #pragma omp for
    for (i = 0; i < N; i++)
    {
      double x = localx0 + ((((double) i) * 1.0) / (N - 1));
      f0[i] = sin(3.14159265358979323846 * x);
      f1[i] = sin(3.14159265358979323846 * x);
    }

    if (my_rank == 0)
    {
      f0[0] = 0;
      f1[0] = 0;
      f2[0] = 0;
    }

    if (my_rank == (omp_get_num_threads() - 1))
    {
      f0[localN - 1] = 0;
      f1[localN - 1] = 0;
      f2[localN - 1] = 0;
    }

    double leftNeighbor = 0;
    double rightNeighbor = 0;
    int step = 2;
    while (step <= end)
    {
      int i;
      for (i = 1; i < (localN - 2); i++)
      {
        f2[i] = ((0.01 * ((f1[i - 1] - (2 * f1[i])) + f1[i + 1])) + (2 * f1[i])) - f0[i];
      }

      #pragma omp critical
      {
        if (my_rank != 0)
        {
          *(shared + ((my_rank * 2) - 1)) = *f1;
          printf("Left val %lf by thread %d\n", *f1, my_rank);
        }

        if (my_rank != (comm_sz - 1))
        {
          *(shared + (my_rank * 2)) = *(f1 + (localN - 1));
          printf("Right val %lf by thread %d\n", *(f1 + (localN - 1)), my_rank);
        }

      }
      if (my_rank != 0)
      {
        int i = 0;
        leftNeighbor = *(shared + ((my_rank * 2) - 2));
        f2[i] = ((0.01 * ((leftNeighbor - (2 * f1[i])) + f1[i + 1])) + (2 * f1[i])) - f0[i];
      }

      if (my_rank != (comm_sz - 1))
      {
        int i = localN - 1;
        rightNeighbor = *(shared + ((my_rank * 2) + 1));
        f2[i] = ((0.01 * ((f1[i - 1] - (2 * f1[i])) + rightNeighbor)) + (2 * f1[i])) - f0[i];
      }

      if (my_rank == 0)
      {
      }

      temp = f0;
      f0 = f1;
      f1 = f2;
      f2 = temp;
      step++;
    }

  }
  return 0;

  double local_result = 0.0;
  double local_start;
  double local_end;
  double local_interval;
  double x;
  int i;
  int local_bins;
  int rank = omp_get_thread_num();
  int num_threads = omp_get_num_threads();
  local_interval = (x_end - x_start) / num_bins;
  local_bins = num_bins / num_threads;
  local_start = x_start + ((rank * local_bins) * local_interval);
  local_end = local_start + (local_bins * local_interval);
  if (rank == (num_threads - 1))
  {
    local_end = x_end;
    local_bins = local_bins + (num_bins - (local_bins * num_threads));
  }

  x = 0.0;
  for (i = 0; i < local_bins; i++)
  {
    double start;
    double end;
    start = local_start + (local_interval * i);
    end = start + local_interval;
    local_result += (0.5 * (curve(start) + curve(end))) * local_interval;
  }

  printf("Thread: %d, interval: %lf, bins: %d, start: %lf, end: %lf, result: %lf\n", rank, local_interval, local_bins, local_start, local_end, local_result);
  *result += local_result;
}

