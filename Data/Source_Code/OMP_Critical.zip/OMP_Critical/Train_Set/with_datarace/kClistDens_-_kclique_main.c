{
  unsigned s;
  unsigned t;
} edge;
{
  unsigned node;
  unsigned deg;
} nodedeg;
{
  unsigned n;
  unsigned e;
  edge *edges;
  unsigned *rank;
} edgelist;
{
  unsigned n;
  unsigned e;
  edge *edges;
  unsigned *cd;
  unsigned *adj;
  unsigned core;
} graph;
{
  unsigned *n;
  unsigned **d;
  unsigned *adj;
  unsigned char *lab;
  unsigned **nodes;
  unsigned core;
} subgraph;
{
  unsigned key;
  unsigned value;
} keyvalue;
{
  unsigned n_max;
  unsigned n;
  unsigned *pt;
  keyvalue *kv;
} bheap;
unsigned *old = 0;
unsigned *new = 0;
#pragma omp threadprivate(new,old);
unsigned long long *ckdeg_p;
unsigned long long *ckdeg;
unsigned *ck_p;
#pragma omp threadprivate(ckdeg_p,ck_p);
unsigned long long kclique_main(unsigned char k, graph *g)
{
  unsigned i;
  unsigned long long n = 0;
  subgraph *sg;
  #pragma omp parallel private(sg,i) reduction(+:n)
  {
    sg = allocsub(g, k);
    #pragma omp for schedule(dynamic, 1) nowait
    for (i = 0; i < g->e; i++)
    {
      ck_p[k - 1] = g->edges[i].s;
      ck_p[k - 2] = g->edges[i].t;
      mksub(g, g->edges[i], sg, k);
      kclique_thread(k, k - 2, sg, &n);
    }

    free_subgraph(sg, k);
    #pragma omp single
    {
      bzero(ckdeg, g->n * (sizeof(unsigned long long)));
    }
    #pragma omp barrier
    {
      for (i = 0; i < g->n; i++)
      {
        ckdeg[i] += ckdeg_p[i];
      }

      bzero(ckdeg_p, g->n * (sizeof(unsigned long long)));
    }
  }
  return n;
}

