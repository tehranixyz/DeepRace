int main(int argc, char *argv[])
{
  int i = 0;
  int j = 0;
  int iam;
  int np = 1;
  int tBloque;
  int *vResultado;
  int aux;
  int **mA;
  int **mB;
  int **mC;
  np = atoi(argv[1]);
  tBloque = 120 / np;
  vResultado = (int *) malloc(120 * (sizeof(int)));
  mA = (int **) malloc(120 * (sizeof(int *)));
  mB = (int **) malloc(120 * (sizeof(int *)));
  mC = (int **) malloc(120 * (sizeof(int *)));
  for (i = 0; i < 120; i++)
  {
    mA[i] = (int *) malloc(120 * (sizeof(int)));
    mB[i] = (int *) malloc(120 * (sizeof(int)));
    mC[i] = (int *) malloc(120 * (sizeof(int)));
    for (j = 0; j < 120; j++)
    {
      mA[i][j] = rand() % 9;
      mA[i][j] = rand() % 9;
      mC[i][j] = 0;
    }

  }

  #pragma omp parallel num_threads(np) private(iam, i, j, aux) default(shared)
  {
    iam = omp_get_thread_num();
    for (i = 0; i < tMatrizF; i++)
    {
      aux = 0;
      aux += (mA[i][(iam * tBloque) + j] * mB[i][(iam * tBloque) + j]) + mA[i][(iam * tBloque) + j];
    }

    {
      vResultado[i] += aux;
    }
  }
}

