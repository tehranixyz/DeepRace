int main()
{
  int ix;
  double Scale;
  double LScale;
  double ssq;
  double Lssq;
  #pragma omp parallel
  {
    #pragma omp single
    printf("Number of threads is %d\n", 1);
  }
  Scale = 2.0;
  ssq = 1.0;
  printf("Before parallel region: Scale = %f ssq = %f\n", Scale, ssq);
  #pragma omp parallel default(none) private(ix,LScale,Lssq) shared(Scale,ssq)
  {
    int TID = 0;
    Lssq = 2.0 * TID;
    #pragma omp for
    for (ix = 1; ix < 10; ix++)
    {
      LScale = TID + ix;
    }

    printf("Thread %d computed LScale = %f\n", TID, LScale);
    {
      printf("Thread %d entered critical region\n", TID);
      if (Scale < LScale)
      {
        ssq = ((Scale / LScale) * ssq) + Lssq;
        Scale = LScale;
        printf("\tThread %d: Reset Scale to %f\n", TID, Scale);
      }
      else
      {
        ssq = ssq + ((LScale / Scale) * Lssq);
      }

      printf("\tThread %d: New value of ssq = %f\n", TID, ssq);
    }
  }
  printf("After parallel region: Scale = %f ssq = %f\n", Scale, ssq);
  return 0;
}

