void SRbarrier4(int *count, int *sense, int *local_sense, unsigned int *local_spin_count)
{
  *local_sense = !(*local_sense);
  {
    *count = (*count) - 1;
    if ((*count) == 0)
    {
      *count = omp_get_num_threads();
      *sense = *local_sense;
    }

  }
  while ((*sense) != (*local_sense))
  {
    *local_spin_count = (*local_spin_count) + 1;
  }

  ;
}

