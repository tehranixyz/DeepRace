double xold[101 + 2][101 + 2];
double xnew[101 + 2][101 + 2];
int main(int argc, char *argv[])
{
  double rtclock();
  double clkbegin;
  double clkend;
  double t;
  double thisdiff;
  double maxdiff;
  int i;
  int j;
  int iter;
  for (i = 0; i < (101 + 2); i++)
    xold[i][0] = (i * 50.0) / (101 + 1);

  for (i = 0; i < (101 + 2); i++)
    xold[i][101 + 1] = (((i + 101) + 1) * 50.0) / (101 + 1);

  for (j = 0; j < (101 + 2); j++)
    xold[0][j] = (j * 50.0) / (101 + 1);

  for (j = 0; j < (101 + 2); j++)
    xold[101 + 1][j] = (((j + 101) + 1) * 50.0) / (101 + 1);

  for (i = 1; i < (101 + 1); i++)
    for (j = 1; j < (101 + 1); j++)
    xold[i][j] = 0;


  clkbegin = rtclock();
  int done = 0;
  omp_set_dynamic(0);
  omp_set_num_threads(4);
  int num_threads = 0;
  iter = 0;
  maxdiff = 0;
  #pragma omp parallel private(i,j,thisdiff)
  {
    #pragma omp single
    num_threads = omp_get_num_threads();
    #pragma omp barrier
    int id = omp_get_thread_num();
    int start = ((101 / num_threads) * id) + 1;
    int end = ((101 / num_threads) * (id + 1)) + 1;
    if (id == (num_threads - 1))
      end = 101 + 1;

    do
    {
      double diff = 0;
      for (i = start; i < end; i++)
        for (j = 1; j < (101 + 1); j++)
      {
        double temp = 0.25 * (((xold[i - 1][j] + xold[i + 1][j]) + xold[i][j - 1]) + xold[i][j + 1]);
        xnew[i][j] = temp;
        if ((thisdiff = fabs(temp - xold[i][j])) > diff)
          diff = thisdiff;

      }


      if (diff > maxdiff)
        maxdiff = diff;

      #pragma omp barrier
      #pragma omp single
      if (maxdiff < 0.0000001)
      {
        clkend = rtclock();
        done = 1;
        printf("Solution converged in  %d iterations\n", iter + 1);
        printf("Solution at center of grid : %f\n", xnew[(101 + 1) / 2][(101 + 1) / 2]);
        t = clkend - clkbegin;
        printf("Base-Jacobi: %.1f MFLOPS; Time = %.3f sec; \n", ((((4.0 * 101) * 101) * (iter + 1)) / t) / 1000000, t);
      }
      else
      {
        maxdiff = 0;
        iter++;
      }

      for (i = start; i < end; i++)
        for (j = 1; j < (101 + 1); j++)
        xold[i][j] = xnew[i][j];


      #pragma omp barrier
    }
    while ((!done) && (iter < 1000000));
  }
}

