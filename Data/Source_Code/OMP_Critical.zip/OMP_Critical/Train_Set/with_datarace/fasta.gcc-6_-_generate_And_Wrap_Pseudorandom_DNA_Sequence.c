{
  char letter;
  float probability;
} nucleotide_info;
uint32_t seed = 42;
static void generate_And_Wrap_Pseudorandom_DNA_Sequence(const nucleotide_info nucleotides_Information[], const intnative_t number_Of_Nucleotides, const intnative_t number_Of_Characters_To_Create)
{
  float cumulative_Probabilities[number_Of_Nucleotides];
  float cumulative_Probability = 0.0;
  for (intnative_t i = 0; i < number_Of_Nucleotides; i++)
  {
    cumulative_Probability += nucleotides_Information[i].probability;
    cumulative_Probabilities[i] = cumulative_Probability * 139968;
  }

  char blocks[3][(60 * 1024) + 1024];
  intnative_t next_Block_To_Output = 0;
  intnative_t block_Statuses[3];
  for (intnative_t i = 0; i < 3; block_Statuses[i++] = -1)
    ;

  intnative_t current_Number_Of_Characters_To_Create = number_Of_Characters_To_Create;
  #pragma omp parallel for schedule(guided)
  for (intnative_t current_Block_Number = 0; current_Block_Number < (((number_Of_Characters_To_Create + (60 * 1024)) - 1) / (60 * 1024)); current_Block_Number++)
  {
    intnative_t block_To_Use;
    intnative_t block_Length;
    float pseudorandom_Numbers[60 * 1024];
    {
      block_To_Use = next_Block_To_Output;
      for (intnative_t i = 0; i < 3; i++, block_To_Use = (block_To_Use + 1) % 3)
      {
        if (block_Statuses[block_To_Use] == (-1))
          break;

      }

      while (block_Statuses[block_To_Use] == 0)
      {
        #pragma omp flush(block_Statuses)
      }

      output_Blocks(blocks, block_Statuses, &next_Block_To_Output, 3);
      block_Statuses[block_To_Use]++;
      block_Length = 60 * 1024;
      if (current_Number_Of_Characters_To_Create < (60 * 1024))
        block_Length = current_Number_Of_Characters_To_Create;

      current_Number_Of_Characters_To_Create -= block_Length;
      for (intnative_t pseudorandom_Number_Index = 0; pseudorandom_Number_Index < block_Length; pseudorandom_Numbers[pseudorandom_Number_Index++] = get_LCG_Pseudorandom_Number(139968))
        ;

    }
    char *line = blocks[block_To_Use];
    for (intnative_t column = 0, pseudorandom_Number_Index = 0; pseudorandom_Number_Index < block_Length; pseudorandom_Number_Index++)
    {
      const float r = pseudorandom_Numbers[pseudorandom_Number_Index];
      intnative_t count = 0;
      for (intnative_t i = 0; i < number_Of_Nucleotides; i++)
        if (cumulative_Probabilities[i] <= r)
        count++;


      line[column] = nucleotides_Information[count].letter;
      if ((++column) == 60)
      {
        column = 0;
        line += 60 + 1;
      }

    }

    block_Statuses[block_To_Use] = block_Length;
  }

  output_Blocks(blocks, block_Statuses, &next_Block_To_Output, 3);
}

