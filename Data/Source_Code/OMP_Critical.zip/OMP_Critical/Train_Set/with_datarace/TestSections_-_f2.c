int f2()
{
  int i;
  int tid;
  int sum = 0;
  for (i = 0; i < 10; ++i)
  {
    sum -= i;
    {
      tid = omp_get_thread_num();
      printf("In f2() with thread %d\n", tid);
    }
  }

  return sum;
}

