static int issorted(int *, int);
int bogosort(int *array, int size)
{
  if (array == 0)
    return 1;

  srand((unsigned) time(0));
  int *sorted = malloc(sizeof(int));
  *sorted = issorted(array, size);
  while (!(*sorted))
  {
    for (int i = 0; i < size; i++)
    {
      int index = 0;
      do
      {
        index = rand() % size;
      }
      while (index == i);
      {
        if (!(*sorted))
        {
          int temp = array[i];
          array[i] = array[index];
          array[index] = temp;
        }

        if (issorted(array, size))
        {
          *sorted = 1;
          break;
        }

      }
      #pragma omp cancel for
      #pragma omp cancellation point for
    }

  }

  return 0;

  double sum;
  double step;
  double x;
  double pi = 0;
  double t1;
  double t2;
  int i;
  int id;
  step = 1. / ((double) 1000000000);
  #pragma omp parallel private (id, x, sum)
  {
    int id;
    id = omp_get_thread_num();
    sum = 0.0;
    for (i = id; i < 1000000000; i = i + 8)
    {
      x = (i + 0.5) * step;
      sum += 4.0 / (1.0 + (x * x));
    }

    #pragma omp critical
    {
      pi += sum * step;
    }
  }
  printf(" numerical pi = %.15f \n", pi);
  printf(" analytical pi = %.15f \n", acos(-1.0));
  printf(" Error = %E \n", fabs(acos(-1.0) - pi));
  return 0;
}

