void f2(void)
{
  int i;
  int j = 0;
  #pragma omp parallel
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
    #pragma omp master
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp single
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp taskgroup
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp task
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp taskgroup
    #pragma omp task
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp taskgroup
    {
      #pragma omp task
      {
        #pragma omp task
        {
          #pragma omp cancellation point taskgroup
          #pragma omp cancel taskgroup
        }
      }
    }
    #pragma omp taskgroup
    {
      #pragma omp parallel
      {
        #pragma omp task
        {
          #pragma omp cancel taskgroup
          #pragma omp cancellation point taskgroup
        }
      }
      #pragma omp target
      {
        #pragma omp task
        {
          #pragma omp cancel taskgroup
          #pragma omp cancellation point taskgroup
        }
      }
      #pragma omp target
      #pragma omp teams
      #pragma omp distribute
      for (i = 0; i < 10; i++)
      {
        #pragma omp task
        {
          #pragma omp cancel taskgroup
          #pragma omp cancellation point taskgroup
        }
      }

      #pragma omp target data map(i)
      {
        #pragma omp task
        {
          #pragma omp cancel taskgroup
          #pragma omp cancellation point taskgroup
        }
      }
    }
    #pragma omp for
    for (i = 0; i < 10; i++)
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }

    #pragma omp for ordered
    for (i = 0; i < 10; i++)
      #pragma omp ordered

    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp sections
    {
      {
        #pragma omp cancel parallel
        #pragma omp cancel for
        #pragma omp cancel sections
        #pragma omp cancel taskgroup
        #pragma omp cancellation point parallel
        #pragma omp cancellation point for
        #pragma omp cancellation point sections
        #pragma omp cancellation point taskgroup
      }
      #pragma omp section
      {
        #pragma omp cancel parallel
        #pragma omp cancel for
        #pragma omp cancel sections
        #pragma omp cancel taskgroup
        #pragma omp cancellation point parallel
        #pragma omp cancellation point for
        #pragma omp cancellation point sections
        #pragma omp cancellation point taskgroup
      }
    }
    #pragma omp target data map(j)
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp target data map(j)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target teams
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp target teams distribute
  for (i = 0; i < 10; i++)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }

  #pragma omp for
  for (i = 0; i < 10; i++)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }

  #pragma omp for
  for (i = 0; i < 10; i++)
    #pragma omp target data map(j)

  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for
  for (i = 0; i < 10; i++)
    #pragma omp target

  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for ordered
  for (i = 0; i < 10; i++)
    #pragma omp ordered

  #pragma omp target data map(j)
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp for ordered
  for (i = 0; i < 10; i++)
    #pragma omp ordered

  #pragma omp target
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
  }
  #pragma omp sections
  {
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp sections
  {
    #pragma omp target data map(j)
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    #pragma omp target data map(j)
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp sections
  {
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
    #pragma omp section
    #pragma omp target
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
  #pragma omp task
  {
    #pragma omp cancel parallel
    #pragma omp cancel for
    #pragma omp cancel sections
    #pragma omp cancel taskgroup
    #pragma omp cancellation point parallel
    #pragma omp cancellation point for
    #pragma omp cancellation point sections
    #pragma omp cancellation point taskgroup
    #pragma omp taskgroup
    {
      #pragma omp cancel parallel
      #pragma omp cancel for
      #pragma omp cancel sections
      #pragma omp cancel taskgroup
      #pragma omp cancellation point parallel
      #pragma omp cancellation point for
      #pragma omp cancellation point sections
      #pragma omp cancellation point taskgroup
    }
  }
}

