int main(void)
{
  #pragma omp parallel
  {
    {
      sleep(1);
      printf("sleep end\n");
    }
  }
}

