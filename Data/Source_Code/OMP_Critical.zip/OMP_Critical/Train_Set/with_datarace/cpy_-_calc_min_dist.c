float calc_min_dist(float *image, int i_width, int i_height, float *template, int t_width)
{
  float min_dist = FLT_MAX;
  float curr_dist;
  int x_offset = (i_width - t_width) + 1;
  int y_offset = (i_height - t_width) + 1;
  int flip = 0;
  while (flip < 2)
  {
    for (int rotate = 0; rotate < 4; rotate++)
    {
      int y_off;
      int x_off;
      int y;
      int x;
      #pragma omp parallel for private(x_off, y_off, x, y, curr_dist)
      for (y_off = 0; y_off < y_offset; y_off++)
      {
        for (x_off = 0; x_off < x_offset; x_off++)
        {
          curr_dist = 0.0;
          for (y = 0; y < t_width; y++)
          {
            for (x = 0; x < t_width; x++)
            {
              curr_dist += pow(template[(y * t_width) + x] - image[((y + y_off) * i_width) + (x + x_off)], 2);
            }

          }

          {
            if (curr_dist < min_dist)
            {
              min_dist = curr_dist;
            }

            curr_dist = 0;
          }
        }

      }

      rotate_ccw_90(template, t_width);
    }

    flip_horizontal(template, t_width);
    flip++;
  }

  return min_dist;

  double start;
  double finish;
  double elapsed;
  GET_TIME(start);
  #pragma omp parallel num_threads(thread_count)
  {
    int i;
    int j;
    int block_size;
    int rank;
    int k = 0;
    double temp;
    double *local_y;
    block_size = m / thread_count;
    local_y = (double *) malloc(block_size * (sizeof(double)));
    rank = omp_get_thread_num();
    #pragma omp for
    for (i = 0; i < m; i++)
    {
      local_y[k] = 0.0;
      for (j = 0; j < n; j++)
      {
        temp = A[(i * n) + j] * x[j];
        local_y[k] += temp;
      }

      k++;
    }

    #pragma omp critical
    {
      int i;
      for (i = 0; i < block_size; i++)
      {
        y[i + (block_size * rank)] = local_y[i];
      }

    }
    free(local_y);
  }
  GET_TIME(finish);
  elapsed = finish - start;
  printf("Elapsed time = %e seconds\n", elapsed);
}

