int findMatches(int, int, int, int, int, float **);
float **createArray(int, int);
int findMatches(int rct, int cct, int max, int min, int verbose, float **rows)
{
  int sh_count = 0;
  int r;
  int c;
  #pragma omp parallel private(r,c) shared(sh_count) num_threads(8)
  {
    #pragma omp for
    for (r = 0; r < rct; r++)
    {
      for (c = 0; c < cct; c++)
      {
        if ((rows[r][c] <= max) && (rows[r][c] >= min))
        {
          if (verbose)
          {
            fprintf(stdout, "r=%d, cc=%d: %.6f (thread= %d)\n", r, c, rows[r][c], omp_get_thread_num());
          }

          {
            sh_count++;
          }
        }

      }

    }

  }
  return sh_count;
}

