int main(int argc, char **argv)
{
  int rank;
  char *host;
  MPI_Init(&argc, &argv);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  host = (char *) malloc(HOST_NAME_MAX * (sizeof(char)));
  gethostname(host, HOST_NAME_MAX);
  if (rank == 0)
    printf("MPI started\n");

  MPI_Barrier(MPI_COMM_WORLD);
  printf("Process with rank %d running on Node %s Core %d\n", rank, host, likwid_getProcessorId());
  fflush(stdout);
  MPI_Barrier(MPI_COMM_WORLD);
  if (rank == 0)
    printf("Enter OpenMP parallel region\n");

  MPI_Barrier(MPI_COMM_WORLD);
  #pragma omp parallel
  {
    int coreId = likwid_getProcessorId();
    {
      printf("Rank %d Thread %d running on core %d \n", rank, omp_get_thread_num(), coreId);
      fflush(stdout);
    }
  }
  sleep(2);
  MPI_Finalize();
}

