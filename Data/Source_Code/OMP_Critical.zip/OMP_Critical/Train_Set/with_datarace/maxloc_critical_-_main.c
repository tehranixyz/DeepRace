double x[214700000];
int main(int argc, char *argv[])
{
  double maxval = 0.0;
  int maxloc = 0;
  srand(time(0));
  int i;
  for (i = 0; i < 214700000; i++)
  {
    x[i] = (((((double) rand()) / 32767) * (((double) rand()) / 32767)) * (((double) rand()) / 32767)) * 1000;
  }

  for (i = 0; i < 214700000; i++)
  {
    if (x[i] > maxval)
    {
      maxval = x[i];
      maxloc = i;
    }

  }

  double maxval_1 = maxval;
  int maxloc_1 = maxloc;
  maxval = 0.0;
  maxloc = 0;
  double start_time;
  double run_time;
  start_time = omp_get_wtime();
  #pragma omp parallel for
  for (i = 0; i < 214700000; i++)
  {
    if (x[i] > maxval)
    {
      {
        #pragma omp flush(maxval, maxloc)
        if (x[i] > maxval)
        {
          maxval = x[i];
          maxloc = i;
        }

      }
    }

  }

  run_time = omp_get_wtime() - start_time;
  printf("maxloc computation in %f seconds\n", run_time);
  printf("maxval (omp)   = %f maxloc (omp)   = %d \n", maxval, maxloc);
  printf("maxval (s)     = %f maxloc (s)     = %d \n", maxval_1, maxloc_1);
  if (maxloc_1 != maxloc)
    printf("Test failed\n");

  return 0;
}

