int n;
int thread_num;
void countingsort(int *A, int *B, int n)
{
  int i;
  struct timeval start;
  struct timeval end;
  double delta;
  int *C = (int *) malloc(100 * (sizeof(int)));
  int *S = (int *) malloc(100 * (sizeof(int)));
  gettimeofday(&start, 0);
  #pragma omp parallel for shared(C) private(i)
  for (i = 0; i < 100; i++)
    C[i] = 0;

  #pragma omp parallel
  {
    int i;
    int *C_private = (int *) malloc(100 * (sizeof(int)));
    for (i = 0; i < 100; i++)
      C_private[i] = 0;

    #pragma omp for nowait
    for (i = 0; i < n; i++)
      C_private[A[i]]++;

    {
      for (i = 0; i < 100; i++)
        C[i] += C_private[i];

    }
  }
  S[0] = 0;
  for (i = 1; i < 100; i++)
  {
    C[i] = C[i] + C[i - 1];
    S[i] = C[i - 1] + 1;
  }

  #pragma omp parallel
  {
    int i;
    int id = omp_get_thread_num();
    int chunk = ceil(((float) 100) / ((float) thread_num));
    int start = id * chunk;
    int end = (id + 1) * chunk;
    if (end >= 100)
      end = 100 - 1;

    for (i = start; i <= end; i++)
    {
      int j;
      int s = S[i];
      int e = C[i];
      for (j = s; j <= e; j++)
        B[j] = i;

    }

  }
  gettimeofday(&end, 0);
  delta = ((((end.tv_sec - start.tv_sec) * 1000000u) + end.tv_usec) - start.tv_usec) / 1.e6;
  printf("%d %d %lf\n", thread_num, n, delta);
}

