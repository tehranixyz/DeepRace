static long GLOBAL_failcounter = 0;
void *FGNSRdbg_calloc(size_t c, size_t s)
{
  void *retval;
  {
    if ((GLOBAL_failcounter > 0) && ((--GLOBAL_failcounter) == 0))
      retval = 0;
    else
      retval = calloc(c, s);

  }
  return retval;
}

