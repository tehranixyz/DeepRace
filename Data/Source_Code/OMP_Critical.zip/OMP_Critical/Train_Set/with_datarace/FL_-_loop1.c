double a[729][729] = {0};
double b[729][729] = {0};
double c[729] = {0};
int jmax[729];
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void loop1(void)
{
  int i;
  int j;
  int Ars[4];
  int Arf[4];
  int Arnow[4];
  int Tid = 0;
  int Tid_max = 0;
  int Tnums = 0;
  int e = 0;
  double start = 0;
  double finish = 0;
  double chunk_size = 0.0;
  double chunk_size_temp = 0.0;
  double finish_state = 0.0;
  double gap = 0;
  double max_gap = 0;
  for (i = 0; i < 4; i++)
  {
    Arf[i] = (Ars[i] = (Arnow[i] = 0));
  }

  omp_set_num_threads(4);
  #pragma omp parallel default(none) private(max_gap ,i,j, Tid,Tid_max, Tnums, start, finish, gap, chunk_size, chunk_size_temp, finish_state) shared(a,b, Ars, Arf, Arnow)
  {
    chunk_size_temp = 0.0, finish_state = 0, chunk_size = 0.0, start = 0.0, finish = 0.0, i = 0, j = 0, gap = 0.0;
    Tid = omp_get_thread_num();
    Tnums = omp_get_num_threads();
    Ars[Tid] = (729 * Tid) / Tnums;
    Arf[Tid] = ((729 * (Tid + 1)) / Tnums) - 1;
    chunk_size_temp = (Arf[Tid] - Ars[Tid]) + 1;
    int e = 0;
    e = Ars[Tid];
    int work_done = 0;
    while (!work_done)
    {
      for (i = Ars[Tid]; i <= Arf[Tid]; i++)
      {
        chunk_size = ceil(chunk_size_temp / Tnums);
        chunk_size_temp -= chunk_size;
        while (chunk_size != 0)
        {
          for (j = 729 - 1; j > e; j--)
          {
            a[e][j] += cos(b[e][j]);
          }

          e++;
          Arnow[Tid]++;
          chunk_size--;
        }

      }

      {
        for (i = 0; i < 4; ++i)
        {
          max_gap = gap;
          gap = Arf[i] - Arnow[i];
          if (gap > max_gap)
          {
            max_gap = gap;
            Tid_max = i;
          }

        }

        if (max_gap > 1)
        {
          work_done = 1;
        }
        else
        {
          Ars[Tid] = Arnow[Tid_max] + (max_gap / 2);
          Arnow[Tid] = Ars[Tid];
          Arf[Tid] = Arf[Tid_max];
          Arf[Tid_max] = Ars[Tid];
          chunk_size_temp = (max_gap * Tid_max) / Tnums;
        }

      }
    }

  }
}

