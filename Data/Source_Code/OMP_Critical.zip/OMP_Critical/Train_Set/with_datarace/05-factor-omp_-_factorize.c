void factorize(unsigned long long value)
{
  unsigned long long temp = value;
  unsigned long long i;
  int end = (int) ceil(value / 2.0);
  #pragma omp parallel for num_threads(THREADS)
  for (i = 2; i <= end; i++)
  {
    printf("i: %lld\n", i);
    if (is_prime(i))
    {
      while ((temp % i) == 0)
      {
        printf("\t%llu\n", i);
        temp /= i;
      }

    }

  }

}

