double start_time;
double end_time;
int numWorkers;
int size;
int matrix[20000][20000];
void *Worker(void *);
{
  int max;
  int min;
  int max_row;
  int max_col;
  int min_row;
  int min_col;
} Data;
Data common_values[20000];
int main(int argc, char *argv[])
{
  int i;
  int j;
  long total = 0;
  size = (argc > 1) ? (atoi(argv[1])) : (20000);
  numWorkers = (argc > 2) ? (atoi(argv[2])) : (8);
  if (size > 20000)
    size = 20000;

  if (numWorkers > 8)
    numWorkers = 8;

  omp_set_num_threads(numWorkers);
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      matrix[i][j] = rand() % 99;
    }

  }

  Data own_values = {.max = INT_MIN, .min = 32767, .max_row = -1, .max_col = -1, .min_row = -1, .min_col = -1};
  Data results = {.max = INT_MIN, .min = 32767, .max_row = -1, .max_col = -1, .min_row = -1, .min_col = -1};
  start_time = omp_get_wtime();
  #pragma omp parallel for reduction (+:total) private(j) firstprivate(own_values) shared(results)
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      total += matrix[i][j];
      if (matrix[i][j] > own_values.max)
      {
        own_values.max = matrix[i][j];
        own_values.max_row = i;
        own_values.max_col = j;
      }

      if (matrix[i][j] < own_values.min)
      {
        own_values.min = matrix[i][j];
        own_values.min_row = i;
        own_values.min_col = j;
      }

    }

    {
      if (own_values.max > results.max)
      {
        results.max = own_values.max;
        results.max_row = own_values.max_row;
        results.max_col = own_values.max_col;
      }

      if (own_values.min < results.min)
      {
        results.min = own_values.min;
        results.min_row = own_values.min_row;
        results.min_col = own_values.min_col;
      }

    }
  }

  end_time = omp_get_wtime();
  printf("the total is %ld\n", total);
  printf("max is %d at matrix[%d][%d] its value is %d\n", results.max, results.max_row, results.max_col, matrix[results.max_row][results.max_col]);
  printf("min is %d at matrix[%d][%d] its value is %d\n", results.min, results.min_row, results.min_col, matrix[results.min_row][results.min_col]);
  printf("it took %g seconds\n", end_time - start_time);
}

