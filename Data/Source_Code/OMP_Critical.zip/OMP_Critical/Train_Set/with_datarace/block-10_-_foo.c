void foo(int i)
{
  int j;
  switch (i)
  {
    #pragma omp parallel
    {
      case 0:
        ;

    }
  }

  switch (i)
  {
    #pragma omp for
    for (j = 0; j < 10; ++j)
    {
      case 1:
        ;

    }

  }

  switch (i)
  {
    {
      case 2:
        ;

    }
  }

  switch (i)
  {
    #pragma omp master
    {
      case 3:
        ;

    }
  }

  switch (i)
  {
    #pragma omp sections
    {
      case 4:
        ;

      #pragma omp section
      {
        case 5:
          ;

      }
    }
  }

  switch (i)
  {
    #pragma omp ordered
    {
      default:
        ;

    }
  }


  int i;
  int n = 100;
  int arr[n];
  int maxi = -1;
  for (i = 0; i < n; i++)
    arr[i] = rand() % 100;

  arr[78] = 999;
  omp_set_num_threads(4);
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    if (arr[i] > maxi)
    {
      #pragma omp critical
      {
        if (arr[i] > maxi)
          maxi = arr[i];

        printf("critical %d\n", i);
      }
    }

  }

  printf("max = %d\n", maxi);
  return 0;
}

