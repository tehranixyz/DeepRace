static int graphics = 0;
static int window_number = -1;
static void display(int xsize, int ysize, double h[xsize + 2][ysize + 2])
{
  #pragma omp parallel for
  for (int i = 1; i <= xsize; i++)
    for (int j = 1; j <= ysize; j++)
  {
    unsigned int icolor;
    double color;
    color = (h[i][j] - 20.0) / (100.0 - 20.0);
    if (color < 0.0)
      color = 0.0;

    if (color > 1.0)
      color = 1.0;

    if (graphics)
    {
      {
        graphic_setRainbowColor(window_number, (double) color);
        graphic_drawPoint(window_number, i, j);
      }
    }

  }


  if (graphics)
    graphic_flush(window_number);


  int *array;
  int i;
  int Noofelements;
  int cur_max;
  int current_value;
  printf("Enter the number of elements\n");
  scanf("%d", &Noofelements);
  if (Noofelements <= 0)
  {
    printf("The array elements cannot be stored\n");
    exit(1);
  }

  array = (int *) malloc((sizeof(int)) * Noofelements);
  *array, i, Noofelements, cur_max, current_value;
  srand(65536);
  for (i = 0; i < Noofelements; i++)
    array[i] = rand();

  if (Noofelements == 1)
  {
    printf("The Largest Number In The Array is %d", array[0]);
    exit(1);
  }

  cur_max = 0;
  omp_set_num_threads(8);
  #pragma omp parallel for
  for (i = 0; i < Noofelements; i = i + 1)
  {
    if (array[i] > cur_max)
      #pragma omp critical

    if (array[i] > cur_max)
      cur_max = array[i];

  }

  current_value = array[0];
  for (i = 1; i < Noofelements; i++)
    if (array[i] > current_value)
    current_value = array[i];


  printf("The Input Array Elements Are \n");
  for (i = 0; i < Noofelements; i++)
    printf("\t%d", array[i]);

  printf("\n");
  if (current_value == cur_max)
    printf("\nThe Max Value Is Same From Serial And Parallel OpenMP Directive\n");
  else
  {
    printf("\nThe Max Value Is Not Same In Serial And Parallel OpenMP Directive\n");
    exit(1);
  }

  printf("\n");
  free(array);
  printf("\nThe Largest Number In The Given Array Is %d\n", cur_max);
}

