{
  double init;
  double end;
  struct task *next;
  struct task *prev;
} task;
{
  int size;
  struct task *front;
  struct task *tail;
} queue;
queue *q;
int terminated = 0;
int *idle;
task *receiveTask()
{
  task *t;
  {
    t = dequeue();
  }
  return t;
}

