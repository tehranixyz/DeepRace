int i;
int j;
double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
struct Data
{
  int i;
  int j;
  int c;
  int k;
  int tid;
  double timetick;
  double sumaLocal;
  double minLocal;
  double maxLocal;
  if (((argc != 3) || ((N = atoi(argv[1])) <= 0)) || ((T = atoi(argv[2])) <= 0))
  {
    printf("\nUsar: %s n t\n  n: Dimension de la matriz (nxn X nxn)\n  t: Cantidad de threads\n", argv[0]);
    exit(1);
  }

  R = (double *) malloc(((sizeof(double)) * N) * N);
  for (i = 0; i < 3; i++)
  {
    M[i] = (double *) malloc(((sizeof(double)) * N) * N);
  }

  M[0][0] = 1;
  M[0][1] = 2;
  M[0][2] = 3;
  M[0][3] = 4;
  M[0][4] = 5;
  M[0][5] = 6;
  M[0][6] = 7;
  M[0][7] = 8;
  M[0][8] = 9;
  M[0][9] = 10;
  M[0][10] = 11;
  M[0][11] = 12;
  M[0][12] = 13;
  M[0][13] = 14;
  M[0][14] = 15;
  M[0][15] = 16;
  M[1][0] = 17;
  M[1][1] = 21;
  M[1][2] = 25;
  M[1][3] = 29;
  M[1][4] = 18;
  M[1][5] = 22;
  M[1][6] = 26;
  M[1][7] = 30;
  M[1][8] = 19;
  M[1][9] = 23;
  M[1][10] = 27;
  M[1][11] = 31;
  M[1][12] = 20;
  M[1][13] = 24;
  M[1][14] = 28;
  M[1][15] = 32;
  M[2][0] = 33;
  M[2][1] = 37;
  M[2][2] = 41;
  M[2][3] = 45;
  M[2][4] = 34;
  M[2][5] = 38;
  M[2][6] = 42;
  M[2][7] = 46;
  M[2][8] = 35;
  M[2][9] = 39;
  M[2][10] = 43;
  M[2][11] = 47;
  M[2][12] = 36;
  M[2][13] = 40;
  M[2][14] = 44;
  M[2][15] = 48;
  min = 9999;
  max = -999;
  suma = 0;
  minLocal = 9999;
  maxLocal = -999;
  sumaLocal = 0;
  timetick = dwalltime();
  omp_set_num_threads(T);
  #pragma omp parallel private(tid,i,j,c,k) shared(M,R,min,max) firstprivate(sumaLocal,minLocal,maxLocal) reduction(+: suma)
  {
    tid = omp_get_thread_num();
    #pragma omp for
    for (i = 0; i < N; ++i)
    {
      for (j = 0; j < N; ++j)
      {
        R[(i * N) + j] = 0;
        if (M[0][(i * N) + j] < minLocal)
          minLocal = M[0][(i * N) + j];

        if (M[0][(i * N) + j] > maxLocal)
          maxLocal = M[0][(i * N) + j];

        if (M[1][(i * N) + j] < minLocal)
          minLocal = M[1][(i * N) + j];

        if (M[1][(i * N) + j] > maxLocal)
          maxLocal = M[1][(i * N) + j];

        sumaLocal += M[0][(i * N) + j] + M[1][(i * N) + j];
        for (c = 0; c < N; ++c)
        {
          R[(i * N) + j] += M[0][(i * N) + c] * M[1][c + (j * N)];
        }

      }

    }

    for (k = 2; k < 3; ++k)
    {
      if ((k % 2) == 1)
      {
        #pragma omp for
        for (i = 0; i < N; ++i)
        {
          for (j = 0; j < N; ++j)
          {
            R[(i * N) + j] = 0;
            if (M[k][(i * N) + j] < minLocal)
              minLocal = M[k][(i * N) + j];

            if (M[k][(i * N) + j] > maxLocal)
              maxLocal = M[k][(i * N) + j];

            sumaLocal += M[k][(i * N) + j];
            for (c = 0; c < N; ++c)
            {
              R[(i * N) + j] += M[0][(i * N) + c] * M[k][c + (j * N)];
            }

          }

        }

      }
      else
      {
        #pragma omp for
        for (i = 0; i < N; ++i)
        {
          for (j = 0; j < N; ++j)
          {
            M[0][(i * N) + j] = 0;
            if (M[k][(i * N) + j] < minLocal)
              minLocal = M[k][(i * N) + j];

            if (M[k][(i * N) + j] > maxLocal)
              maxLocal = M[k][(i * N) + j];

            sumaLocal += M[k][(i * N) + j];
            for (c = 0; c < N; ++c)
            {
              M[0][(i * N) + j] += R[(i * N) + c] * M[k][c + (j * N)];
            }

          }

        }

      }

    }

    #pragma omp critical(min)
    {
      if (minLocal < min)
        min = minLocal;

    }
    #pragma omp critical(max)
    {
      if (maxLocal > max)
        max = maxLocal;

    }
    suma = sumaLocal;
  }
  if ((3 % 2) == 1)
  {
    free(R);
    R = M[0];
  }

  escalar = pow((max - min) / (suma / ((N * N) * 3)), 3);
  #pragma omp parallel private(i,j) shared(R)
  {
    #pragma omp for
    for (i = 0; i < N; ++i)
    {
      for (j = 0; j < N; ++j)
      {
        R[(i * N) + j] *= escalar;
      }

    }

  }
  printf("\nTiempo en segundos %f\n", dwalltime() - timetick);
  printMatrix(R, "R", 0);
  free(R);
  for (i = 1; i < 3; i++)
  {
    free(M[i]);
  }

  return 0;

  int start;
  int end;
  int size;
};
struct Node
{
  struct Data *data;
  struct Node *next;
};
struct Q
{
  struct Node *front;
  struct Node *rear;
};
struct Data *nxt_chunk(struct Q *list[])
{
  struct Data *tempdat;
  struct Data *finaldat;
  int large = 0;
  int pos = -1;
  for (i = 0; i < 2; i++)
  {
    tempdat = peek(list[i]);
    if (tempdat != 0)
    {
      if (tempdat->size > large)
      {
        large = tempdat->size;
        pos = i;
      }

    }

  }

  if (pos != (-1))
  {
    {
      finaldat = deq(list[pos]);
    }
    return finaldat;
  }
  else
  {
    return 0;
  }

}

