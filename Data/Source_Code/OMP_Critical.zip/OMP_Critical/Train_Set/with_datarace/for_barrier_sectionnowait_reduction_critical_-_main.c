int main()
{
  double *dx;
  dx = (double *) calloc(n, sizeof(double));
  int i;
  int j;
  int k;
  int id;
  int jstart;
  int jstop;
  int dnp = n / p;
  double dxi;
  for (k = 0; k < maxit; k++)
  {
    double sum = 0.0;
    for (i = 0; i < n; i++)
    {
      dx[i] = b[i];
      #pragma omp parallel shared(A,x) private(id,j,jstart,jstop,dxi)
      {
        id = omp_get_thread_num();
        jstart = id * dnp;
        jstop = jstart + dnp;
        dxi = 0.0;
        for (j = jstart; j < jstop; j++)
          dxi += A[i][j] * x[j];

        #pragma omp critical
        dx[i] -= dxi;
      }
      dx[i] /= A[i][i];
      x[i] += dx[i];
      sum += (dx[i] >= 0.0) ? (dx[i]) : (-dx[i]);
    }

    printf("%4d : %e\n", k, sum);
    if (sum < epsilon)
      break;

  }

  *numit = k + 1;
  free(dx);

  int t0;
  int t1;
  int M = 1000;
  int N = 1000;
  double A[M][N];
  t0 = omp_get_wtime();
  for (int i = 0; i < M; ++i)
    for (int j = 0; j < N; ++j)
    A[i][j] = 0.0;


  t1 = omp_get_wtime();
  printf("time sans paralellisation  : %f\n", t1 - t0);
  t0 = omp_get_wtime();
  #pragma omp parallel for
  for (int i = 0; i < M; ++i)
    for (int j = 0; j < N; ++j)
    A[i][j] = 0.0;


  t1 = omp_get_wtime();
  printf("time avec paralellisation  : %f\n", t1 - t0);
  printf("\n\nExemple avec la directive Schedule()\n");
  M = 12;
  N = 12;
  long double B[N][M];
  int num_du_thread;
  int i;
  int j;
  #pragma omp parallel for ordered schedule(runtime) private(i, j, num_du_thread)
  for (i = 0; i < M; i++)
  {
    for (j = 0; j < N; j++)
      B[i][j] = 0.0;

    num_du_thread = omp_get_thread_num();
    printf("i = %d :: thread n° %d \n", i, num_du_thread);
  }

  printf("\n\nExemple avec la directive barrier \n");
  #pragma omp parallel
  {
    thread_num = omp_get_thread_num();
    #pragma omp single
    {
      printf("Single : je suis le 1er thread a entrer, mon numero de thread est %d\n", thread_num);
    }
    ;
    printf("region parralele : Bonjour je suis le thread n° %d\n, ", thread_num);
    #pragma omp barrier
    #pragma omp master
    {
      printf("Bonjour je suis le thread principale : mon numero est: %d ", thread_num);
    }
    ;
  }
  printf("\n\nExemple avec la directive nowait \n");
  #pragma omp parallel
  {
    thread_num = omp_get_thread_num();
    #pragma omp single nowait
    {
      printf("Single : hello depuis le thread n° %d\n", thread_num);
    }
    ;
    printf("region parallel : hello depuis le thread numero %d\n", thread_num);
    #pragma omp master
    {
      printf("master: hello depuis le thread n° %d\n", thread_num);
    }
    ;
  }
  ;
  printf("\n\nExemple avec la directive reduction \n");
  M = 10;
  a = 2;
  #pragma omp parallel
  {
    thread_num = omp_get_thread_num();
    #pragma omp for reduction(+:a)
    for (i = 0; i < M; i++)
    {
      a = a + 1;
    }

  }
  ;
  printf("a final = %d\n", a);
  printf("\n\nExemple avec la directive atomic\n");
  M = 10;
  a = 2;
  #pragma omp parallel
  {
    thread_num = omp_get_thread_num();
    #pragma omp for
    for (i = 0; i < M; i++)
    {
      #pragma omp atomic
      a += 1;
      printf("Thread numero %d \t a = %d\n", thread_num, a);
    }

  }
  ;
  printf("a final = %d\n", a);
  M = 10, a = 2;
  #pragma omp parallel
  {
    thread_num = omp_get_thread_num();
    #pragma omp for
    for (i = 0; i < M; i++)
    {
      a += 1;
      printf("Thread %d \t, a = %d\n", thread_num, a);
    }

  }
  ;
  printf("a final = %d\n", a);
  printf("\n\nExemple avec la directive sections \n");
  #pragma omp parallel sections num_threads(4)
  {
    printf("Hello from thread %d\n", omp_get_thread_num());
    #pragma omp section
    printf("Hello from thread %d\n", omp_get_thread_num());
  }
  printf("\n\nUn ature exemple avec la directive section\n\n");
  #pragma omp parallel sections
  {
    #pragma omp section
    {
      printf("Section 1 id = %d\n", omp_get_thread_num());
    }
    #pragma omp section
    {
      printf("Section 2 id = %d\n", omp_get_thread_num());
    }
    #pragma omp section
    {
      printf("Section 3 id = %d\n", omp_get_thread_num());
    }
  }
  ;
  int n = omp_get_num_procs();
  #pragma omp parallel
  {
    printf("Hello World !! \n");
  }
  ;
  printf("le nombre de coeur est %d, ", n);
}

