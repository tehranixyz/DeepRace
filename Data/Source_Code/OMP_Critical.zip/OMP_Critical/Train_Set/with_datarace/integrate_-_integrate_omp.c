const double PI = 3.14159265358979323846;
const double a = -4.0;
const double b = 4.0;
const int nsteps = 40000000;
double integrate_omp(double (*func)(double), double a, double b, int n)
{
  double h = (b - a) / n;
  double sum = 0.0;
  #pragma omp parallel
  {
    int nthreads = omp_get_num_threads();
    int threadid = omp_get_thread_num();
    int items_per_thread = n / nthreads;
    int lb = threadid * items_per_thread;
    int ub = (threadid == (nthreads - 1)) ? (n - 1) : ((lb + items_per_thread) - 1);
    for (int i = lb; i <= ub; i++)
    {
      double f = func(a + (h * (i + 0.5)));
      {
        sum += f;
      }
    }

  }
  sum *= h;
  return sum;
}

