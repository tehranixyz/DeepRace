int main(int argc, char **argv);
int *dijkstra_distance(int ohd[6][6]);
void find_nearest(int s, int e, int mind[6], int connected[6], int *d, int *v);
void init(int ohd[6][6]);
void timestamp(void);
void update_mind(int s, int e, int mv, int connected[6], int ohd[6][6], int mind[6]);
int *dijkstra_distance(int ohd[6][6])
{
  int *connected;
  int i;
  int i4_huge = 2147483647;
  int md;
  int *mind;
  int mv;
  int my_first;
  int my_id;
  int my_last;
  int my_md;
  int my_mv;
  int my_step;
  int nth;
  connected = (int *) malloc(6 * (sizeof(int)));
  connected[0] = 1;
  for (i = 1; i < 6; i++)
  {
    connected[i] = 0;
  }

  mind = (int *) malloc(6 * (sizeof(int)));
  for (i = 0; i < 6; i++)
  {
    mind[i] = ohd[0][i];
  }

  #pragma omp parallel private ( my_first, my_id, my_last, my_md, my_mv, my_step ) shared ( connected, md, mind, mv, nth, ohd )
  {
    my_id = omp_get_thread_num();
    nth = omp_get_num_threads();
    my_first = (my_id * 6) / nth;
    my_last = (((my_id + 1) * 6) / nth) - 1;
    #pragma omp single
    {
      printf("\n");
      printf("  P%d: Parallel region begins with %d threads\n", my_id, nth);
      printf("\n");
    }
    fprintf(stdout, "  P%d:  First=%d  Last=%d\n", my_id, my_first, my_last);
    for (my_step = 1; my_step < 6; my_step++)
    {
      #pragma omp single
      {
        md = i4_huge;
        mv = -1;
      }
      find_nearest(my_first, my_last, mind, connected, &my_md, &my_mv);
      {
        if (my_md < md)
        {
          md = my_md;
          mv = my_mv;
        }

      }
      #pragma omp barrier
      #pragma omp single
      {
        if (mv != (-1))
        {
          connected[mv] = 1;
          printf("  P%d: Connecting node %d.\n", my_id, mv);
        }

      }
      #pragma omp barrier
      if (mv != (-1))
      {
        update_mind(my_first, my_last, mv, connected, ohd, mind);
      }

      #pragma omp barrier
    }

    #pragma omp single
    {
      printf("\n");
      printf("  P%d: Exiting parallel region.\n", my_id);
    }
  }
  free(connected);
  return mind;
}

