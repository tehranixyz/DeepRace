extern int decode;
extern int latlon;
extern double *lat;
extern double *lon;
int f_stats(ARG0)
{
  double sum;
  double sum_wt;
  double wt;
  double min;
  double max;
  double t;
  int do_wt;
  int i;
  unsigned int n;
  if (mode == (-1))
  {
    latlon = (decode = 1);
  }
  else
    if (mode >= 0)
  {
    do_wt = lat != 0;
    sum = (wt = (sum_wt = 0.0));
    n = 0;
    #pragma omp parallel private(i,t)
    {
      double sum_thread;
      double sum_wt_thread;
      double wt_thread;
      double min_thread;
      double max_thread;
      int n_thread;
      max_thread = (min_thread = 0.0);
      sum_thread = 0.0;
      wt_thread = (sum_wt_thread = 0.0);
      n_thread = 0;
      if (do_wt)
      {
        #pragma omp for nowait
        for (i = 0; i < ndata; i++)
        {
          if (!UNDEFINED_VAL(data[i]))
          {
            {
              t = cos((3.14159265 / 180.0) * lat[i]);
              wt_thread += t;
              sum_wt_thread += data[i] * t;
            }
          }

        }

      }

      #pragma omp for nowait
      for (i = 0; i < ndata; i++)
      {
        if (!UNDEFINED_VAL(data[i]))
        {
          if ((n_thread++) == 0)
          {
            sum_thread = (min_thread = (max_thread = data[i]));
          }
          else
          {
            max_thread = (max_thread < data[i]) ? (data[i]) : (max_thread);
            min_thread = (min_thread > data[i]) ? (data[i]) : (min_thread);
            sum_thread += data[i];
          }

        }

      }

      {
        if (n_thread)
        {
          if (n == 0)
          {
            min = min_thread;
            max = max_thread;
          }
          else
          {
            min = (min > min_thread) ? (min_thread) : (min);
            max = (max < max_thread) ? (max_thread) : (max);
          }

          sum += sum_thread;
          wt += wt_thread;
          sum_wt += sum_wt_thread;
          n += n_thread;
        }

      }
    }
    if (n)
      sum /= n;

    sprintf(inv_out, "ndata=%u:undef=%u:mean=%lg:min=%lg:max=%lg", ndata, ndata - n, sum, min, max);
    if (wt > 0)
    {
      sum_wt = sum_wt / wt;
      inv_out += strlen(inv_out);
      sprintf(inv_out, ":cos_wt_mean=%lg", sum_wt);
    }

  }


  return 0;
}

