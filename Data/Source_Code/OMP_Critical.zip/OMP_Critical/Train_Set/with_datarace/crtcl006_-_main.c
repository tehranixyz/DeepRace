static char rcsid[] = "$Id$";
int thds;
int errors = 0;
int data;
int main()
{
  int i;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp for schedule(static,1) lastprivate (prvt)
    for (i = 0; i < thds; i++)
    {
      prvt = i;
      barrier(thds);
      if (prvt != i)
      {
        #pragma omp critical
        errors += 1;
      }

      if ((sizeof(prvt)) != (sizeof(char)))
      {
        #pragma omp critical
        errors += 1;
      }

      if (i == 0)
      {
        waittime(1);
      }

      prvt = i;
    }

    if (prvt != (thds - 1))
    {
      #pragma omp critical
      errors += 1;
    }

  }
  #pragma omp parallel
  func(thds);
  func(1);
  if (errors == 0)
  {
    printf("lastprivate 006 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("lastprivate 006 : FAILED\n");
    return 1;
  }


  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  clear();
  #pragma omp parallel
  {
    int id = omp_get_thread_num();
    int i;
    #pragma omp barrier
    switch (id)
    {
      case 0:
      {
        i = read_data();
        waittime(1);
        write_data(i + 1);
      }
        break;

      case 1:
      {
        i = read_data();
        waittime(1);
        write_data(i + 1);
      }
        break;

      case 2:
      {
        i = read_data();
        waittime(1);
        write_data(i + 1);
      }
        break;

      case 3:
      {
        i = read_data();
        waittime(1);
        write_data(i + 1);
      }
        break;

      default:
        break;

    }

  }
  check(thds);
  clear();
  #pragma omp parallel
  func_critical();
  check(thds);
  clear();
  func_critical();
  check(1);
  if (errors == 0)
  {
    printf("critical 006 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("critical 006 : FAILED\n");
    return 1;
  }

}

