float MonteCarloIntegration(int iterationNumber)
{
  double sum = 0;
  long long Volume = pow(10, 10);
  int threadNumber;
  int count = 0;
  int k = 1;
  int foo = pow(4, k);
  float integralValue_at_Iteration_c;
  float integralValue_at_Iteration_c_MinusOne;
  float error;
  double temp = 0;
  #pragma omp parallel for
  for (int c = 1; c <= iterationNumber; c++)
  {
    float *randVector = ArbitraryDimentionalRandomVectorInRange(-0.5, 0.5, 10);
    {
      sum += expLFunction(randVector);
      int threadNum;
      if (count == foo)
      {
        threadNum = omp_get_thread_num();
        if (omp_get_thread_num() == threadNum)
        {
          integralValue_at_Iteration_c = (1.0 / ((float) count)) * sum;
          error = fabs(integralValue_at_Iteration_c - temp);
          temp = integralValue_at_Iteration_c;
          printf("At iteration %d, the integral value is %f \n", count, integralValue_at_Iteration_c);
          printf("The error at iteration %d is %f \n", count, error);
          foo = pow(4, ++k);
        }

      }

      count++;
    }
    if (c > 1)
      continue;

    threadNumber = omp_get_num_threads();
  }

  printf("Total iterations: %d\n", count);
  printf("Total threads used: %d\n", threadNumber);
  return (1.0 / ((float) count)) * sum;
}

