static char rcsid[] = "$Id$";
int errors = 0;
int thds;
long long prvt;
void func1(int magicno, long long *prvt)
{
  #pragma omp critical
  shrd += 1;
  #pragma omp barrier
  if (shrd != thds)
  {
    #pragma omp critical
    errors += 1;
  }


  int id = omp_get_thread_num();
  if ((*prvt) != magicno)
  {
    errors += 1;
  }

  *prvt = id;
  #pragma omp barrier
  if ((*prvt) != id)
  {
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(long long)))
  {
    errors += 1;
  }

}

