extern const struct training_set ts;
extern const struct settings s;
extern const float ionenergies[];
extern const float affinities[];
void run_diff_evolution(struct subset * const ss)
{
  assert(ss != 0);
  if (s.verbosity >= VERBOSE_KAPPA)
    printf("DE Generating population of size %d\n", s.population_size);

  float *bounds = (float *) malloc((((ts.atom_types_count * 2) + 1) * 2) * (sizeof(float)));
  compute_parameters_bounds(bounds, 0);
  fill_ss(ss, s.population_size);
  generate_random_population(ss, bounds, s.population_size);
  de_ss = ss;
  if (s.verbosity >= VERBOSE_KAPPA)
    printf("DE Calculating charges and evaluating fitness function for whole population\n");

  int i = 0;
  #pragma omp parallel for num_threads(s.om_threads) default(shared) private(i)
  for (i = 0; i < ss->kappa_data_count; i++)
  {
    calculate_charges(ss, &ss->data[i]);
    calculate_statistics(ss, &ss->data[i]);
  }

  int minimized_initial = 0;
  int *good_indices = (int *) calloc(s.population_size, sizeof(int));
  for (i = 0; i < s.population_size; i++)
    good_indices[i] = -1;

  if (s.polish > 2)
  {
    if (s.verbosity >= VERBOSE_KAPPA)
      printf("DE minimizing part of population\n");

    minimized_initial = minimize_part_of_population(ss, good_indices);
  }

  if (minimized_initial == 0)
  {
    for (i = 0; i < s.population_size; i++)
      good_indices[i] = i;

    minimized_initial = s.population_size;
  }

  set_the_best(ss);
  int iter = 0;
  struct kappa_data *trial = (struct kappa_data *) malloc(sizeof(struct kappa_data));
  struct kappa_data *so_far_best = (struct kappa_data *) malloc(sizeof(struct kappa_data));
  kd_init(trial);
  trial->parent_subset = ss;
  kd_init(so_far_best);
  kd_copy_parameters(ss->best, so_far_best);
  calculate_charges(ss, so_far_best);
  calculate_statistics(ss, so_far_best);
  kd_print_results(so_far_best);
  if (s.polish > 2)
  {
    minimize_locally(so_far_best, 1000);
    calculate_charges(ss, so_far_best);
    calculate_statistics(ss, so_far_best);
    kd_print_results(so_far_best);
  }

  float mutation_constant = s.mutation_constant;
  int iters_with_evolution = 0;
  int condition = 1;
  int minimized = 0;
  #pragma omp parallel num_threads(s.om_threads) default(shared)
  {
    while (condition)
    {
      #pragma omp master
      condition = iter < s.om_iters;
      {
        #pragma omp master
        {
          iter++;
          if (s.verbosity >= VERBOSE_KAPPA)
          {
            if ((iter % 100) == 0)
              printf("\nDE iter %d evolve thread %d\n", iter, omp_get_thread_num());
            else
              printf(".");

          }

          int rand1 = good_indices[(int) floor(get_random_float(0, (float) minimized_initial))];
          int rand2 = good_indices[(int) floor(get_random_float(0, (float) minimized_initial))];
          struct kappa_data *a = &ss->data[rand1];
          struct kappa_data *b = &ss->data[rand2];
          if (s.dither)
            mutation_constant = get_random_float(0.5, 1);

          evolve_kappa(trial, so_far_best, a, b, bounds, mutation_constant, s.recombination_constant);
          iters_with_evolution++;
          calculate_charges(ss, trial);
          calculate_statistics(ss, trial);
          if (s.verbosity >= VERBOSE_KAPPA)
            printf("Trial stats %f %f %d\n", trial->full_stats.R_w, trial->full_stats.R2, is_quite_good(trial));

          {
            if (compare_and_set(trial, so_far_best))
            {
              calculate_charges(ss, so_far_best);
              calculate_statistics(ss, so_far_best);
              if (s.verbosity >= VERBOSE_KAPPA)
              {
                printf("\n");
                kd_print_results(so_far_best);
              }

            }

          }
        }
        if (((s.polish > 1) && is_quite_good(trial)) && ((s.om_threads == 0) || (omp_get_thread_num() != 0)))
        {
          minimized++;
          if (s.verbosity >= VERBOSE_KAPPA)
            printf("\nDE min thread %d\n", omp_get_thread_num());

          struct kappa_data *min_trial = (struct kappa_data *) malloc(sizeof(struct kappa_data));
          kd_init(min_trial);
          min_trial->parent_subset = ss;
          kd_copy_parameters(trial, min_trial);
          minimize_locally(min_trial, 500);
          calculate_charges(de_ss, min_trial);
          calculate_statistics(de_ss, min_trial);
          int cond = 0;
          cond = kd_sort_by_is_better(min_trial, trial) && compare_and_set(min_trial, so_far_best);
          if (cond)
          {
            calculate_charges(ss, so_far_best);
            calculate_statistics(ss, so_far_best);
            if (s.verbosity >= VERBOSE_KAPPA)
            {
              printf("\n");
              kd_print_results(so_far_best);
            }

          }

          kd_destroy(min_trial);
          free(min_trial);
        }

      }
    }

  }
  if (s.polish > 0)
    minimize_locally(so_far_best, 2000);

  kd_destroy(trial);
  free(trial);
  free(bounds);
  free(good_indices);
  kd_copy_parameters(so_far_best, ss->best);
  calculate_charges(ss, ss->best);
  calculate_statistics(ss, ss->best);
  if (s.verbosity >= VERBOSE_KAPPA)
  {
    printf("Out of %d iterations, we minimized %d trials.\n", s.om_iters, minimized);
  }

  kd_destroy(so_far_best);
  free(so_far_best);
}

