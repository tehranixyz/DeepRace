void periodic_move_node()
{
  int ii;
  int kk;
  int i;
  int j;
  int m;
  int n;
  int ic;
  int ef;
  int ddx = 1 / dx;
  double ef_inta;
  double ef_intb;
  double xposa;
  double xposb;
  double xposnewa;
  double xposnewb;
  double v_xa;
  double v_xnewa;
  double v_xb;
  double v_xnewb;
  double v_ya;
  double v_za;
  double v_yb;
  double v_zb;
  double Area1 = 0;
  double Area2 = 0;
  double Area3 = 0;
  double Area4 = 0;
  double pcn = .5 / ((double) ppc);
  double rho[Lx + 1];
  double pef[Lx + 1];
  omp_set_num_threads(20);
  for (ii = 1; ii < tt; ii++)
  {
    #pragma omp parallel default(shared) private(xposa,xposb,xposnewa,xposnewb,v_xa,v_xnewa,v_xb,v_xnewb,v_ya,v_za,v_yb,v_zb, ef_inta, ef_intb, i, j, kk, m, n)
    {
      int my_id = omp_get_thread_num();
      int num_threads = omp_get_num_threads();
      int my_num_elements = Npart / num_threads;
      int my_first_element = my_id * (Npart / num_threads);
      if (my_id == (num_threads - 1))
      {
        my_num_elements += Npart - (num_threads * (Npart / num_threads));
      }

      for (kk = my_first_element; kk < (my_first_element + my_num_elements); kk++)
      {
        xposa = Part_Matrix_A[ii - 1][kk][1];
        v_xa = Part_Matrix_A[ii - 1][kk][4];
        v_ya = Part_Matrix_A[ii - 1][kk][5];
        v_za = Part_Matrix_A[ii - 1][kk][6];
        i = floor(xposa);
        m = ceil(xposa);
        ef_inta = (((efield[ii - 1][m] - efield[ii - 1][i]) * (xposa - i)) * ddx) + efield[ii - 1][i];
        v_xnewa = v_xa - (ef_inta * dt);
        xposnewa = xposa + (v_xnewa * dt);
        Part_Matrix_A[ii][kk][0] = Part_Matrix_A[ii - 1][kk][0];
        Part_Matrix_A[ii][kk][1] = xposnewa;
        Part_Matrix_A[ii][kk][4] = v_xnewa;
        Part_Matrix_A[ii][kk][5] = v_ya;
        Part_Matrix_A[ii][kk][6] = v_za;
        if (Part_Matrix_A[ii][kk][1] < 0)
        {
          Part_Matrix_A[ii][kk][1] = Part_Matrix_A[ii][kk][1] + Lx;
        }

        if (Part_Matrix_A[ii][kk][1] > Lx)
        {
          Part_Matrix_A[ii][kk][1] = Part_Matrix_A[ii][kk][1] - Lx;
        }

        xposb = Part_Matrix_B[ii - 1][kk][1];
        v_xb = Part_Matrix_B[ii - 1][kk][4];
        v_yb = Part_Matrix_B[ii - 1][kk][5];
        v_zb = Part_Matrix_B[ii - 1][kk][6];
        j = floor(xposb);
        n = ceil(xposb);
        ef_intb = (((efield[ii - 1][n] - efield[ii - 1][j]) * (xposb - j)) * ddx) + efield[ii - 1][j];
        v_xnewb = v_xb - (ef_intb * dt);
        xposnewb = xposb + (v_xnewb * dt);
        Part_Matrix_B[ii][kk][0] = Part_Matrix_B[ii - 1][kk][0];
        Part_Matrix_B[ii][kk][1] = xposnewb;
        Part_Matrix_B[ii][kk][4] = v_xnewb;
        Part_Matrix_B[ii][kk][5] = v_yb;
        Part_Matrix_B[ii][kk][6] = v_zb;
        if (Part_Matrix_B[ii][kk][1] < 0)
        {
          Part_Matrix_B[ii][kk][1] = Part_Matrix_B[ii][kk][1] + Lx;
        }

        if (Part_Matrix_B[ii][kk][1] > Lx)
        {
          Part_Matrix_B[ii][kk][1] = Part_Matrix_B[ii][kk][1] - Lx;
        }

      }

    }
    #pragma omp parallel default(shared) private(i, j, kk, Area1, Area2, Area3, Area4, m, n)
    {
      int my_id = omp_get_thread_num();
      int num_threads = omp_get_num_threads();
      int my_num_elements = Npart / num_threads;
      int my_first_element = my_id * (Npart / num_threads);
      if (my_id == (num_threads - 1))
      {
        my_num_elements += Npart - (num_threads * (Npart / num_threads));
      }

      for (kk = my_first_element; kk < (my_first_element + my_num_elements); kk++)
      {
        i = floor(Part_Matrix_A[ii][kk][1]);
        m = ceil(Part_Matrix_A[ii][kk][1]);
        j = floor(Part_Matrix_B[ii][kk][1]);
        n = ceil(Part_Matrix_B[ii][kk][1]);
        Area1 = m - Part_Matrix_A[ii][kk][1];
        Area2 = Part_Matrix_A[ii][kk][1] - i;
        Area3 = n - Part_Matrix_B[ii][kk][1];
        Area4 = Part_Matrix_B[ii][kk][1] - j;
        {
          chargenodeA[ii][i] += Area1;
          chargenodeA[ii][m] += Area2;
          chargenodeB[ii][j] += Area3;
          chargenodeB[ii][n] += Area4;
        }
      }

    }
    chargenodeA[ii][0] = chargenodeA[ii][0] + chargenodeA[ii][Lx];
    chargenodeA[ii][Lx] = chargenodeA[ii][0];
    chargenodeB[ii][0] = chargenodeB[ii][0] + chargenodeB[ii][Lx];
    chargenodeB[ii][Lx] = chargenodeB[ii][0];
    for (ic = 0; ic <= Lx; ic++)
    {
      normchargenodeA[ii][ic] = pcn * chargenodeA[ii][ic];
      normchargenodeB[ii][ic] = pcn * chargenodeB[ii][ic];
      normdiff[ii][ic] = (1 - normchargenodeA[ii][ic]) - normchargenodeB[ii][ic];
      rho[ic] = normdiff[ii][ic];
    }

    if (((((ii == ((.2 * tt) - 1)) || (ii == ((.4 * tt) - 1))) || (ii == ((.6 * tt) - 1))) || (ii == ((.8 * tt) - 1))) || (ii == (tt - 1)))
    {
      printf("Timestep:\t%4d\n", ii + 1);
    }

    update_phi_field(rho);
    for (ef = 0; ef < Lx; ef++)
    {
      phi[ii][ef] = rho[ef];
      pef[ef] = phi[ii][ef];
    }

    update_E_field(pef);
    for (ef = 0; ef < Lx; ef++)
    {
      efield[ii][ef] = pef[ef];
    }

    phi[ii][Lx] = phi[ii][0];
    efield[ii][Lx] = efield[ii][0];
  }


  int label[10][10];
  int i;
  int j;
  int val;
  int counter;
  int flag;
  int T[50] = {0};
  int nthreads;
  int start;
  int size;
  int chunk;
  int key[10] = {0};
  counter = 0;
  nthreads = 3;
  #pragma omp parallel num_threads(3) default(shared) private(counter,tid,i,j,start,chunk,size)
  {
    key[0] = 1;
    tid = omp_get_thread_num();
    chunk = m / nthreads;
    size = chunk;
    start = tid * chunk;
    lock = 0;
    #pragma omp for schedule(static,chunk)
    for (i = 0; i < m; i++)
    {
      if (key[tid] == 1)
      {
        for (j = start; j < (start + chunk); j++)
        {
          if (matrix[i][j] == 0)
          {
            label[i][j] = 0;
          }
          else
          {
            val = fmask(label, matrix, m, n, i, j, T);
            if (val == 0)
            {
              #pragma omp critical
              counter++;
              T[counter] = counter;
              label[i][j] = counter;
            }
            else
            {
              label[i][j] = val;
              fassignT(T, label, m, n, i, j, val);
            }

          }

        }

        #pragma omp critical
        k = k + chunk;
        key[++lock] = 1;
      }

    }

  }
  flag = 1;
  while (flag)
  {
    for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)
      {
        if (matrix[i][j] != 0)
        {
          val = bmask(label, matrix, m, n, i, j, T);
          if ((val != 0) && (val < label[i][j]))
          {
            flag = 0;
            label[i][j] = val;
          }

          if (val != 0)
          {
            bassignT(T, label, m, n, i, j, val);
          }

        }

      }

    }

    for (i = 0; i < m; i++)
    {
      for (j = 0; j < n; j++)
      {
        if (matrix[i][j] != 0)
        {
          val = fmask(label, matrix, m, n, i, j, T);
          if ((val != 0) && (val < label[i][j]))
          {
            flag = 0;
            label[i][j] = val;
          }

          if (val != 0)
          {
            fassignT(T, label, m, n, i, j, val);
          }

        }

      }

    }

    flag = 1 - flag;
  }

  for (i = 0; i < m; i++)
  {
    for (j = 0; j < n; j++)
    {
      printf("%d ", label[i][j]);
    }

    printf("\n");
  }

}

