double dotp(double *x, double *y)
{
  double position;
  double velocity;
  double fitness;
  double pbest_pos;
  double pbest_fit;
} particle;
double w;
double c1;
double c2;
double max_v;
double max_pos;
double min_pos;
unsigned particle_cnt;
particle gbest;
int num;
particle *lbest;
particle *AllocateParticle();
void ParticleInit(particle *p);
void ParticleMove(particle *p);
void ParticleRelease(particle *p);
void ParticleDisplay(particle *p);
void ParticleMove(particle *p)
{
  unsigned i;
  double v;
  double pos;
  double ppos;
  double gpos;
  gpos = gbest.position;
  for (i = 0; i < particle_cnt; i++)
  {
    v = p[i].velocity;
    pos = p[i].position;
    ppos = p[i].pbest_pos;
    v = ((w * v) + ((c1 * (((double) rand()) / 32767)) * (ppos - pos))) + ((c2 * (((double) rand()) / 32767)) * (gpos - pos));
    if (v < (-max_v))
      v = -max_v;
    else
      if (v > max_v)
      v = max_v;


    pos = pos + v;
    if (pos > max_pos)
      pos = max_pos;
    else
      if (pos < min_pos)
      pos = min_pos;


    p[i].velocity = v;
    p[i].position = pos;
    p[i].fitness = fit(pos);
    if (p[i].fitness > p[i].pbest_fit)
    {
      p[i].pbest_fit = p[i].fitness;
      p[i].pbest_pos = p[i].position;
    }

    #pragma omp critical
    {
      if (p[i].fitness > gbest.fitness)
        memcpy((void *) (&gbest), (void *) (&p[i]), sizeof(particle));

    }
  }


  double global_sum = 0.0;
  #pragma omp parallel
  {
    double partial_sum = 0.0;
    #pragma omp for
    for (int i = 0; i < 1000000; i++)
      partial_sum += x[i] * y[i];

    global_sum += partial_sum;
  }
  return global_sum;
}

