{
  double init;
  double end;
  struct task *next;
  struct task *prev;
} task;
{
  int size;
  struct task *front;
  struct task *tail;
} queue;
queue *q;
int terminated = 0;
int *idle;
double calculateIntegral1(double init, double end, function f)
{
  double interval = end - init;
  double sum = 0;
  #pragma omp parallel shared(sum)
  {
    int tid;
    int nThreads;
    tid = omp_get_thread_num();
    nThreads = omp_get_num_threads();
    double myInterval = interval / nThreads;
    double myInit = init + (tid * myInterval);
    "Thread(%d): MyInit->%.2f, MyEnd->%.2f\n", tid, myInit, myInit + myInterval;
    double mySum = adaptQuad(myInit, myInit + myInterval, f);
    {
      "Thread(%d): MySum->%.2f\n", tid, mySum;
      sum += mySum;
    }
  }
  return sum;
}

