{
  char *t;
  char *p;
  int start_t;
  int stop_t;
  int start_p;
  int stop_p;
  int thread_id;
  int padding;
  short *found_pos;
} params;
void *process_text(char *t, char *p, int start_t, int stop_t, int start_p, int stop_p, short *found_pos, int rank)
{
  int found = 0;
  long processed = 0;
  long total_processed = 0;
  start_p += stop_p - 1;
  start_t += stop_p - 1;
  while (start_t <= stop_t)
  {
    if (start_p == 0)
    {
      found = 1;
      if (found_pos[start_t] == (-1))
      {
        found_pos[start_t] = rank;
      }

      start_t += processed;
      start_p += processed;
      start_t += stop_p;
      processed = 0;
    }

    if (t[start_t] == p[start_p])
    {
      start_t--;
      start_p--;
      processed++;
    }
    else
    {
      if ((stop_t - start_t) < stop_p)
        break;

      int num = how_many_positions(p + ((stop_p - processed) - 1), t[start_t], stop_p);
      start_t += processed;
      start_t += num;
      total_processed += processed;
      total_processed += num;
      processed = 0;
      start_p = stop_p - 1;
    }

  }

}

