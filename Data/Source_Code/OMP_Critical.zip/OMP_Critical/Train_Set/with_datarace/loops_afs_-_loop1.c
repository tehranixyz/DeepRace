double a[729][729];
double b[729][729];
double c[729];
int jmax[729];
int P;
int seg_sz;
int *itr_left;
int *seg_asgn;
int t_no;
int itr_prf[729] = {0};
void init1(void);
void init2(void);
void loop1(void);
void loop2(void);
void valid1(void);
void valid2(void);
void debug_race(void);
void loop1(void)
{
  int i;
  int j;
  int t;
  int lb;
  int ub;
  int rsv;
  int chnk_sz;
  int max_val;
  int val;
  int ldd_t;
  int seg;
  int itr;
  t_no = omp_get_thread_num();
  seg = t_no;
  #pragma atomic write
  seg_asgn[t_no] = t_no;
  itr = seg_sz;
  if (t_no == (P - 1))
  {
    itr += 729 - (seg_sz * P);
  }

  max_val = itr;
  lb = seg * seg_sz;
  rsv = (chnk_sz = (int) (itr / P));
  {
    itr_left[t_no] = itr - rsv;
  }
  while (max_val > 0)
  {
    while (itr > 0)
    {
      ub = lb + chnk_sz;
      {
        itr_left[t_no] -= chnk_sz;
        itr = itr_left[t_no];
      }
      for (i = lb; i < ub; i++)
      {
        #pragma omp atomic update
        itr_prf[i]++;
        for (j = 729 - 1; j > i; j--)
        {
          a[i][j] += cos(b[i][j]);
        }

      }

      lb = i;
      itr += rsv;
      chnk_sz = (int) (itr / P);
      if (chnk_sz < 1)
      {
        chnk_sz = 1;
      }

    }

    {
      max_val = 0;
      ldd_t = t_no;
      for (t = 0; t < P; t++)
      {
        #pragma omp atomic read
        val = itr_left[t];
        if (val > max_val)
        {
          max_val = val;
          ldd_t = t;
        }

      }

      {
        itr = itr_left[ldd_t];
        itr_left[ldd_t] = 0;
      }
    }
    printf("T%d has %d itrs left (Org value = %d) Reassign to T%d ....", ldd_t, itr, max_val, t_no);
    #pragma atomic read
    seg = seg_asgn[ldd_t];
    #pragma atomic write
    seg_asgn[t_no] = seg;
    rsv = (chnk_sz = (int) (itr / P));
    if (itr < P)
    {
      rsv = (chnk_sz = 1);
    }

    {
      itr_left[t_no] = itr - rsv;
    }
    lb = (seg == (P - 1)) ? (729 - itr) : (((seg + 1) * seg_sz) - itr);
    printf(" eval segment %d. bounds %d - %d\n", seg, lb, (seg + 1) * seg_sz);
  }

  #pragma omp barrier

  int thds;
  int i;
  int errors = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi thread.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    if (omp_in_parallel() == 0)
    {
      #pragma omp critical
      errors += 1;
    }

  }
  for (i = 1; i <= thds; i++)
  {
    omp_set_num_threads(i);
    #pragma omp parallel
    {
      if (omp_in_parallel() == 0)
      {
        #pragma omp critical
        errors += 1;
      }

    }
  }

  if (errors == 0)
  {
    printf("omp_in_parallel 002 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("omp_in_parallel 002 : FAILED\n");
    return 1;
  }

}

