int main(int argc, char *argv[])
{
  omp_set_num_threads(8);
  float *AUX;
  float *AUX1;
  float **MA;
  float *MB;
  float tempo;
  double inicial = omp_get_wtime();
  double tempoAloc;
  double inicialAloc;
  double tempoInsercao;
  double inicialInsercao;
  float erro;
  float dif;
  float numerador = 0.00;
  float denominador = 0.00;
  float max = 0.00;
  float J_ERROR;
  float result;
  int J_ORDER;
  int J_ITE_MAX;
  int J_ROW_TEST;
  int i;
  int j;
  int count = 0;
  int flag = 0;
  FILE *pFile;
  char nome_arquivo[15];
  printf("Nome do arquivo: ");
  scanf("%s", nome_arquivo);
  pFile = fopen(nome_arquivo, "rb");
  if (pFile == 0)
  {
    fputs("File error", stderr);
    exit(1);
  }

  rewind(pFile);
  fscanf(pFile, "%d", &J_ORDER);
  fscanf(pFile, "%d", &J_ROW_TEST);
  fscanf(pFile, "%f", &J_ERROR);
  fscanf(pFile, "%d", &J_ITE_MAX);
  inicialAloc = omp_get_wtime();
  MA = (float **) malloc((sizeof(float *)) * J_ORDER);
  for (i = 0; i < J_ORDER; i++)
  {
    MA[i] = (float *) malloc((sizeof(float)) * J_ORDER);
  }

  MB = (float *) malloc((sizeof(float)) * J_ORDER);
  tempoAloc = omp_get_wtime() - inicialAloc;
  printf("----------------------------------------------------------------\n");
  printf("Tempo de alocacao: %.10lf seg\n", tempoAloc);
  printf("----------------------------------------------------------------\n");
  inicialInsercao = omp_get_wtime();
  for (i = 0; i < J_ORDER; i++)
  {
    for (j = 0; j < J_ORDER; j++)
      fscanf(pFile, "%f", &MA[i][j]);

  }

  for (i = 0; i < J_ORDER; i++)
  {
    fscanf(pFile, "%f", &MB[i]);
  }

  tempoInsercao = omp_get_wtime() - inicialAloc;
  printf("Tempo de insercao de dados: %.10lf seg\n", tempoInsercao);
  printf("----------------------------------------------------------------\n");
  inicial = omp_get_wtime();
  for (i = 0; i < J_ORDER; i++)
  {
    AUX = (float *) malloc((sizeof(float)) * J_ORDER);
  }

  for (i = 0; i < J_ORDER; i++)
  {
    AUX1 = (float *) malloc((sizeof(float)) * J_ORDER);
    AUX[i] = 0;
  }

  i = 0;
  j = 0;
  do
  {
    denominador = 0.00;
    numerador = 0.00;
    count = count + 1;
    for (i = 0; i < J_ORDER; i++)
    {
      AUX1[i] = 0.0;
      for (j = 0; j < J_ORDER; j++)
      {
        if (i != j)
        {
          AUX1[i] = AUX1[i] + (MA[i][j] * AUX[j]);
        }

      }

      AUX1[i] = (1 / MA[i][i]) * (MB[i] - AUX1[i]);
      dif = AUX1[i] - AUX[i];
      if (dif < 0)
      {
        dif = dif * (-1);
      }

      if (numerador < dif)
      {
        numerador = dif;
      }

      dif = AUX1[i];
      if (dif < 0)
      {
        dif = dif * (-1);
      }

      if (denominador < dif)
      {
        denominador = dif;
      }

    }

    for (i = 0; i < J_ORDER; i++)
    {
      AUX[i] = AUX1[i];
    }

    erro = numerador / denominador;
  }
  while ((erro >= J_ERROR) && (count < J_ITE_MAX));
  #pragma omp parallel for
  for (i = 0; i < J_ORDER; i++)
  {
    result = result + (MA[J_ROW_TEST][i] * AUX1[i]);
  }

  printf("----------------------------------------------------------------\n");
  printf("Iterations: %d\n", count);
  printf("RowTest: %d => [%f] =? %f\n", J_ROW_TEST, result, MB[J_ROW_TEST]);
  printf("----------------------------------------------------------------\n");
  tempo = omp_get_wtime() - inicial;
  printf("Tempo de execução do Jacobi-Richardson: %.10lf seg\n", tempo);
  printf("----------------------------------------------------------------\n");
  free(MA);
  free(MB);
  free(AUX);
  free(AUX1);
  printf("---------------------------Fim Programa-------------------------\n");
  return 0;
}

