struct elem
{
  long long val;
  struct elem *next;
};
void slave_procedure(int my_rank, int comm_size, long long the_number)
{
  long long from;
  long long to;
  long long to_send;
  int shit_happened;
  struct elem *head = 0;
  from = (((long long int) sqrt((double) the_number)) / (comm_size - 1)) * (my_rank - 1);
  to = ((((long long int) sqrt((double) the_number)) / (comm_size - 1)) + 1) * my_rank;
  from = (from == 0) ? (1) : (from);
  long long int i;
  #pragma omp parallel shared(from, to) private(i)
  {
    #pragma omp for schedule(auto)
    for (i = 0; i < (to - from); ++i)
    {
      if ((the_number % (from + i)) == 0)
      {
        {
          add(&head, from + i);
          add(&head, the_number / (from + i));
        }
      }

    }

  }
  do
  {
    to_send = pick(&head);
    shit_happened = MPI_Ssend(&to_send, 1, MPI_LONG_LONG, 0, 0, MPI_COMM_WORLD);
    if (shit_happened)
    {
      fprintf(stderr, "Send failed");
      MPI_Abort(MPI_COMM_WORLD, 1);
    }

  }
  while (to_send != 0);
}

