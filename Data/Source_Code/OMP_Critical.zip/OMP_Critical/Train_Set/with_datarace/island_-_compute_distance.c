struct path
{
  int city_path[500];
  int rank;
  int distance;
};
int distance[500][500];
path paths[50];
path *all_paths;
path best;
void compute_distance(path *local_paths)
{
  for (int i = 0; i < 50; i++)
  {
    int *city_path = local_paths[i].city_path;
    int path_distance = distance[city_path[500 - 1]][city_path[0]];
    for (int j = 0; j < (500 - 1); j++)
    {
      path_distance += distance[city_path[j]][city_path[j + 1]];
    }

    local_paths[i].distance = path_distance;
    if ((path_distance < best.distance) || (best.distance == (-1)))
    {
      best = local_paths[i];
    }

  }


  int y;
  #pragma omp critical
  y = x - 1;
  if (y < 0)
    return 0;

  return a(x - 1) + 1;
}

