void print_results(float array[50], int tid, int section)
{
  int i;
  FILE *f;
  if (diag_buffer == 0)
    return;

  #pragma omp critical
  {
    f = fopen(diag_filename, "a");
    if (!f)
    {
      perror("ERROR");
      fprintf(stderr, "Unable to open file '%s' for writing diagnostic information!\n", diag_filename);
      exit(-1);
    }

    if (ftell(f) == 0)
    {
      fprintf(f, "#");
      for (i = 0; i < diag_n; i++)
      {
        fprintf(f, " %s", diag_names[i]);
      }

    }

    fputs(diag_buffer, f);
    fclose(f);
  }

  int i;
  int j;
  j = 1;
  {
    printf("\nThread %d did section %d. The results are:\n", tid, section);
    for (i = 0; i < 50; i++)
    {
      printf("%e  ", array[i]);
      j++;
      if (j == 6)
      {
        printf("\n");
        j = 1;
      }

    }

    printf("\n");
  }
  printf("Thread %d done and synchronized.\n", tid);
}

