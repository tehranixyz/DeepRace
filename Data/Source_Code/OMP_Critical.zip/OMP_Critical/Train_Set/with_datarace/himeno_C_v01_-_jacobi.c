static real p[MKMAX][MJMAX][MIMAX];
static real a[4][MKMAX][MJMAX][MIMAX];
static real b[3][MKMAX][MJMAX][MIMAX];
static real c[3][MKMAX][MJMAX][MIMAX];
static real bnd[MKMAX][MJMAX][MIMAX];
static real wrk1[MKMAX][MJMAX][MIMAX];
static real wrk2[MKMAX][MJMAX][MIMAX];
static int imax;
static int jmax;
static int kmax;
static real omega;
double gettime();
double jacobi(int);
void initmt();
double jacobi(int nn)
{
  int i;
  int j;
  int k;
  int loop;
  real s0;
  double gosa;
  double gosa1;
  double ss;
  #pragma omp parallel default(shared) private(loop,k,j,i,s0,ss,gosa1)
  {
    for (loop = 0; loop < nn; ++loop)
    {
      #pragma omp barrier
      #pragma omp master
      gosa = 0.0;
      gosa1 = 0.0;
      #pragma acc parallel loop private(i,j,k,s0,ss) reduction(+:gosa1) vector_length(NTPB)
      #pragma omp for
      for (k = 1; k < (kmax - 1); ++k)
        for (j = 1; j < (jmax - 1); ++j)
        for (i = 1; i < (imax - 1); ++i)
      {
        s0 = (((((((((a[0][k][j][i] * p[k][j][i + 1]) + (a[1][k][j][i] * p[k][j + 1][i])) + (a[2][k][j][i] * p[k + 1][j][i])) + (b[0][k][j][i] * (((p[k][j + 1][i + 1] - p[k][j - 1][i + 1]) - p[k][j + 1][i - 1]) + p[k][j - 1][i - 1]))) + (b[1][k][j][i] * (((p[k + 1][j + 1][i] - p[k + 1][j - 1][i]) - p[k - 1][j + 1][i]) + p[k - 1][j - 1][i]))) + (b[2][k][j][i] * (((p[k + 1][j][i + 1] - p[k + 1][j][i - 1]) - p[k - 1][j][i + 1]) + p[k - 1][j][i - 1]))) + (c[0][k][j][i] * p[k][j][i - 1])) + (c[1][k][j][i] * p[k][j - 1][i])) + (c[2][k][j][i] * p[k - 1][j][i])) + wrk1[k][j][i];
        ss = ((s0 * a[3][k][j][i]) - p[k][j][i]) * bnd[k][j][i];
        gosa1 = gosa1 + (ss * ss);
        wrk2[k][j][i] = p[k][j][i] + (omega * ss);
      }



      #pragma omp for nowait
      for (k = 1; k < (kmax - 1); ++k)
        for (j = 1; j < (jmax - 1); ++j)
        for (i = 1; i < (imax - 1); ++i)
        p[k][j][i] = wrk2[k][j][i];



      gosa = gosa + gosa1;
    }

  }
  return gosa;
}

