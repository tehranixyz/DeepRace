static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int func(int *prvt)
{
  *prvt = omp_get_thread_num();
  #pragma omp barrier
  if ((*prvt) != omp_get_thread_num())
  {
    errors++;
  }

}

