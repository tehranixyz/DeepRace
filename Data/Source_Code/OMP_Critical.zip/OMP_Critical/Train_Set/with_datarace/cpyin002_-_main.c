static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt1;
int prvt2;
int prvt3;
#pragma omp threadprivate(prvt1,prvt2,prvt3);
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt1 = -1;
  prvt2 = 0;
  prvt3 = 1;
  #pragma omp parallel copyin (prvt1) copyin (prvt2) copyin (prvt3)
  {
    if (((prvt1 != (-1)) || (prvt2 != 0)) || (prvt3 != 1))
    {
      errors += 1;
    }

  }
  prvt1 = -2;
  prvt2 = 1;
  prvt3 = 2;
  #pragma omp parallel copyin (prvt1,prvt2) copyin (prvt3)
  {
    if (((prvt1 != (-2)) || (prvt2 != 1)) || (prvt3 != 2))
    {
      errors += 1;
    }

  }
  prvt1 = -3;
  prvt2 = 2;
  prvt3 = 3;
  #pragma omp parallel copyin (prvt1,prvt2,prvt3)
  {
    if (((prvt1 != (-3)) || (prvt2 != 2)) || (prvt3 != 3))
    {
      errors += 1;
    }

  }
  if (errors == 0)
  {
    printf("copyin 002 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("copyin 002 : FAILED\n");
    return 1;
  }


  int id = omp_get_thread_num();
  *prvt = id;
  #pragma omp barrier
  if ((*prvt) != id)
  {
    #pragma omp critical
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(long)))
  {
    #pragma omp critical
    errors += 1;
  }

}

