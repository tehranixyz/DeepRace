{
  double start = omp_get_wtime();
  static int n = 100000000;
  int nthreads;
  float dx;
  float x;
  float y;
  dx = 1 / (((double) n) + 1);
  FILE *fp = fopen("calculations.txt", "w");
  if (argc > 1)
    nthreads = atoi(argv[1]);

  #pragma omp parallel for private(x)
  for (int i = 0; i < n; i++)
  {
    x = i * dx;
    y = ((exp(x) * cos(x)) * sin(x)) * sqrt((5 * x) + 6);
    #pragma omp critical
    if ((i % 1000000) == 0)
    {
      fprintf(fp, "%d, %f, %f\n", i, x, y);
    }

  }

  fclose(fp);
  double end = omp_get_wtime();
  printf("Time elapsed: %f\n", end - start);

  long nodeCount;
  struct SigNode *firstNode;
  struct SigNode *lastNode;
} SigHead;
{
  int col;
  int keyIndexes[4];
  long signature;
  struct SigNode *nextNode;
  struct SigNode *nextCollisionNode;
  struct SigNode *prevCollisionNode;
  struct SigNode *nextCollisionHead;
} SigNode;
struct SigNode *findPrevCollisionNode(struct SigHead *head, struct SigHead *collisionsHead, int col, long signature)
{
  SigNode *prevCollisionNode = 0;
  if (head->nodeCount > 0)
  {
    SigNode *currentNode = head->firstNode;
    while ((currentNode->nextNode != 0) && (currentNode->col != col))
    {
      if ((currentNode->signature == signature) && (currentNode->nextCollisionNode == 0))
      {
        prevCollisionNode = currentNode;
        if (prevCollisionNode->prevCollisionNode == 0)
        {
          {
            if (collisionsHead->nodeCount == 0)
            {
              collisionsHead->firstNode = currentNode;
            }
            else
            {
              collisionsHead->lastNode->nextCollisionHead = currentNode;
            }

            collisionsHead->lastNode = currentNode;
            collisionsHead->nodeCount++;
          }
        }

      }

      currentNode = currentNode->nextNode;
    }

  }

  return prevCollisionNode;
}

