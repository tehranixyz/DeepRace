static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int a;
int b;
void func_flush()
{
  a = 0;
  #pragma omp barrier
  if (omp_get_thread_num() == 0)
  {
    waittime(1);
    a = 1;
  }
  else
  {
    while (a == 0)
    {
      {
      }
    }

  }

}

