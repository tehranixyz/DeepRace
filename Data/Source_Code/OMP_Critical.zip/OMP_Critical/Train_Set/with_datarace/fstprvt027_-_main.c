static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt;
int main()
{
  int sum = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    #pragma omp for firstprivate(prvt)
    for (prvt = 0; prvt < thds; prvt++)
    {
      sum += 1;
    }

  }
  if (sum != thds)
  {
    errors += 1;
  }

  if (errors == 0)
  {
    printf("firstprivate 027 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 027 : FAILED\n");
    return 1;
  }


  int sum = 0;
  int sum0 = 0;
  int sum1 = 0;
  int known_sum;
  int i;
  #pragma omp parallel private(sum1)
  {
    sum0 = 0;
    sum1 = 0;
    #pragma omp for private(sum0) schedule(static,1)
    for (i = 1; i <= LOOPCOUNT; i++)
    {
      sum0 = sum1;
      #pragma omp flush
      sum0 = sum0 + i;
      do_some_work();
      #pragma omp flush
      sum1 = sum0;
    }

    #pragma omp critical
    {
      sum = sum + sum1;
    }
  }
  known_sum = (LOOPCOUNT * (LOOPCOUNT + 1)) / 2;
  return known_sum == sum;
}

