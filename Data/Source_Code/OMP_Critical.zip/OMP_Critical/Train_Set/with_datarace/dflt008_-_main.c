static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int shrd;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  shrd = 0;
  #pragma omp parallel sections default (shared)
  {
    #pragma omp section
    {
      shrd += 1;
    }
    #pragma omp section
    {
      shrd += 1;
    }
    #pragma omp section
    {
      shrd += 1;
    }
  }
  if (shrd != 3)
  {
    errors += 1;
  }

  shrd = 0;
  #pragma omp parallel sections default (none) shared (shrd)
  {
    #pragma omp section
    {
      shrd += 1;
    }
    #pragma omp section
    {
      shrd += 1;
    }
    #pragma omp section
    {
      shrd += 1;
    }
  }
  if (shrd != 3)
  {
    errors += 1;
  }

  if (errors == 0)
  {
    printf("default 008 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("default 008 : FAILED\n");
    return 1;
  }

}

