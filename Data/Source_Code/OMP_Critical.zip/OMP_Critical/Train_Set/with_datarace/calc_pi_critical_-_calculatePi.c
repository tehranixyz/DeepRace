void getparams(int argc, char **argv, int *iterations);
int isNumber(char *number);
void calculatePi(int iterations);
void calculatePi(int iterations)
{
  double oneStep = 1.0 / iterations;
  double lowbound = 0;
  double higherbound = 0;
  #pragma omp parallel for
  for (int i = 1; i <= iterations; i++)
  {
    if (i < iterations)
    {
      {
        lowbound += sqrt(1 - pow(i * oneStep, 2)) * oneStep;
      }
    }

    {
      higherbound += sqrt(1 - pow((i - 1) * oneStep, 2)) * oneStep;
    }
  }

  lowbound = lowbound * 4;
  higherbound = higherbound * 4;
  printf("Lower Bound: %.12f\n", lowbound);
  printf("Upper Bound: %.12f\n", higherbound);

  double estimate_x = 0.0;
  double estimate_y = 0.0;
  int i;
  int a;
  int temp1;
  int temp2;
  #pragma omp parallel for private(temp1, temp2)
  for (i = 0; i < n; i++)
  {
    a = weights[i];
    temp1 = arrayX[i] * a;
    temp2 = arrayY[i] * a;
    #pragma omp critical
    estimate_x += temp1;
    #pragma omp critical
    estimate_y += temp2;
  }

  *x_e = estimate_x;
  *y_e = estimate_y;
}

