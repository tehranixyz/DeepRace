extern int nv;
extern int *notdone;
extern int nth;
extern int chunk;
extern int md;
extern int mv;
extern int largeint;
extern unsigned *ohd;
extern unsigned *mind;
extern void init();
extern void findmymin();
extern void updatemind();
int startv;
int endv;
int step;
int mymv;
int me;
unsigned int mymd;
void dowork()
{
  #pragma threadprivate(startv,endv,step, mymv,me,mymd)
  #pragma omp parallel
  {
    me = omp_get_thread_num();
    #pragma omp master
    {
      nth = omp_get_num_threads();
      if ((nv % nth) != 0)
      {
        printf("nv must be divisible by nth\n");
        exit(1);
      }

      chunk = nv / nth;
    }
    startv = me * chunk;
    endv = (startv + chunk) - 1;
    for (step = 0; step < nv; step++)
    {
      #pragma omp master
      {
        md = largeint;
        mv = 0;
      }
      findmymin(startv, endv, &mymd, &mymv);
      {
        if (mymd < md)
        {
          md = mymd;
          mv = mymv;
        }

      }
      #pragma omp barrier
      #pragma omp master
      {
        notdone[mv] = 0;
      }
      updatemind(startv, endv);
      #pragma omp barrier
    }

  }
}

