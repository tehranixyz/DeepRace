unsigned int genprimes(unsigned int N, unsigned int t, unsigned int *array);
void writeToFile(char *filename, unsigned int arraySize, unsigned int *array);
int cmpfunc(const void *a, const void *b);
unsigned int genprimes(unsigned int N, unsigned int t, unsigned int *array)
{
  unsigned int arraySize = N - 1;
  unsigned int j;
  unsigned int index;
  unsigned int *newarray;
  unsigned int *temp;
  unsigned int next = 2;
  unsigned int nextIndex = 0;
  newarray = (unsigned int *) calloc(arraySize, sizeof(unsigned int));
  unsigned int limit = (unsigned int) floor((N + 1) / 2);
  while (next <= limit)
  {
    index = 0;
    #pragma omp parallel for num_threads(t)
    for (j = 0; j < arraySize; j++)
    {
      if ((array[j] != next) && ((array[j] % next) == 0))
        continue;

      {
        newarray[index] = array[j];
        index++;
      }
    }

    arraySize = index;
    qsort(newarray, arraySize, sizeof(int), cmpfunc);
    temp = newarray;
    newarray = array;
    array = temp;
    if (array[nextIndex] == next)
    {
      nextIndex++;
      next = array[nextIndex];
    }

  }

  return arraySize;
}

