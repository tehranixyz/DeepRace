static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int org;
int prvt;
#pragma omp threadprivate(prvt);
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = (org = -1);
  #pragma omp parallel copyin (prvt)
  {
    if (prvt != org)
    {
      {
        ERROR(errors);
      }
    }

  }
  prvt = (org = 0);
  #pragma omp parallel copyin (prvt)
  {
    if (prvt != org)
    {
      {
        ERROR(errors);
      }
    }

  }
  prvt = (org = 1);
  #pragma omp parallel copyin (prvt)
  {
    if (prvt != org)
    {
      {
        ERROR(errors);
      }
    }

  }
  if (errors == 0)
  {
    printf("copyin 001 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("copyin 001 : FAILED\n");
    return 1;
  }

}

