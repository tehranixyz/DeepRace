int NV = 0;
int threadnum1;
double sumpt = 0;
int main(int argc, char *argv[]);
int *dijkstra_distance(int ohd[NV][NV]);
void find_nearest(int s, int e, int mind[NV], int connected[NV], int *d, int *v);
void init(int ohd[NV][NV]);
void timestamp(void);
void update_mind(int s, int e, int mv, int connected[NV], int ohd[NV][NV], int mind[NV]);
int *dijkstra_distance(int ohd[NV][NV])
{
  int *connected;
  int i;
  int i4_huge = 2147483647;
  int md;
  int *mind;
  int mv;
  int my_first;
  int my_id;
  int my_last;
  int my_md;
  int my_mv;
  int my_step;
  int nth;
  int cpu;
  double pt1;
  double pt2;
  double ptminus1;
  double ptminus2;
  connected = (int *) malloc(NV * (sizeof(int)));
  connected[0] = 1;
  for (i = 1; i < NV; i++)
  {
    connected[i] = 0;
  }

  mind = (int *) malloc(NV * (sizeof(int)));
  for (i = 0; i < NV; i++)
  {
    mind[i] = ohd[0][i];
  }

  #pragma omp parallel private ( my_first, my_id, my_last, my_md, my_mv, my_step,cpu,pt1,pt2,ptminus1,ptminus2 ) shared ( connected, md, mind, mv, nth, ohd)
  {
    my_id = omp_get_thread_num();
    nth = omp_get_num_threads();
    threadnum1 = nth;
    cpu = sched_getcpu();
    my_first = (my_id * NV) / nth;
    my_last = (((my_id + 1) * NV) / nth) - 1;
    #pragma omp single
    {
      printf("\n");
      printf("  P%d: Parallel region begins with %d threads \n", my_id, nth);
      printf("\n");
    }
    fprintf(stdout, "  P%d:  First=%d  Last=%d cpu:%d \n", my_id, my_first, my_last, cpu);
    for (my_step = 1; my_step < NV; my_step++)
    {
      #pragma omp single
      {
        md = i4_huge;
        mv = -1;
      }
      pt1 = omp_get_wtime();
      find_nearest(my_first, my_last, mind, connected, &my_md, &my_mv);
      pt2 = omp_get_wtime();
      ptminus1 = pt2 - pt1;
      {
        if (my_md < md)
        {
          md = my_md;
          mv = my_mv;
        }

      }
      #pragma omp barrier
      #pragma omp single
      {
        if (mv != (-1))
        {
          connected[mv] = 1;
        }

      }
      #pragma omp barrier
      if (mv != (-1))
      {
        pt1 = omp_get_wtime();
        update_mind(my_first, my_last, mv, connected, ohd, mind);
        pt2 = omp_get_wtime();
        ptminus2 = pt2 - pt1;
      }

      #pragma omp master
      {
        sumpt += ptminus2 + ptminus1;
      }
      #pragma omp barrier
    }

  }
  free(connected);
  return mind;
}

