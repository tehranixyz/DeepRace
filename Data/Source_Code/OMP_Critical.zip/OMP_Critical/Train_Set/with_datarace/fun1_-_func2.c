void func2(double *weights, double *probability, int n)
{
  int i;
  double sumWeights = 0;
  int temp;
  #pragma omp parallel for
  for (i = 0; i < n; i++)
  {
    temp = weights[i] * exp(probability[i]);
    weights[i] = weights[i] * exp(probability[i]);
    sumWeights += temp;
    weights[i] = temp;
  }

  for (i = 0; i < n; i++)
    weights[i] = weights[i] / sumWeights;

}

