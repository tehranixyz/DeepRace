int main()
{
  int arr[1000];
  int i;
  int max = -1;
  for (i = 0; i < 1000; i++)
    arr[i] = rand() % 100000;

  omp_set_num_threads(4);
  #pragma omp parallel for
  for (i = 0; i < 1000; i++)
  {
    if (arr[i] > max)
    {
      if (arr[i] > max)
        max = arr[i];

    }

  }

  printf("Max = %d\n", max);
}

