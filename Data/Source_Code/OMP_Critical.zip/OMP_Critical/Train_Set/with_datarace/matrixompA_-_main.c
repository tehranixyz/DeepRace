double start_time;
double end_time;
int numWorkers;
int size;
int matrix[10000][10000];
void *Worker(void *);
int main(int argc, char *argv[])
{
  srand(time(0));
  int i;
  int j;
  int total = 0;
  size = (argc > 1) ? (atoi(argv[1])) : (10000);
  numWorkers = (argc > 2) ? (atoi(argv[2])) : (8);
  if (size > 10000)
    size = 10000;

  if (numWorkers > 8)
    numWorkers = 8;

  omp_set_num_threads(numWorkers);
  for (i = 0; i < size; i++)
  {
    for (j = 0; j < size; j++)
    {
      matrix[i][j] = rand() % 100;
    }

  }

  int maxX = 0;
  int maxY = 0;
  int max = 0;
  int finalMax = 0;
  int x = 0;
  int y = 0;
  start_time = omp_get_wtime();
  #pragma omp parallel for reduction (+:total) private( j, max, maxX, maxY) shared(finalMax, x, y)
  for (i = 0; i < size; i++)
  {
    int id = omp_get_thread_num();
    for (j = 0; j < size; j++)
    {
      int elem = matrix[i][j];
      if (elem > max)
      {
        max = elem;
        maxX = i;
        maxY = j;
      }

      total += elem;
    }

    {
      if (max > finalMax)
      {
        finalMax = max;
        x = maxX;
        y = maxY;
      }

    }
  }

  end_time = omp_get_wtime();
  printf("the total is %d\n", total);
  printf("max value: %d at %d, %d\n", finalMax, x, y);
  printf("it took %g seconds\n", end_time - start_time);
}

