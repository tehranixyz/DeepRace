struct round_t
{
  long partial_sum;
  long id;
  long istart;
  long iend;
  long i;
  long final_sum = 0;
  #pragma omp parallel private(partial_sum,id,istart,iend,i) shared(final_sum)
  {
    int num_threads = omp_get_num_threads();
    id = omp_get_thread_num();
    istart = (id * k) / num_threads;
    iend = ((id + 1) * k) / num_threads;
    partial_sum = 0;
    for (i = istart; i < iend; i++)
    {
      partial_sum += A[i];
    }

    #pragma omp critical
    {
      final_sum += partial_sum;
    }
  }
  return final_sum;

  int role;
  int vpid;
  int tb_round;
  bool *opponent;
  bool flag;
};
round_t array[100][100];
int main(int argc, char **argv)
{
  bool x = 0;
  if (argc != 3)
  {
    printf("Enter the number of threads and barriers.\n");
    exit(0);
  }

  struct timeval start;
  struct timeval end;
  int i;
  int k;
  int thread_count = atoi(argv[1]);
  int barrier_count = atoi(argv[2]);
  int num_rounds = ceil(log(thread_count) / log(2));
  for (i = 0; i < thread_count; i++)
  {
    for (k = 0; k <= num_rounds; k++)
    {
      array[i][k].flag = 0;
      array[i][k].role = -1;
      array[i][k].opponent = &x;
    }

  }

  int second_check;
  int first_check = 0;
  for (i = 0; i < thread_count; i++)
  {
    for (k = 0; k <= num_rounds; k++)
    {
      second_check = ceil(pow(2, k));
      first_check = ceil(pow(2, k - 1));
      if ((((k > 0) && ((i % second_check) == 0)) && ((i + first_check) < thread_count)) && (second_check < thread_count))
      {
        array[i][k].role = 0;
      }

      if (((k > 0) && ((i % second_check) == 0)) && ((i + first_check) >= thread_count))
      {
        array[i][k].role = 2;
      }

      if ((k > 0) && ((i % second_check) == first_check))
      {
        array[i][k].role = 1;
      }

      if (((k > 0) && (i == 0)) && (second_check >= thread_count))
      {
        array[i][k].role = 3;
      }

      if (k == 0)
      {
        array[i][k].role = 4;
      }

      if (array[i][k].role == 1)
      {
        array[i][k].opponent = &array[i - first_check][k].flag;
      }

      if ((array[i][k].role == 0) || (array[i][k].role == 3))
      {
        array[i][k].opponent = &array[i + first_check][k].flag;
      }

    }

  }

  gettimeofday(&start, 0);
  #pragma omp parallel num_threads(thread_count) shared(array)
  {
    int vpid = 0;
    bool *sense;
    bool temp = 1;
    {
      vpid = omp_get_thread_num();
      sense = &temp;
    }
    int num_threads = omp_get_num_threads();
    int i;
    int j;
    int thread_num = omp_get_thread_num();
    printf("Thread Number: %d Ready.\n", vpid);
    for (i = 0; i < barrier_count; i++)
    {
      printf("Thread %d is waiting at Barrier %d.\n", vpid, i + 1);
      tournament_barrier(vpid, sense, num_rounds);
      printf("Thread %d left Barrier %d.\n", vpid, i + 1);
    }

  }
  gettimeofday(&end, 0);
  printf("Total Time:    %ld\n", ((end.tv_sec * 1000000) + end.tv_usec) - ((start.tv_sec * 1000000) + start.tv_usec));
  return 0;
}

