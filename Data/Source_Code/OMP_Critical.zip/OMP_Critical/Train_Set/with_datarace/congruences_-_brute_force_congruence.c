static long *adjust_coeffs_to_mod(int degree, long *coeffs, long mod);
static long *solve_prime_power_congruence(int degree, long coeffs[], long prime, int power);
static long *solve_system_of_order_1_congruence_sets(int numOfSets, int *lengthsOfSets, long **sets, long mods[]);
long *brute_force_congruence(int degree, long coeffs[], long primeMod)
{
  long *adjustedCoeffs = adjust_coeffs_to_mod(degree, coeffs, primeMod);
  long *solutionList = calloc(degree + 1, sizeof(long));
  long *solutions = solutionList + 1;
  int numberOfSolutions = 0;
  long x;
  #pragma omp parallel for
  for (x = 0; x < primeMod; x++)
  {
    if (mod_eval_polynomial(degree, adjustedCoeffs, primeMod, x) == 0)
    {
      solutions[numberOfSolutions++] = x;
    }

  }

  *solutionList = numberOfSolutions;
  free(adjustedCoeffs);
  return solutionList;
}

