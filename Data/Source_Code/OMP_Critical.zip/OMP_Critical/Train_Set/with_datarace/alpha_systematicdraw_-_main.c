int lts_linfit_exit = 0;
int gaussjfail = 0;
int ltsrunning = 0;
int dosys_dbootstrap = 1;
int dosys_ltsbadres = 1;
int main()
{
  long i;
  long j;
  long k;
  long p;
  long q;
  long ic;
  long n;
  long icdone;
  long select;
  double nyes;
  double nno;
  struct multdata *sys_known[2];
  struct multdata *sys_rand[2];
  struct multdata *outstruct;
  struct multdata *OT;
  char *header = malloc(10000 * (sizeof(char)));
  double somerand;
  char *ostring = malloc(10000 * (sizeof(char)));
  char *istring = malloc(10000 * (sizeof(char)));
  char *thr_ostring;
  char *thr_istring;
  FILE *fp;
  char *sptr;
  char *savptr;
  int breakloop;
  double scale;
  double dtemp;
  char *thr_dir;
  int thr_num;
  long nx;
  long index[2];
  char *thr_headerwrite;
  double *thr_RAlist;
  double *thr_RAselect;
  long thr_nquasars;
  long thr_nquasars_select;
  double thr_chisq;
  double thr_numpoints;
  double thr_numparms;
  double thr_AICC;
  double thr_k;
  double thr_n;
  int istat;
  struct simresults
  {
    long n;
    double *sig;
    double *msig;
    long *nbad;
    double *badresrms;
    double *chisq;
    double *numpoints;
    double *numparms;
  };
  struct simresults *sr;
  sr = malloc(sizeof(struct simresults));
  sr->sig = malloc((1000 + 3) * (sizeof(double)));
  sr->msig = malloc((1000 + 3) * (sizeof(double)));
  sr->nbad = malloc((1000 + 3) * (sizeof(long)));
  sr->badresrms = malloc((1000 + 3) * (sizeof(double)));
  sr->chisq = malloc((1000 + 3) * (sizeof(double)));
  sr->numpoints = malloc((1000 + 3) * (sizeof(double)));
  sr->numparms = malloc((1000 + 3) * (sizeof(double)));
  init_genrand(time(0));
  for (i = 1; i <= 2; i++)
  {
    sys_known[i] = malloc(sizeof(struct multdata));
    allocate_multspace(sys_known[i], 10000, 3);
    sys_rand[i] = malloc(sizeof(struct multdata));
    allocate_multspace(sys_rand[i], 10000, 3);
  }

  OT = malloc(sizeof(struct multdata));
  allocate_multspace(OT, 10000, 3);
  for (i = 1; i <= 2; i++)
  {
    sprintf(ostring, "sysdraw_known_%d.dat", i);
    read_data(sys_known[i], ostring, header, 3);
    printf("Read %ld entries from sysdraw_known_%d\n", sys_known[i]->n, i);
    sprintf(ostring, "sysdraw_rand_%d.dat", i);
    read_data(sys_rand[i], ostring, header, 3);
    printf("Read %ld entries from sysdraw_rand_%d\n", sys_rand[i]->n, i);
  }

  read_data(OT, "other_telescope.dat", header, 3);
  printf("Read %ld entries from other_telescope\n", OT->n, i);
  sleep(1);
  n = sys_rand[1]->n;
  for (i = 2; i <= 2; i++)
  {
    if (sys_rand[i]->n != n)
    {
      printf("ERROR: sysdraw_rand_1.dat and sysdraw_rand_%d have different n\n", i);
      exit(1);
    }

  }

  for (i = 1; i <= 2; i++)
  {
    printf("---------SYSDRAW_RAND_%d---------\n", i);
    for (j = 1; j <= sys_rand[i]->n; j++)
    {
      printf("z=%lf     y=%lf    err=%lf\n", sys_rand[i]->x[j][1], sys_rand[i]->y[j], sys_rand[i]->err[j]);
    }

  }

  for (i = 1; i <= 2; i++)
  {
  }

  omp_set_num_threads(8);
  icdone = 0;
  system("rm sysdraw_dipolesig_prog.dat");
  system("rm sysdraw_monopolesig_prog.dat");
  system("rm sysdraw_LTSnbad_prog.dat");
  system("rm sysdraw_LTSbadres_rms_prog.dat");
  system("rm sysdraw_LTS_scale_prog.dat");
  system("rm sysdraw_AICC_prog.dat");
  system("rm sysdraw_chisq_prog.dat");
  system("rm sysdraw_numparms_prog.dat");
  system("rm sysdraw_numpoints_prog.dat");
  #pragma omp parallel for firstprivate(thr_num, thr_dir, outstruct, i, j, n, k, p, somerand, select, thr_istring, thr_ostring, thr_headerwrite, scale, dtemp, thr_RAlist, thr_RAselect, thr_nquasars, thr_nquasars_select, nyes, nno, thr_chisq, thr_numpoints, thr_numparms, thr_AICC, thr_k, thr_n) private(fp, sptr, savptr) shared(sr, OT, icdone) schedule(dynamic)
  for (ic = 1; ic <= 1000; ic++)
  {
    outstruct = malloc(sizeof(struct multdata));
    allocate_multspace(outstruct, 10000, 3);
    thr_ostring = malloc(1000 * (sizeof(char)));
    thr_istring = malloc(1000 * (sizeof(char)));
    thr_num = omp_get_thread_num();
    thr_dir = malloc(1000 * (sizeof(char)));
    thr_headerwrite = malloc(1000 * (sizeof(char)));
    thr_RAlist = malloc((10000 + 2) * (sizeof(double)));
    thr_RAselect = malloc((10000 + 2) * (sizeof(double)));
    sprintf(thr_ostring, "mkdir %d", thr_num);
    system(thr_ostring);
    i = 0;
    for (j = 1; j <= 2; j++)
    {
      n = sys_known[j]->n;
      for (k = 1; k <= n; k++)
      {
        i++;
        outstruct->y[i] = sys_known[j]->y[k];
        outstruct->err[i] = sys_known[j]->err[k];
        for (p = 1; p <= 3; p++)
        {
          outstruct->x[i][p] = sys_known[j]->x[k][p];
        }

      }

    }

    n = sys_rand[1]->n;
    SelectRandomQuasars(thr_RAselect, thr_RAlist, &thr_nquasars, &thr_nquasars_select, sys_rand[1], 6.0 / 7.0);
    for (k = 1; k <= n; k++)
    {
      i++;
      select = IsQuasarInList(thr_RAselect, thr_nquasars_select, sys_rand[1]->x[k][2]);
      if (select == 1)
        nyes++;
      else
        nno++;

      outstruct->y[i] = sys_rand[select]->y[k];
      outstruct->err[i] = sys_rand[select]->err[k];
      for (p = 1; p <= 3; p++)
      {
        outstruct->x[i][p] = sys_rand[select]->x[k][p];
      }

    }

    outstruct->n = i;
    outstruct->nx = sys_rand[1]->nx;
    sprintf(thr_ostring, "%d/sysdraw_run.dat", thr_num);
    write_data(outstruct, thr_ostring, "autofit nodipolebootstrap", 3);
    sprintf(thr_ostring, "nice -n 5 alphafit %d/sysdraw_run.dat %d", thr_num, thr_num);
    system(thr_ostring);
    sprintf(thr_ostring, "%d/autofit_results.txt", thr_num);
    GetParmFromAutofitFile(thr_ostring, "LTS_scale", thr_istring);
    scale = atof(thr_istring);
    for (i = 1; i <= outstruct->n; i++)
    {
      dtemp = outstruct->err[i];
      outstruct->err[i] = sqrt((dtemp * dtemp) + (scale * scale));
    }

    n = OT->n;
    j = outstruct->n;
    for (i = 1; i <= n; i++)
    {
      j++;
      outstruct->y[j] = OT->y[i];
      outstruct->err[j] = OT->err[i];
      for (p = 1; p <= 3; p++)
      {
        outstruct->x[j][p] = OT->x[i][p];
      }

    }

    outstruct->n += OT->n;
    sprintf(thr_ostring, "%d/sysdraw_run_noauto.dat", thr_num);
    strcpy(thr_headerwrite, "noerrorincrease ");
    if (dosys_ltsbadres)
      strcat(thr_headerwrite, "nodipolebootstrap ");

    write_data(outstruct, thr_ostring, thr_headerwrite, 3);
    sprintf(thr_ostring, "%d/sysdraw_run.dat", thr_num);
    strcat(thr_headerwrite, "autofit ");
    write_data(outstruct, thr_ostring, thr_headerwrite, 3);
    sprintf(thr_ostring, "nice -n 5 alphafit %d/sysdraw_run.dat %d", thr_num, thr_num);
    system(thr_ostring);
    sprintf(thr_ostring, "%d/autofit_results.txt", thr_num);
    GetParmFromAutofitFile(thr_ostring, "dipole_significance", thr_istring);
    sr->sig[ic] = atof(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "monopole_significance", thr_istring);
    sr->msig[ic] = atof(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "LTS_nbadres", thr_istring);
    sr->nbad[ic] = atoi(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "LTS_badres_rms", thr_istring);
    sr->badresrms[ic] = atof(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "chisq", thr_istring);
    sr->chisq[ic] = atof(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "numpoints", thr_istring);
    sr->numpoints[ic] = atof(thr_istring);
    GetParmFromAutofitFile(thr_ostring, "numparms", thr_istring);
    sr->numparms[ic] = atof(thr_istring);
    deallocate_multspace(outstruct, 10000, 3);
    free(thr_ostring);
    free(thr_istring);
    free(thr_dir);
    free(thr_headerwrite);
    free(thr_RAlist);
    free(thr_RAselect);
    {
      icdone++;
      fp = fopen("sysdraw_status.txt", "w");
      printf("########COMPLETED ITERATION %d of %d###########\n", icdone, 1000);
      fprintf(fp, "########COMPLETED ITERATION %d of %d###########\n", icdone, 1000);
      fclose(fp);
      fp = fopen("sysdraw_dipolesig_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->sig[ic]);
      fclose(fp);
      fp = fopen("sysdraw_monopolesig_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->msig[ic]);
      fclose(fp);
      fp = fopen("sysdraw_LTSnbad_prog.dat", "a");
      fprintf(fp, "%lf\n", (double) sr->nbad[ic]);
      fclose(fp);
      fp = fopen("sysdraw_LTSbadres_rms_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->badresrms[ic]);
      fclose(fp);
      fp = fopen("sysdraw_LTS_scale_prog.dat", "a");
      fprintf(fp, "%lf\n", scale);
      fclose(fp);
      fp = fopen("sysdraw_AICC_prog.dat", "a");
      thr_k = sr->numparms[ic] + 0.0;
      thr_n = sr->numpoints[ic];
      thr_AICC = (sr->chisq[ic] + (2 * thr_k)) + (((2.0 * thr_k) * (thr_k + 1.0)) / ((thr_n - thr_k) - 1.0));
      fprintf(fp, "%lf\n", thr_AICC);
      fclose(fp);
      fp = fopen("sysdraw_chisq_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->chisq[ic]);
      fclose(fp);
      fp = fopen("sysdraw_numparms_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->numparms[ic]);
      fclose(fp);
      fp = fopen("sysdraw_numpoints_prog.dat", "a");
      fprintf(fp, "%lf\n", sr->numpoints[ic]);
      fclose(fp);
    }
  }

  fp = fopen("sysdraw_dipolesig.dat", "w");
  for (i = 1; i <= 1000; i++)
  {
    fprintf(fp, "%lf\n", sr->sig[i]);
  }

  fclose(fp);

  int n;
  int nthreads = 1;
  int i;
  int j;
  int seed;
  double x;
  double sum = 0.0;
  double priv_sum = 0.0;
  double t0;
  double t1;
  struct drand48_data drand_buf;
  if (argc > 1)
  {
    nthreads = atoi(argv[1]);
  }

  n = 100000000;
  t0 = omp_get_wtime();
  #pragma omp parallel num_threads(nthreads) private(seed, drand_buf, x, priv_sum)
  {
    #pragma omp for
    for (i = 0; i < n; i++)
    {
      seed = 1202107158 + (omp_get_thread_num() * 1999);
      srand48_r(seed, &drand_buf);
      drand48_r(&drand_buf, &x);
      priv_sum += x;
    }

    #pragma omp critical
    sum += priv_sum;
  }
  t1 = omp_get_wtime();
  printf("time: %7.3f\n", t1 - t0);
  printf("sum: %f\n", sum);
}

