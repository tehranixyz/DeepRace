struct cell_t
{
  int row;
  int col;
  int *list;
  int *base_array;
  int n_allowed;
  int value;
};
int is_allowed(cell_t *this, int val);
int add_allowed(cell_t *, int);
int remove_allowed(cell_t *this, int val);
int set_value(cell_t *, int);
struct pool_t;
struct pool_t
{
  cell_t **arr_boards;
  int sz_alloc;
  int sz;
};
workpool_t *workpool;
board_store_t *store;
cell_t *solved_board;
int solved;
int push_mem(board_store_t *pool, cell_t *board)
{
  int retval = 0;
  if (omp_in_parallel() != 0)
  {
    {
      if (!not_full(pool))
      {
        cell_t **oldarr = pool->arr_boards;
        pool->arr_boards = malloc((2 * pool->sz_alloc) * (sizeof(cell_t *)));
        memcpy(pool->arr_boards, oldarr, pool->sz_alloc * (sizeof(cell_t *)));
        pool->sz_alloc *= 2;
        free(oldarr);
        retval = 1;
      }

      pool->arr_boards[pool->sz] = board;
      pool->sz++;
    }
  }
  else
  {
    if (!not_full(pool))
    {
      cell_t **oldarr = pool->arr_boards;
      pool->arr_boards = malloc((2 * pool->sz_alloc) * (sizeof(cell_t *)));
      memcpy(pool->arr_boards, oldarr, pool->sz_alloc * (sizeof(cell_t *)));
      pool->sz_alloc *= 2;
      free(oldarr);
      retval = 1;
    }

    pool->arr_boards[pool->sz] = board;
    pool->sz++;
  }

  return retval;
}

