static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int shrd;
int main()
{
  remove("calculations.txt");
  if (argc == 2)
  {
    int nthreads = atoi(argv[1]);
    int n = 1000000 * 100;
    float dx = 1.0 / (((float) n) + 1.0);
    double x = 0;
    double y = 0;
    #pragma omp parallel for private(x)
    for (int i = 0; i < n; i++)
    {
      x = i * dx;
      y = ((exp(x) * cos(x)) * sin(x)) * sqrt((5 * x) + 6.0);
      if (((i % 1000000) == 0) && (i != 0))
      {
        #pragma omp critical
        {
        }
      }

    }

  }

  return 0;

  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    int i;
    #pragma omp for shared (shrd)
    for (i = 0; i < thds; i++)
    {
      shrd += 1;
    }

  }
  printf("err_shared 001 : FAILED, can not compile this program.\n");
  return 1;
}

