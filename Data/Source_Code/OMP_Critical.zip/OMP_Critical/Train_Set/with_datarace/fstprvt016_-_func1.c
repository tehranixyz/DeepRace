static char rcsid[] = "$Id$";
int errors = 0;
int thds;
void *prvt;
void func1(int magicno, void **prvt)
{
  int id = omp_get_thread_num();
  if ((*prvt) != ((void *) magicno))
  {
    errors += 1;
  }

  *prvt = (void *) id;
  #pragma omp barrier
  if ((*prvt) != ((void *) id))
  {
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(void *)))
  {
    errors += 1;
  }


  FILE *fp;
  FILE *fpmag;
  FILE *fpkcorr;
  char aa[1000];
  float rmin;
  float rmax;
  float dlogr;
  float r;
  float dx;
  float dy;
  float dz;
  float xt;
  float rcube = 125;
  float BUF = 20;
  float x1;
  float r1;
  float y1;
  float z1;
  float zz1;
  float ra1;
  float x11;
  float kcorr;
  float deltaz;
  int nr = 14;
  int ngal;
  int ngal2;
  int i;
  int j;
  int k;
  int nmock;
  int ibin;
  int nrandoms;
  int **npairs_dr2;
  int ngal_tot;
  double **nrand;
  double ***nrand_jack;
  float *x;
  float *y;
  float *z;
  float *x2;
  float *y2;
  float *z2;
  float *rx1;
  float *rx2;
  float *ry1;
  float *ry2;
  float *rz1;
  float *rz2;
  float *xg;
  float *yg;
  int nrand1;
  int nrand2;
  double npairs_tot;
  double *rbar;
  double nratio;
  double DR1;
  double DR2;
  double RR;
  double DD;
  double xi;
  double **pibar;
  double **npairs;
  double **npairs_dr1;
  float maglo = -10;
  float maghi = -30;
  float zlo = 0;
  float zhi = 1;
  float zmin;
  float zmax;
  float theta;
  int nz;
  int jbin;
  int ntmp;
  int CALC_RR_COUNTS = 0;
  int input_code = 2;
  float lx;
  float ly;
  float lz;
  float pi;
  float phi;
  float PI_MAX;
  float weight;
  float *gweight;
  double **nx;
  double ***nxj;
  int njack1;
  int nby5;
  int nsby5;
  int ii;
  int *subindx;
  int ijack;
  int n;
  double ***npairs_dr1_jack;
  double ***npairs_jack;
  int ijack1;
  int ijack2;
  int jjack;
  int njack_ra;
  int njack_dec;
  int njack_tot;
  int njack = 10;
  float dx_jack = 15;
  float dy_jack = 0.1;
  float ra_min = 100;
  float dec_min = -0.07;
  float *gal_ra;
  float *gal_dec;
  float *gal_dec2;
  float *ran_ra;
  float *ran_dec;
  float *rweight;
  int id;
  int idp;
  int id2;
  float *rancnt_jack;
  float *galcnt_jack;
  float xi_err;
  float xi_jack;
  float xi_bar;
  double ngal_tmp;
  double nrand_tmp;
  float xi_data[30];
  float xij[200 * 200][30];
  float covar[30][30];
  float jack_ralo[1000];
  float jack_rahi[1000];
  float jack_declo[1000];
  float jack_dechi[1000];
  FILE *fpcovar;
  FILE *fpjack;
  int *jackvect;
  int *rjackvect;
  int *isurvey;
  int RANDWEIGHTS = 1;
  double ngalx;
  double xx;
  double **nd;
  double ***ndj;
  float dn4k_split;
  float *gal_dn4k;
  float *gal_z;
  int ABOVE_SPLIT;
  int SPLIT = 0;
  FILE *fpdn4k;
  float *rsqr;
  float box_min;
  float box_max;
  float rmax_small;
  float rmax_small_sqr;
  float xmin;
  float xmax;
  float rsearch;
  int *meshparts;
  int ***meshstart;
  int nmesh;
  int meshfac;
  int nbrmax;
  int *indx;
  int *meshpartsr;
  int ***meshstartr;
  int nmeshr;
  int meshfacr;
  int j1;
  int i1;
  int *meshpartsr2;
  int ***meshstartr2;
  int nmeshr2;
  int meshfacr2;
  int ismall;
  int nrand1_large;
  int nrandx;
  int irank;
  int nrank;
  int flag = 0;
  float t0;
  float t1;
  float ctime1;
  float ctime2;
  float *rx;
  float **pix;
  int p;
  int ix;
  int iy;
  int iz;
  int iix;
  int iiy;
  int iiz;
  int ir;
  int nbr;
  int iiix;
  int iiiy;
  int iiiz;
  int ntot;
  float rmax2;
  float side;
  float side2;
  float sinv;
  SPEED_OF_LIGHT = 1;
  if (argc < 4)
  {
    fprintf(stderr, "wp_LS_weight galdat1 rand1.dat RR_file [covarfile] [collision_weight1] [collision_weight2] [rmin] [rmax] [nrbin] [njack_per_side] [pi_max]> wp.dat\n");
    exit(0);
  }

  COLLISION_WEIGHT = 2.64;
  if (argc > 5)
    COLLISION_WEIGHT = atof(argv[5]);

  if (argc > 6)
    COLLISION_WEIGHT2 = atof(argv[6]);

  fprintf(stderr, "collision_weight= %f\n", COLLISION_WEIGHT);
  fprintf(stderr, "collision_weight2= %f\n", COLLISION_WEIGHT2);
  rmin = 0.2;
  rmax = 60.0;
  nr = 10;
  dlogr = log(rmax / rmin) / nr;
  zmin = 0;
  PI_MAX = (zmax = 60);
  if (argc > 11)
    PI_MAX = (zmax = atof(argv[11]));

  nz = (int) zmax;
  deltaz = (zmax - zmin) / nz;
  if (argc > 7)
    rmin = atof(argv[7]);

  if (argc > 8)
    rmax = atof(argv[8]);

  if (argc > 9)
    nr = atoi(argv[9]);

  dlogr = log(rmax / rmin) / nr;
  fprintf(stderr, "rmin= %f, rmax= %f, nrbin= %d\n", rmin, rmax, nr);
  njack1 = 5;
  if (argc > 10)
    njack1 = atoi(argv[10]);

  njack_tot = njack1 * njack1;
  fprintf(stderr, "Njack1= %d (total jacks= %d)\n", njack1, njack_tot);
  rsearch = sqrt((rmax * rmax) + (PI_MAX * PI_MAX));
  npairs = dmatrix(1, nr, 1, nz);
  npairs_dr1 = dmatrix(1, nr, 1, nz);
  npairs_dr2 = imatrix(1, nr, 1, nz);
  rbar = dvector(1, nr);
  pibar = dmatrix(1, nr, 1, nz);
  for (i = 1; i <= nr; ++i)
    for (j = 1; j <= nz; ++j)
    npairs[i][j] = (rbar[i] = (npairs_dr1[i][j] = (npairs_dr2[i][j] = (pibar[i][j] = 0))));


  npairs_jack = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
  npairs_dr1_jack = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
  for (i = 0; i < njack_tot; ++i)
    for (j = 1; j <= nr; ++j)
    for (k = 1; k <= nz; ++k)
    npairs_jack[i][j][k] = (npairs_dr1_jack[i][j][k] = 0);



  fp = openfile(argv[1]);
  ngal = filesize(fp);
  x = vector(1, ngal);
  y = vector(1, ngal);
  z = vector(1, ngal);
  jackvect = ivector(1, ngal);
  isurvey = ivector(1, ngal);
  gweight = vector(1, ngal);
  gal_ra = vector(1, ngal);
  gal_dec = vector(1, ngal);
  gal_dec2 = vector(1, ngal);
  gal_z = vector(1, ngal);
  jackvect = ivector(1, ngal);
  xg = vector(1, ngal);
  yg = vector(1, ngal);
  subindx = ivector(1, ngal);
  indx = ivector(1, ngal);
  for (j = 1; j <= ngal; ++j)
  {
    fscanf(fp, "%f %f %f %f %d", &x1, &y1, &z1, &gweight[j], &isurvey[j]);
    xg[j] = x1;
    yg[j] = y1;
    jackvect[j] = 1;
    z1 /= SPEED_OF_LIGHT;
    fgets(aa, 1000, fp);
    gal_dec2[j] = (y1 * 3.14159) / 180.;
    phi = x1;
    theta = (3.14159 / 2.0) - y1;
    phi = (x1 * 3.14159) / 180.0;
    theta = (3.14159 / 2.0) - ((y1 * 3.14159) / 180.0);
    zz1 = z1;
    z1 = redshift_distance(z1);
    x[j] = (z1 * sin(theta)) * cos(phi);
    y[j] = (z1 * sin(theta)) * sin(phi);
    z[j] = z1 * cos(theta);
    gal_ra[j] = phi;
    gal_dec[j] = gal_dec2[j];
    gal_z[j] = zz1;
    indx[j] = j;
  }

  fprintf(stderr, "Read [%d/%d] galaxies from file [%s]\n", j, ngal, argv[1]);
  fflush(stdout);
  fclose(fp);
  sort2(ngal, yg, indx);
  nby5 = ngal / njack1;
  for (i = 0; i < njack1; ++i)
  {
    for (n = 0, j = (i * nby5) + 1; j <= ((i + 1) * nby5); ++j)
    {
      n++;
      id = indx[j];
      yg[n] = gal_ra[id];
      subindx[n] = id;
    }

    sort2(n, yg, subindx);
    nsby5 = n / njack1;
    for (ii = 0; ii < njack1; ++ii)
      for (k = 0, j = (ii * nsby5) + 1; j <= ((ii + 1) * nsby5); ++j)
    {
      k++;
      id = subindx[j];
      jackvect[id] = i + (ii * njack1);
    }


  }

  free_vector(xg, 1, ngal);
  free_vector(yg, 1, ngal);
  free_ivector(subindx, 1, ngal);
  free_ivector(indx, 1, ngal);
  for (i = 1; i <= (-ngal); ++i)
    printf("GAL %f %f %d\n", gal_ra[i], gal_dec2[i], jackvect[i]);

  for (i = 1; i <= ngal; ++i)
  {
    isurvey[i] = 1;
  }

  fp = openfile(argv[2]);
  nrand1 = filesize(fp);
  rx1 = vector(1, nrand1);
  ry1 = vector(1, nrand1);
  rz1 = vector(1, nrand1);
  rweight = vector(1, nrand1);
  rjackvect = ivector(1, nrand1);
  ran_ra = vector(1, nrand1);
  ran_dec = vector(1, nrand1);
  xg = vector(1, nrand1);
  yg = vector(1, nrand1);
  subindx = ivector(1, nrand1);
  indx = ivector(1, nrand1);
  for (i = 1; i <= nrand1; ++i)
  {
    fscanf(fp, "%f %f", &rx1[i], &ry1[i]);
    if (RANDWEIGHTS)
      fscanf(fp, "%f", &rweight[i]);
    else
      rweight[i] = 1;

    yg[i] = ry1[i];
    indx[i] = i;
    rjackvect[i] = -1;
    ran_ra[i] = (rx1[i] * 3.14159) / 180.;
    ran_dec[i] = (ry1[i] * 3.14159) / 180.;
    phi = rx1[i] * (3.14159 / 180.0);
    theta = (3.14159 / 2.0) - (ry1[i] * (3.14159 / 180.0));
    zz1 = (z1 = random_redshift_from_data(ngal, gal_z));
    z1 = redshift_distance(z1);
    fgets(aa, 1000, fp);
    rx1[i] = (z1 * sin(theta)) * cos(phi);
    ry1[i] = (z1 * sin(theta)) * sin(phi);
    rz1[i] = z1 * cos(theta);
  }

  fclose(fp);
  fprintf(stderr, "Read [%d] randoms from file [%s]\n", nrand1, argv[2]);
  sort2(nrand1, yg, indx);
  nby5 = ((nrand1 * 1.) / njack1) * 1.;
  ntot = 0;
  for (i = 0; i < njack1; ++i)
  {
    for (n = 0, j = (i * nby5) + 1; j <= ((i + 1) * nby5); ++j)
    {
      n++;
      ntot++;
      id = indx[j];
      yg[n] = ran_ra[id];
      subindx[n] = id;
      if (((i + 1) == njack1) && (ntot == nrand1))
        break;

    }

    sort2(n, yg, subindx);
    nsby5 = (n / njack1) + 1;
    for (k = 0, ii = 0; ii < njack1; ++ii)
      for (j = (ii * nsby5) + 1; j <= ((ii + 1) * nsby5); ++j)
    {
      k++;
      id = subindx[j];
      rjackvect[id] = i + (ii * njack1);
      if (k == n)
        break;

    }


  }

  for (i = 1; i <= (-nrand1); ++i)
    if (rjackvect[i] == 0)
    printf("RAND %f %f %d\n", ran_ra[i] * (180 / 3.14159), ran_dec[i], rjackvect[i]);


  free_vector(xg, 1, nrand1);
  free_vector(yg, 1, nrand1);
  free_ivector(subindx, 1, nrand1);
  free_ivector(indx, 1, nrand1);
  for (i = 0; i < njack_tot; ++i)
  {
    jack_ralo[i] = 10000;
    jack_declo[i] = 10000;
    jack_rahi[i] = -1000;
    jack_dechi[i] = -1000;
    for (j = 1; j <= nrand1; ++j)
    {
      if (rjackvect[j] != i)
        continue;

      if (ran_ra[j] < jack_ralo[i])
        jack_ralo[i] = ran_ra[j];

      if (ran_dec[j] < jack_declo[i])
        jack_declo[i] = ran_dec[j];

      if (ran_ra[j] > jack_rahi[i])
        jack_rahi[i] = ran_ra[j];

      if (ran_dec[j] > jack_dechi[i])
        jack_dechi[i] = ran_dec[j];

    }

  }

  k = 0;
  for (i = 1; i <= nrand1; ++i)
  {
    if (rjackvect[i] >= 0)
      continue;

    for (j = 0; j < (-njack_tot); ++j)
    {
      if ((ran_ra[i] >= jack_ralo[j]) && (ran_ra[i] < jack_rahi[j]))
        if ((ran_dec[i] >= jack_declo[j]) && (ran_dec[i] < jack_dechi[j]))
      {
        rjackvect[i] = j;
        break;
      }


    }

    if (rjackvect[i] == (-1))
    {
      k++;
    }

  }

  fprintf(stderr, "%d randoms still with no home!\n", k);
  k = 0;
  for (i = 1; i <= ngal; ++i)
  {
    jackvect[i] = -1;
    for (j = 0; j < njack_tot; ++j)
    {
      if ((gal_ra[i] >= jack_ralo[j]) && (gal_ra[i] < jack_rahi[j]))
        if ((gal_dec[i] >= jack_declo[j]) && (gal_dec[i] < jack_dechi[j]))
      {
        jackvect[i] = j;
        break;
      }


    }

    if (jackvect[i] == (-1))
    {
      k++;
      jackvect[i] = jackvect[i + 1];
    }

  }

  fprintf(stderr, "%d gals with no jack\n", k);
  SKIP_JACKS:
  xmax = 0;

  xmin = 100000;
  for (i = 1; i <= ngal; ++i)
  {
    if (x[i] < xmin)
      xmin = x[i];

    if (y[i] < xmin)
      xmin = y[i];

    if (z[i] < xmin)
      xmin = z[i];

    if (x[i] > xmax)
      xmax = x[i];

    if (y[i] > xmax)
      xmax = y[i];

    if (z[i] > xmax)
      xmax = z[i];

  }

  for (i = 1; i <= nrand1; ++i)
  {
    if (rx1[i] < xmin)
      xmin = rx1[i];

    if (ry1[i] < xmin)
      xmin = ry1[i];

    if (rz1[i] < xmin)
      xmin = rz1[i];

    if (rx1[i] > xmax)
      xmax = rx1[i];

    if (ry1[i] > xmax)
      xmax = ry1[i];

    if (rz1[i] > xmax)
      xmax = rz1[i];

  }

  box_min = xmin - rsearch;
  box_max = xmax + rsearch;
  fprintf(stderr, "Dimensions: %f %f\n", box_min, box_max);
  nmesh = 0;
  meshlink2(ngal, &nmesh, box_min, box_max, rsearch, &x[1], &y[1], &z[1], &meshparts, &meshstart, meshfac);
  nmeshr = 0;
  meshlink2(nrand1, &nmeshr, box_min, box_max, rsearch, &rx1[1], &ry1[1], &rz1[1], &meshpartsr, &meshstartr, meshfacr);
  CALC_RR_COUNTS = 1;
  if (CALC_RR_COUNTS)
  {
    fprintf(stderr, "Calculating RR pairs...\n");
    nrand = dmatrix(1, nr, 1, nz);
    nrand_jack = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
    for (i = 1; i <= nr; ++i)
      for (j = 1; j <= nz; ++j)
      nrand[i][j] = 0;


    for (i = 1; i <= nr; ++i)
      for (j = 1; j <= nz; ++j)
      for (k = 0; k < njack_tot; ++k)
      nrand_jack[k][i][j] = 0;



    ctime1 = omp_get_wtime();
    #pragma omp parallel shared(rx1,ry1,rz1,meshpartsr, meshstartr,nrand1,flag) private(nx, nxj, i, j, k, j1, i1, irank, nrank,indx,rsqr,nbrmax,ibin,jbin,dx,dy,dz,lx,ly,lz,pi,r,ctime2,rx2,ry2,rz2,meshpartsr2,meshstartr2, p, ix,iy,iz,iix,iiy,iiz,ir,rmax2,nbr,side,side2,sinv,iiix,iiiy,iiiz,id,id2)
    {
      irank = omp_get_thread_num();
      nrank = omp_get_num_threads();
      if (!irank)
        fprintf(stderr, "Num threads: %d %d\n", nrank, nmeshr);

      nx = dmatrix(1, nr, 1, nz);
      nxj = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
      for (i1 = 1; i1 <= nr; ++i1)
        for (j = 1; j <= nz; ++j)
        nx[i1][j] = 0;


      for (i1 = 1; i1 <= nr; ++i1)
        for (j = 1; j <= nz; ++j)
        for (k = 0; k < njack_tot; ++k)
        nxj[k][i1][j] = 0;



      indx = malloc(nrand1 * (sizeof(int)));
      rsqr = malloc(nrand1 * (sizeof(float)));
      #pragma omp barrier
      for (i = 1 + irank; i <= nrand1; i += nrank)
      {
        if (((i % 10000) == 1) && (!irank))
        {
          fprintf(stderr, "%d\n", i);
        }

        nbrmax = nrand1;
        nbrsfind2(box_min, box_max, rsearch, nmeshr, rx1[i], ry1[i], rz1[i], &nbrmax, indx, rsqr, &rx1[1], &ry1[1], &rz1[1], meshpartsr, meshstartr, -1);
        for (j1 = 0; j1 < nbrmax; ++j1)
        {
          j = indx[j1] + 1;
          if (j <= i)
            continue;

          dx = rx1[i] - rx1[j];
          dy = ry1[i] - ry1[j];
          dz = rz1[i] - rz1[j];
          lx = 0.5 * (rx1[i] + rx1[j]);
          ly = 0.5 * (ry1[i] + ry1[j]);
          lz = 0.5 * (rz1[i] + rz1[j]);
          pi = (((((dx * lx) + (dy * ly)) + (dz * lz)) / sqrt(((lx * lx) + (ly * ly)) + (lz * lz))) < 0.0) ? (-((((dx * lx) + (dy * ly)) + (dz * lz)) / sqrt(((lx * lx) + (ly * ly)) + (lz * lz)))) : ((((dx * lx) + (dy * ly)) + (dz * lz)) / sqrt(((lx * lx) + (ly * ly)) + (lz * lz)));
          if (pi >= PI_MAX)
            continue;

          r = sqrt((((dx * dx) + (dy * dy)) + (dz * dz)) - (pi * pi));
          if (r < rmin)
            continue;

          ibin = ((int) (log(r / rmin) / dlogr)) + 1;
          jbin = ((int) (pi / deltaz)) + 1;
          if (ibin <= 0)
            continue;

          if (ibin > nr)
            continue;

          if (jbin <= 0)
            continue;

          if (jbin > nz)
            continue;

          nx[ibin][jbin] += rweight[i] * rweight[j];
          id = rjackvect[i];
          id2 = rjackvect[j];
          if ((id == (-1)) || (id2 == (-1)))
            continue;

          nxj[id][ibin][jbin] += rweight[i] * rweight[j];
          if (id != id2)
            nxj[id2][ibin][jbin] += rweight[i] * rweight[j];

        }

      }

      free(indx);
      free(rsqr);
      if (!flag)
      {
        flag = 1;
        ctime2 = omp_get_wtime();
      }

      #pragma omp critical
      {
        for (i = 1; i <= nr; ++i)
          for (j = 1; j <= nz; ++j)
        {
          nrand[i][j] += nx[i][j];
        }


        for (i = 1; i <= nr; ++i)
          for (j = 1; j <= nz; ++j)
          for (k = 0; k < njack_tot; ++k)
          nrand_jack[k][i][j] += nxj[k][i][j];



      }
    }
    ctime2 = omp_get_wtime();
    fprintf(stderr, "TIME %.2f\n", ctime2 - ctime1);
    fp = fopen(argv[3], "w");
    for (i = 1; i <= nr; ++i)
      for (j = 1; j <= nz; ++j)
      fprintf(fp, "%e\n", nrand[i][j]);


    for (ijack = 0; ijack < njack_tot; ++ijack)
      for (i = 1; i <= nr; ++i)
      for (j = 1; j <= nz; ++j)
      fprintf(fp, "%e\n", nrand_jack[ijack][i][j]);



    fclose(fp);
    fprintf(stderr, "Done with the random-random pairs.\n");
    fprintf(stderr, "Outputted random-random pairs to file [%s].\n", argv[3]);
  }

  galcnt_jack = vector(0, njack_tot - 1);
  for (i = 0; i < njack_tot; ++i)
    galcnt_jack[i] = 0;

  ngalx = 0;
  for (i = 1; i <= ngal; ++i)
  {
    ngalx += gweight[i];
    id = jackvect[i];
    if (id < 0)
      continue;

    galcnt_jack[id] += gweight[i];
  }

  j = 0;
  for (i = 0; i < njack_tot; ++i)
  {
    j += galcnt_jack[i];
  }

  fprintf(stderr, "done with galcnt %d %.0f %d\n", ngal, ngalx, j);
  rancnt_jack = vector(0, njack_tot - 1);
  for (i = 0; i < njack_tot; ++i)
    rancnt_jack[i] = 0;

  for (i = 1; i <= nrand1; ++i)
  {
    id = rjackvect[i];
    if (id < 0)
      continue;

    rancnt_jack[id] += rweight[i];
  }

  j = 0;
  for (i = 0; i < njack_tot; ++i)
    j += rancnt_jack[i];

  for (i = 0; i < (-njack_tot); ++i)
    printf("%d %d %.0f %f %f %f %f\n", i, rancnt_jack[i], galcnt_jack[i], jack_ralo[i] * (180 / 3.14159), jack_rahi[i] * (180 / 3.14159), jack_declo[i] * (180 / 3.14159), jack_dechi[i] * (180 / 3.14159));

  fprintf(stderr, "done with rancnt %d %d\n", nrand1, j);
  #pragma omp parallel shared(x,y,z,meshparts, meshstart,ngal,flag, gal_ra, gal_dec2) private(nd, ndj,rx,pix, i, j, k, j1, i1, irank, nrank,indx,rsqr,nbrmax,ibin,jbin,dx,dy,dz,lx,ly,lz,pi,r, ctime2,rx2,ry2,rz2, p, ix,iy,iz,iix,iiy,iiz,ir,rmax2,nbr,side,side2, sinv,iiix,iiiy,iiiz,id,id2,theta, weight)
  {
    irank = omp_get_thread_num();
    nrank = omp_get_num_threads();
    nd = dmatrix(1, nr, 1, nz);
    ndj = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
    rx = vector(1, nr);
    pix = matrix(1, nr, 1, nz);
    for (i = 1; i <= nr; ++i)
    {
      rx[i] = 0;
      for (j = 1; j <= nz; ++j)
        pix[i][j] = 0;

    }

    for (i1 = 1; i1 <= nr; ++i1)
      for (j = 1; j <= nz; ++j)
      nd[i1][j] = 0;


    for (i1 = 1; i1 <= nr; ++i1)
      for (j = 1; j <= nz; ++j)
      for (k = 0; k < njack_tot; ++k)
      ndj[k][i1][j] = 0;



    indx = malloc(ngal * (sizeof(int)));
    rsqr = malloc(ngal * (sizeof(float)));
    for (i = irank + 1; i <= ngal; i += nrank)
    {
      if ((i % 10000) == 0)
        fprintf(stderr, "%d\n", i);

      nbrmax = ngal;
      nbrsfind2(box_min, box_max, rsearch, nmesh, x[i], y[i], z[i], &nbrmax, indx, rsqr, &x[1], &y[1], &z[1], meshparts, meshstart, i - 1);
      for (j1 = 0; j1 < nbrmax; ++j1)
      {
        j = indx[j1] + 1;
        dx = x[i] - x[j];
        dy = y[i] - y[j];
        dz = z[i] - z[j];
        lx = 0.5 * (x[i] + x[j]);
        ly = 0.5 * (y[i] + y[j]);
        lz = 0.5 * (z[i] + z[j]);
        pi = fabs((((dx * lx) + (dy * ly)) + (dz * lz)) / sqrt(((lx * lx) + (ly * ly)) + (lz * lz)));
        if (pi >= PI_MAX)
          continue;

        r = sqrt((((dx * dx) + (dy * dy)) + (dz * dz)) - (pi * pi));
        if (r < rmin)
          continue;

        ibin = ((int) (log(r / rmin) / dlogr)) + 1;
        jbin = ((int) (pi / deltaz)) + 1;
        if (jbin <= 0)
          continue;

        if (jbin > nz)
          continue;

        if (ibin <= 0)
          continue;

        if (ibin > nr)
          continue;

        if (isurvey[i] == isurvey[j])
        {
          theta = angular_separation(gal_ra[i], gal_dec2[i], gal_ra[j], gal_dec2[j]);
          weight = (collision_weight(theta, isurvey[i]) * gweight[i]) * gweight[j];
        }
        else
        {
          weight = gweight[i] * gweight[j];
        }

        nd[ibin][jbin] += weight;
        rx[ibin] += r * weight;
        pix[ibin][jbin] += pi * weight;
        id = jackvect[i];
        id2 = jackvect[j];
        ndj[id][ibin][jbin] += weight;
        if (id != id2)
          ndj[id2][ibin][jbin] += weight;

      }

    }

    free(indx);
    free(rsqr);
    #pragma omp critical
    {
      for (i = 1; i <= nr; ++i)
        for (j = 1; j <= nz; ++j)
        npairs[i][j] += nd[i][j];


      for (i = 1; i <= nr; ++i)
        for (j = 1; j <= nz; ++j)
        pibar[i][j] += pix[i][j];


      for (i = 1; i <= nr; ++i)
        rbar[i] += rx[i];

      for (i = 1; i <= nr; ++i)
        for (j = 1; j <= nz; ++j)
        for (k = 0; k < njack_tot; ++k)
        npairs_jack[k][i][j] += ndj[k][i][j];



    }
    free_dmatrix(nd, 1, nr, 1, nz);
    free_d3tensor(ndj, 0, njack_tot - 1, 1, nr, 1, nz);
    #pragma omp barrier
  }
  fprintf(stderr, "done with gal-gal pairs\n");
  #pragma omp parallel private(nd, ndj,rx,pix, i, j, k, j1, i1, irank, nrank,indx,rsqr,nbrmax,ibin,jbin,dx,dy,dz,lx,ly,lz,pi,r, ctime2,rx2,ry2,rz2, p, ix,iy,iz,iix,iiy,iiz,ir,rmax2,nbr,side,side2, sinv,iiix,iiiy,iiiz,id,id2,theta, weight)
  {
    indx = malloc(nrand1 * (sizeof(int)));
    rsqr = malloc(nrand1 * (sizeof(float)));
    irank = omp_get_thread_num();
    nrank = omp_get_num_threads();
    nd = dmatrix(1, nr, 1, nz);
    ndj = d3tensor(0, njack_tot - 1, 1, nr, 1, nz);
    for (i1 = 1; i1 <= nr; ++i1)
      for (j = 1; j <= nz; ++j)
      nd[i1][j] = 0;


    for (i1 = 1; i1 <= nr; ++i1)
      for (j = 1; j <= nz; ++j)
      for (k = 0; k < njack_tot; ++k)
      ndj[k][i1][j] = 0;



    for (i = 1 + irank; i <= ngal; i += nrank)
    {
      if ((i % 10000) == 1)
        fprintf(stderr, "%d\n", i);

      nbrmax = nrand1;
      nbrsfind2(box_min, box_max, rsearch, nmeshr, x[i], y[i], z[i], &nbrmax, indx, rsqr, &rx1[1], &ry1[1], &rz1[1], meshpartsr, meshstartr, -1);
      for (j1 = 0; j1 < nbrmax; ++j1)
      {
        j = indx[j1] + 1;
        dx = x[i] - rx1[j];
        dy = y[i] - ry1[j];
        dz = z[i] - rz1[j];
        lx = 0.5 * (x[i] + rx1[j]);
        ly = 0.5 * (y[i] + ry1[j]);
        lz = 0.5 * (z[i] + rz1[j]);
        pi = fabs((((dx * lx) + (dy * ly)) + (dz * lz)) / sqrt(((lx * lx) + (ly * ly)) + (lz * lz)));
        if (pi >= PI_MAX)
          continue;

        r = sqrt((((dx * dx) + (dy * dy)) + (dz * dz)) - (pi * pi));
        if (r < rmin)
          continue;

        ibin = ((int) (log(r / rmin) / dlogr)) + 1;
        jbin = ((int) (pi / deltaz)) + 1;
        if (jbin <= 0)
          continue;

        if (jbin > nz)
          continue;

        if (ibin <= 0)
          continue;

        if (ibin > nr)
          continue;

        weight = gweight[i] * rweight[j];
        nd[ibin][jbin] += weight;
        id = jackvect[i];
        id2 = rjackvect[j];
        if ((id == (-1)) || (id2 == (-1)))
          continue;

        ndj[id][ibin][jbin] += weight;
        if (id != id2)
          ndj[id2][ibin][jbin] += weight;

      }

    }

    #pragma omp critical
    {
      for (i = 1; i <= nr; ++i)
        for (j = 1; j <= nz; ++j)
        npairs_dr1[i][j] += nd[i][j];


      for (i = 1; i <= nr; ++i)
        for (j = 1; j <= nz; ++j)
        for (k = 0; k < njack_tot; ++k)
        npairs_dr1_jack[k][i][j] += ndj[k][i][j];



    }
  }
  fprintf(stderr, "done with gal-rand pairs\n");
  fp = fopen("xi2d.dat", "w");
  if (argc > 4)
    fpcovar = fopen(argv[4], "w");
  else
    fpcovar = fopen("covar.dat", "w");

  j = 1;
  for (i = 1; i <= nr; ++i)
  {
    npairs_tot = 0;
    for (j = 1; j <= nz; ++j)
      npairs_tot += npairs[i][j];

    r = rbar[i] / npairs_tot;
    if (!npairs_tot)
      r = exp(dlogr * (i - 0.5)) * rmin;

    xi_data[i] = 0;
    for (j = 1; j <= nz; ++j)
    {
      DD = npairs[i][j] / (((1. * ngalx) * ngalx) / 2);
      RR = nrand[i][j] / (((1. * nrand1) * nrand1) / 2);
      DR1 = npairs_dr1[i][j] / ((1. * nrand1) * ngalx);
      xi = ((DD - (2 * DR1)) + RR) / RR;
      if (xi < (-1))
        xi == (-1);

      xi_data[i] += xi * (zmax / nz);
      fprintf(fp, "%e %e %e %e %e %e %.1f %d\n", r, pibar[i][j] / npairs[i][j], ((DD - (2 * DR1)) + RR) / RR, DD, RR, DR1, npairs[i][j], nrand[i][j]);
    }

    xi_data[i] *= 2;
    xi = xi_data[i];
    fflush(stdout);
    xi_err = 0;
    xi_bar = 0;
    for (k = 0; k < njack_tot; ++k)
    {
      ngal_tmp = ngalx - galcnt_jack[k];
      nrand_tmp = nrand1 - rancnt_jack[k];
      xi_jack = 0;
      for (j = 1; j <= nz; ++j)
      {
        DD = (npairs[i][j] - npairs_jack[k][i][j]) / (((1. * ngal_tmp) * ngal_tmp) / 2.);
        RR = (nrand[i][j] - nrand_jack[k][i][j]) / (((1. * nrand_tmp) * nrand_tmp) / 2.);
        DR1 = (npairs_dr1[i][j] - npairs_dr1_jack[k][i][j]) / ((1. * nrand_tmp) * ngal_tmp);
        xx = ((DD - (2 * DR1)) + RR) / RR;
        if ((isnan(xx) || isinf(xx)) || (xx < (-1)))
          xx = -1;

        xi_jack += xx;
      }

      xi_jack *= 2;
      if (isnan(xi_jack))
        xi_jack = xi;

      xi_bar += xi_jack / njack_tot;
      if (i == (-nr))
        printf("%d %d %e %e %e %.0f %d\n", i, k, xi_jack, xi, xi_bar, galcnt_jack[k], rancnt_jack[k]);

    }

    xi_data[i] = xi_bar;
    xi_err = 0;
    for (k = 0; k < njack_tot; ++k)
    {
      ngal_tmp = ngalx - galcnt_jack[k];
      nrand_tmp = nrand1 - rancnt_jack[k];
      xi_jack = 0;
      for (j = 1; j <= nz; ++j)
      {
        DD = (npairs[i][j] - npairs_jack[k][i][j]) / (((1. * ngal_tmp) * ngal_tmp) / 2.);
        RR = (nrand[i][j] - nrand_jack[k][i][j]) / (((1. * nrand_tmp) * nrand_tmp) / 2.);
        DR1 = (npairs_dr1[i][j] - npairs_dr1_jack[k][i][j]) / ((1. * nrand_tmp) * ngal_tmp);
        xx = ((DD - (2 * DR1)) + RR) / RR;
        if ((isnan(xx) || isinf(xx)) || (xx < (-1)))
          xx = -1;

        xi_jack += xx;
      }

      xi_jack *= 2;
      if (isnan(xi_jack))
        xi_jack = xi;

      xi_err += (xi_jack - xi_bar) * (xi_jack - xi_bar);
      xij[k][i] = xi_jack;
    }

    xi_err = sqrt(((njack_tot - 1.) / njack_tot) * xi_err);
    printf("%11.5f %.4e %.4e %10.1f %.4e\n", r, xi, xi_err, npairs_tot, xi_bar);
  }

  fclose(fp);
  for (i = 1; i <= nr; ++i)
    for (j = 1; j <= nr; ++j)
  {
    covar[i][j] = 0;
    for (ijack = 0; ijack < njack_tot; ++ijack)
      covar[i][j] += (xi_data[i] - xij[ijack][i]) * (xi_data[j] - xij[ijack][j]);

    covar[i][j] *= (njack_tot - 1.0) / njack_tot;
    fprintf(fpcovar, "%d %d %e\n", i, j, covar[i][j]);
  }


  fclose(fpcovar);
}

