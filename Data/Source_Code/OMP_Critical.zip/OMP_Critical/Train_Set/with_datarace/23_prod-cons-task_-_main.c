int main(int argc, char **argv)
{
  srand(time(0));
  int size = atoi(argv[1]);
  int queue_size = 15;
  int *vetor = (int *) malloc((sizeof(int)) * size);
  ;
  int prod_pos = 0;
  int cons_pos = 0;
  int produced = 0;
  int consumed = 0;
  #pragma omp parallel
  {
    #pragma omp for nowait
    for (int i = 0; i < size; i++)
    {
      #pragma omp task
      {
        int idx;
        {
          while (consumed >= produced)
            sleep(1);

          idx = cons_pos;
          cons_pos++;
          consumed++;
        }
        consume(vetor, idx % queue_size);
      }
    }

    #pragma omp master
    {
      int i = 0;
      while (i < size)
      {
        if (prod_pos >= (cons_pos % queue_size))
        {
          vetor[prod_pos] = produce();
          produced++;
          prod_pos++;
          if (prod_pos == queue_size)
            prod_pos = 0;

          i++;
        }
        else
        {
          sleep(1);
        }

      }

    }
  }
  return 0;
}

