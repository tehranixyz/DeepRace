static long GLOBAL_failcounter = 0;
void FGNSRdbg_setmallocfail(long next_fail)
{
  assert(next_fail >= 0);
  {
    GLOBAL_failcounter = next_fail;
  }
}

