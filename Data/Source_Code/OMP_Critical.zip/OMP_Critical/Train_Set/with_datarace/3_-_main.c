static long num_steps = 100000000;
double step;
int main(void)
{
  int i;
  double pi;
  step = 1.0 / ((double) num_steps);
  int nthreads;
  omp_set_num_threads(4);
  #pragma omp parallel
  {
    int nthrds;
    int i;
    double sum;
    double x;
    int ID = omp_get_thread_num();
    nthrds = omp_get_num_threads();
    if (ID == 0)
      nthreads = nthrds;

    for (i = ID, sum = 0.0; i < num_steps; i += nthrds)
    {
      x = (i + 0.5) * step;
      sum = sum + (4.0 / (1.0 + (x * x)));
    }

    pi += sum * step;
  }
  printf("pi=%f\n", pi);
  return 0;
}

