int main()
{
  int max = 0;
  srand(time(0));
  #pragma omp parallel
  {
    int local = rand() % 100;
    printf("\n local: %i\n", local);
    {
      if (max < local)
      {
        max = local;
      }

    }
  }
  printf("Maior: %i\n", max);
}

