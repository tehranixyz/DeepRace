{
  int key;
  int value;
} tuple;
int recippar(int *edges, int nrow)
{
  int N = nrow;
  int score = 0;
  int reflexive_nodes = 0;
  tuple *tuples = to_tuple_array(N, edges);
  qsort(tuples, N, sizeof(tuples[0]), comparator_using_tuple);
  #pragma omp parallel shared(score)
  {
    #pragma omp for
    for (int i = 0; i < N; i++)
    {
      if (tuples[i].key != tuples[i].value)
      {
        int index = iter_binarySearch(tuples, 0, N - 1, tuples[i].value);
        if ((-1) != index)
        {
          int curr_r = index;
          int curr_l = index;
          int found = 0;
          while (((found == 0) && (curr_r < N)) && (tuples[curr_r].key == tuples[i].value))
          {
            if (tuples[i].key == tuples[curr_r].value)
            {
              score += 1;
              found = 1;
            }

            curr_r++;
          }

          while (((found == 0) && (curr_l >= 0)) && (tuples[curr_l].key == tuples[i].value))
          {
            if (tuples[i].key == tuples[curr_l].value)
            {
              score += 1;
              found = 1;
            }

            curr_l--;
          }

        }

      }
      else
      {
        reflexive_nodes++;
      }

    }

  }
  printf("score: %d\n", score / 2);
  return score / 2;
}

