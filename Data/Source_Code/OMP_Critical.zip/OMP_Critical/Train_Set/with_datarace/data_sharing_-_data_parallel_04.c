char data_parallel_04(void)
{
  int i;
  int result = 0;
  #pragma omp parallel shared(result) private(i)
  {
    for (i = 0; i < 100; i++)
    {
      result += 1;
    }

  }
  return result == (omp_get_max_threads() * 100);
}

