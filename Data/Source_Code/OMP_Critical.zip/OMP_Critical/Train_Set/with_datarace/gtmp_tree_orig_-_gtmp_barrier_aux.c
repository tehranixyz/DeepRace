{
  int i = 0;
  omp_set_num_threads(5);
  #pragma omp parallel
  {
    printf("A(%d)\n", omp_get_thread_num());
    printf("B(%d)\n", omp_get_thread_num());
    printf("C(%d)\n", omp_get_thread_num());
    #pragma omp critical
    {
      printf("This is Critcal (%d) ", omp_get_thread_num());
      printf("For (%d)", omp_get_thread_num());
      printf("the thread (%d) \n", omp_get_thread_num());
    }
    printf("D(%d)\n", omp_get_thread_num());
    printf("E(%d)\n", omp_get_thread_num());
  }
  return 0;

  int k;
  int count;
  int locksense;
  struct _node_t *parent;
} node_t;
static int num_leaves;
static node_t *nodes;
void gtmp_barrier_aux(node_t *node, int sense);
void gtmp_barrier_aux(node_t *node, int sense)
{
  int test;
  {
    test = node->count;
    node->count--;
  }
  if (1 == test)
  {
    if (node->parent != 0)
      gtmp_barrier_aux(node->parent, sense);

    node->count = node->k;
    node->locksense = !node->locksense;
  }

  while (node->locksense != sense)
    ;

}

