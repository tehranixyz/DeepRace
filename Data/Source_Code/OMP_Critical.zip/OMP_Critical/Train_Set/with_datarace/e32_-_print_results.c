void print_results(float array[50], int tid, int section)
{
  int i;
  int j;
  j = 1;
  {
    printf("\nThread %d did section %d. The results are:\n", tid, section);
    for (i = 0; i < 50; i++)
    {
      printf("%e  ", array[i]);
      j++;
      if (j == 6)
      {
        printf("\n");
        j = 1;
      }

    }

    printf("\n");
  }
  #pragma omp barrier
  printf("Thread %d done and synchronized.\n", tid);

  omp_set_num_threads(2);
  int a = 0;
  int i;
  #pragma omp parallel for
  for (i = 0; i < 20000000; i++)
  {
    #pragma omp critical
    {
      a++;
    }
  }

  printf("a = %d\n", a);
  return 0;
}

