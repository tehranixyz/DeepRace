void VXCgen_grid(double *out, double *coords, double *atm_coords, double *radii_table, int natm, int ngrids)
{
  int i;
  int j;
  int n;
  double dx;
  double dy;
  double dz;
  double dist;
  double *grid_dist = malloc(((sizeof(double)) * natm) * ngrids);
  for (i = 0; i < natm; i++)
  {
    for (n = 0; n < ngrids; n++)
    {
      dx = coords[(n * 3) + 0] - atm_coords[(i * 3) + 0];
      dy = coords[(n * 3) + 1] - atm_coords[(i * 3) + 1];
      dz = coords[(n * 3) + 2] - atm_coords[(i * 3) + 2];
      grid_dist[(i * ngrids) + n] = sqrt(((dx * dx) + (dy * dy)) + (dz * dz));
    }

  }

  for (n = 0; n < (natm * ngrids); n++)
  {
    out[n] = 1;
  }

  #pragma omp parallel default(none) shared(out, grid_dist, atm_coords, radii_table, natm, ngrids) private(i, j, n, dx, dy, dz)
  {
    double *buf = malloc(((sizeof(double)) * natm) * ngrids);
    for (i = 0; i < (natm * ngrids); i++)
    {
      buf[i] = 1;
    }

    int ij;
    double fac;
    double g[ngrids];
    #pragma omp for nowait schedule(static)
    for (ij = 0; ij < (natm * natm); ij++)
    {
      i = ij / natm;
      j = ij % natm;
      if (i <= j)
      {
        continue;
      }

      dx = atm_coords[(i * 3) + 0] - atm_coords[(j * 3) + 0];
      dy = atm_coords[(i * 3) + 1] - atm_coords[(j * 3) + 1];
      dz = atm_coords[(i * 3) + 2] - atm_coords[(j * 3) + 2];
      fac = 1 / sqrt(((dx * dx) + (dy * dy)) + (dz * dz));
      for (n = 0; n < ngrids; n++)
      {
        g[n] = grid_dist[(i * ngrids) + n] - grid_dist[(j * ngrids) + n];
        g[n] *= fac;
      }

      if (radii_table != 0)
      {
        fac = radii_table[(i * natm) + j];
        for (n = 0; n < ngrids; n++)
        {
          g[n] += fac * (1 - (g[n] * g[n]));
        }

      }

      for (n = 0; n < ngrids; n++)
      {
        g[n] = ((3 - (g[n] * g[n])) * g[n]) * .5;
      }

      for (n = 0; n < ngrids; n++)
      {
        g[n] = ((3 - (g[n] * g[n])) * g[n]) * .5;
      }

      for (n = 0; n < ngrids; n++)
      {
        g[n] = ((3 - (g[n] * g[n])) * g[n]) * .5;
        g[n] *= .5;
      }

      for (n = 0; n < ngrids; n++)
      {
        buf[(i * ngrids) + n] *= .5 - g[n];
        buf[(j * ngrids) + n] *= .5 + g[n];
      }

    }

    for (i = 0; i < (natm * ngrids); i++)
    {
      out[i] *= buf[i];
    }

    free(buf);
  }
  free(grid_dist);

  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  init(100);
  #pragma omp parallel firstprivate (prvt)
  {
    int id = omp_get_thread_num();
    int i;
    for (i = 0; i < 1024; i++)
    {
      if (prvt[i] != (100 + i))
      {
        #pragma omp critical
        errors += 1;
      }

    }

    for (i = 0; i < 1024; i++)
    {
      prvt[i] = id + i;
    }

    #pragma omp barrier
    for (i = 0; i < 1024; i++)
    {
      if (prvt[i] != (id + i))
      {
        #pragma omp critical
        errors += 1;
      }

    }

    if ((sizeof(prvt)) != ((sizeof(int)) * 1024))
    {
      #pragma omp critical
      errors += 1;
    }

  }
  init(100 * 2);
  #pragma omp parallel firstprivate (prvt)
  func1(100 * 2, prvt);
  init(100 * 3);
  #pragma omp parallel firstprivate (prvt)
  func2(100 * 3);
  if (errors == 0)
  {
    printf("firstprivate 017 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 017 : FAILED\n");
    return 1;
  }

}

