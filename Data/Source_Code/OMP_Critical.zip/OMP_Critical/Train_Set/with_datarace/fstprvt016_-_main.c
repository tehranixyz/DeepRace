static char rcsid[] = "$Id$";
int errors = 0;
int thds;
void *prvt;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = (void *) 100;
  #pragma omp parallel firstprivate (prvt)
  {
    int id = omp_get_thread_num();
    if (prvt != ((void *) 100))
    {
      errors += 1;
    }

    prvt = (void *) id;
    #pragma omp barrier
    if (prvt != ((void *) id))
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(void *)))
    {
      errors += 1;
    }

  }
  prvt = (void *) (100 * 2);
  #pragma omp parallel firstprivate (prvt)
  func1(100 * 2, &prvt);
  prvt = (void *) (100 * 3);
  #pragma omp parallel firstprivate (prvt)
  func2(100 * 3);
  if (errors == 0)
  {
    printf("firstprivate 016 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 016 : FAILED\n");
    return 1;
  }

}

