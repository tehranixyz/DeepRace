int check_for_schedule_guided(FILE *logFile)
{
  int threads;
  int tids[150];
  int i;
  int *tmp;
  int flag = 0;
  int result = 0;
  int notout = 1;
  int maxiter = 0;
  int count = 0;
  int tmp_count = 0;
  int tid;
  #pragma omp parallel
  {
    #pragma omp single
    {
      threads = omp_get_num_threads();
    }
  }
  if (threads < 2)
  {
    printf("This test only works with at least two threads .\n");
    return 0;
  }

  #pragma omp parallel shared(tids,maxiter) private(tid,count)
  {
    tid = omp_get_thread_num();
    #pragma omp for nowait schedule(guided,7)
    for (i = 0; i < 150; ++i)
    {
      count = 0;
      #pragma omp flush(maxiter)
      if (i > maxiter)
      {
        {
          maxiter = i;
        }
      }

      #pragma omp flush(maxiter,notout)
      while ((notout && (count < 5)) && (maxiter == i))
      {
        my_sleep(1);
        count += 1;
      }

      tids[i] = tid;
    }

    notout = 0;
    #pragma omp flush(notout)
  }
  count = 0;
  for (i = 0; i < (150 - 1); ++i)
  {
    if (tids[i] != tids[i + 1])
    {
      count++;
    }

  }

  tmp = (int *) malloc((count + 1) * (sizeof(int)));
  tmp_count = 0;
  tmp[0] = 1;
  for (i = 0; i < (150 - 1); ++i)
  {
    if (tids[i] == tids[i + 1])
    {
      tmp[tmp_count]++;
    }
    else
    {
      tmp_count++;
      tmp[tmp_count] = 1;
    }

  }

  flag = 0;
  for (i = 0; i < (count - 1); i++)
  {
    if ((i > 0) && (tmp[i] == tmp[i + 1]))
      flag = 1;

    if (flag == 0)
    {
      if (tmp[i] <= tmp[i + 1])
      {
        result++;
        fprintf(logFile, "chunk size from %d to %d not decreased.\n", i, i + 1);
      }

    }
    else
      if (tmp[i] != tmp[i + 1])
    {
      result++;
      fprintf(logFile, "chunk size not maintained.\n");
    }


  }

  return result == 0;
}

