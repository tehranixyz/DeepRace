int main(int argc, char *argv[])
{
  sem_init(&Sem, 0, 1);
  int ThreadId = 0;
  int NReader;
  int NWriter;
  int i;
  int j;
  printf("\nEnter number of readers: ");
  scanf("%d", &NReader);
  printf("\nEnter number of writers: ");
  scanf("%d", &NWriter);
  #pragma omp parallel num_threads( (NReader+NWriter) ) shared(ThreadId)
  {
    printf("\n in parallel construct");
    #pragma omp for nowait
    for (i = 0; i < NReader; i++)
    {
      printf("\nReader started %d", i);
      #pragma omp critical
      {
        ReadCount++;
        if (ReadCount == 1)
          sem_wait(&Sem);

      }
      ThreadId = omp_get_thread_num();
      printf("\n\nReader %d with thread id %d is reading shared variable %d ", i, ThreadId, var);
      #pragma omp critical
      {
        ReadCount--;
        if (ReadCount == 0)
          sem_post(&Sem);

      }
    }

    #pragma omp for nowait
    for (j = 0; j < NWriter; j++)
    {
      printf("\nWriter started %d", j);
      sem_wait(&Sem);
      sleep(1);
      var = var + 2;
      ThreadId = omp_get_thread_num();
      printf("\nWriter %d with ThreadId %d has updated the shared variable to %d ", j, ThreadId, var);
      sem_post(&Sem);
    }

  }

  int M = atoi(argv[1]);
  int N = atoi(argv[1]);
  int K = atoi(argv[1]);
  double ctime;
  double ctime1;
  double ctime2;
  double diff;
  double th_diff;
  double epsilon = atof(argv[2]);
  int num_threads = atoi(argv[3]);
  int i;
  int iterations;
  int j;
  int k;
  double mean;
  omp_set_num_threads(num_threads);
  double *u[M][N];
  for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    u[i][j] = (double *) malloc(K * (sizeof(double)));


  double *w[M][N];
  for (i = 0; i < M; i++)
    for (j = 0; j < N; j++)
    w[i][j] = (double *) malloc(K * (sizeof(double)));


  diff = epsilon;
  mean = 0.0;
  ctime1 = omp_get_wtime();
  #pragma omp parallel shared ( w ) private ( i, j, k )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0][0] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1][0] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j][0] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j][0] = 0.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][0][K - 1] = 100.0;
    }

    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      w[i][N - 1][K - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[M - 1][j][K - 1] = 100.0;
    }

    #pragma omp for
    for (j = 0; j < N; j++)
    {
      w[0][j][K - 1] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[0][0][k] = 0.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[0][N - 1][k] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[M - 1][0][k] = 100.0;
    }

    #pragma omp for
    for (k = 0; k < K; k++)
    {
      w[M - 1][N - 1][k] = 100.0;
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][0][0];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][N - 1][0];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[M - 1][j][0];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[0][j][0];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][0][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (i = 1; i < (M - 1); i++)
    {
      mean = mean + w[i][N - 1][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[M - 1][j][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (j = 0; j < N; j++)
    {
      mean = mean + w[0][j][K - 1];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[0][0][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[0][N - 1][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[M - 1][0][k];
    }

    #pragma omp for reduction ( + : mean )
    for (k = 0; k < K; k++)
    {
      mean = mean + w[M - 1][N - 1][k];
    }

  }
  mean = mean / ((double) ((((4 * M) + (4 * N)) + (4 * K)) - 12));
  #pragma omp parallel shared ( mean, w ) private ( i, j, k )
  {
    #pragma omp for
    for (i = 1; i < (M - 1); i++)
    {
      for (j = 1; j < (N - 1); j++)
      {
        for (k = 1; k < (K - 1); k++)
        {
          w[i][j][k] = mean;
        }

      }

    }

  }
  iterations = 0;
  while (epsilon <= diff)
  {
    #pragma omp parallel shared ( diff, u, w ) private ( i, j,k, th_diff )
    {
      #pragma omp for
      for (i = 0; i < M; i++)
      {
        for (j = 0; j < N; j++)
        {
          for (k = 0; k < K; k++)
          {
            u[i][j][k] = w[i][j][k];
          }

        }

      }

      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          for (k = 1; k < (K - 1); k++)
          {
            w[i][j][k] = (((((u[i - 1][j][k] + u[i + 1][j][k]) + u[i][j - 1][k]) + u[i][j + 1][k]) + u[i][j][k + 1]) + u[i][j][k - 1]) / 6.0;
          }

        }

      }

    }
    diff = 0.0;
    #pragma omp parallel shared ( diff, u, w ) private ( i, j, k,th_diff )
    {
      th_diff = 0.0;
      #pragma omp for
      for (i = 1; i < (M - 1); i++)
      {
        for (j = 1; j < (N - 1); j++)
        {
          for (k = 1; k < (K - 1); k++)
          {
            if (th_diff < fabs(w[i][j][k] - u[i][j][k]))
            {
              th_diff = fabs(w[i][j][k] - u[i][j][k]);
            }

          }

        }

      }

      {
        if (diff < th_diff)
        {
          diff = th_diff;
        }

      }
    }
    iterations++;
  }

  ctime2 = omp_get_wtime();
  ctime = ctime2 - ctime1;
  printf("%d %f\n", iterations, ctime);
  return 0;
}

