int main(void)
{
  int a[] = {2, 3, 4, 6, 7, 8, 9, 0};
  int i;
  int max = a[0];
  int SIZE = 8;
  #pragma omp parallel for num_threads(4)
  for (i = 1; i < SIZE; i++)
  {
    if (a[i] > max)
    {
      #pragma omp critical
      if (a[i] > max)
        max = a[i];

    }

  }

  printf("The max number is %d \n", max);
  return 0;

  int a = 0;
  int b = 0;
  int c = 0;
  #pragma omp parallel
  {
    a = a + 1;
    b = b + 1;
    c = c + 1;
  }
}

