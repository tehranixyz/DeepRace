static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int prvt1;
int prvt2;
int prvt3;
void func(int t)
{
  int i;
  #pragma omp for schedule(static,1) lastprivate (prvt1,prvt2,prvt3)
  for (i = 0; i < thds; i++)
  {
    prvt1 = i;
    prvt2 = i;
    prvt3 = i;
    barrier(t);
    if (prvt1 != i)
    {
      errors += 1;
    }

    if (prvt2 != i)
    {
      errors += 1;
    }

    if (prvt3 != i)
    {
      errors += 1;
    }

    if (i == 0)
    {
      waittime(1);
    }

    prvt1 = i;
    prvt2 = i;
    prvt3 = i;
  }

  if (prvt1 != (thds - 1))
  {
    errors += 1;
  }

  if (prvt2 != (thds - 1))
  {
    errors += 1;
  }

  if (prvt3 != (thds - 1))
  {
    errors += 1;
  }


  int N = atoi(argv[1]);
  int i;
  int j;
  double t1;
  double t2;
  int *V;
  V = (int *) malloc(N * (sizeof(int)));
  int *V2;
  V2 = (int *) malloc(N * (sizeof(int)));
  int **M;
  M = (int **) malloc(N * (sizeof(int *)));
  for (i = 0; i < N; i++)
    M[i] = (int *) malloc(N * (sizeof(int)));

  if (argc < 2)
  {
    fprintf(stderr, "Uso:./ejercicio9 N \n");
    exit(-1);
  }

  srand(time(0));
  #pragma omp parallel for private(j)
  for (i = 0; i < N; i++)
  {
    for (j = 0; j < N; j++)
    {
      M[i][j] = 1;
    }

  }

  #pragma omp parallel for
  for (i = 0; i < N; i++)
    V[i] = i + 1;

  t1 = omp_get_wtime();
  int suma;
  int sumalocal;
  for (i = 0; i < N; i++)
  {
    suma = 0;
    #pragma omp parallel private(sumalocal)
    {
      sumalocal = 0;
      #pragma omp for
      for (j = 0; j < N; j++)
      {
        sumalocal += M[i][j] * V[j];
      }

      #pragma omp critical
      suma += sumalocal;
    }
    V2[i] = suma;
  }

  t2 = omp_get_wtime();
  t2 = t2 - t1;
  if (N < 10)
  {
    printf("M:\n");
    for (i = 0; i < N; i++)
    {
      for (j = 0; j < N; j++)
        printf("%d ", M[i][j]);

      printf("\n");
    }

    printf("\nV:\n");
    for (i = 0; i < N; i++)
      printf("%d \n", V[i]);

    printf("\nResultado MxV:\n");
    for (i = 0; i < N; i++)
      printf("%d ", V2[i]);

  }
  else
  {
    printf("V2[0]:%d\n", V2[0]);
    printf("V2[N-1]:%d\n", V2[N - 1]);
  }

  printf("\nTiempo en ejecutar MxV:%8.7f\n", t2);
  for (i = 0; i < N; i++)
    free(M[i]);

  free(M);
  free(V);
  free(V2);
}

