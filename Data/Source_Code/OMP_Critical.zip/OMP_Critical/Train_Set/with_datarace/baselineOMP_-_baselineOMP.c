float barrierTimeCounter[100000];
void baselineOMP(int numberOfThreads, int numberOfBarriers)
{
  if ((numberOfThreads <= 0) || (numberOfBarriers <= 0))
  {
    printf("\nERROR: Number of threads/barriers cannot be negative!");
    exit(1);
  }

  int i = 0;
  for (i = 0; i < 100000; i++)
  {
    barrierTimeCounter[i] = 0.0;
  }

  omp_set_num_threads(numberOfThreads);
  #pragma omp parallel shared(numberOfThreads)
  {
    struct timeval startTime;
    struct timeval endTime;
    double totalTime;
    numberOfThreads = omp_get_num_threads();
    int i = 0;
    int j = 0;
    int threadID;
    threadID = omp_get_thread_num();
    for (i = 0; i < numberOfBarriers; i++)
    {
      j = 0;
      while (j < 9999)
      {
        j++;
      }

      printf("\nEntered thread %d  of %d threads at barrier %d", threadID, numberOfThreads, i);
      gettimeofday(&startTime, 0);
      #pragma omp barrier
      {
      }
      gettimeofday(&endTime, 0);
      totalTime = ((endTime.tv_sec * 1000000) + endTime.tv_usec) - ((startTime.tv_sec * 1000000) + startTime.tv_usec);
      printf("\nTotal time at barrier %d by thread %d is %f", i, threadID, totalTime);
      {
        barrierTimeCounter[i] += (float) totalTime;
      }
      j = 0;
      while (j < 9999)
      {
        j++;
      }

      printf("\nCompleted thread %d of %d threads at barrier %d", threadID, numberOfThreads, i);
    }

  }
  float totalBarrierTime = 0.0;
  for (i = 0; i < numberOfBarriers; i++)
  {
    printf("\nTime taken at Barrier %d is %f", i, barrierTimeCounter[i]);
    totalBarrierTime += barrierTimeCounter[i];
  }

  printf("\nAverage time taken at Barriers is %f\n", ((float) totalBarrierTime) / numberOfBarriers);
}

