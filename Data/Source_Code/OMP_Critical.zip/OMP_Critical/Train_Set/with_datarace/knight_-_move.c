{
  int id;
  int **board;
  int move_num;
  int x;
  int y;
} Task;
int solutions_counter;
int num_tasks;
void move(int **board, int x, int y, int move_num)
{
  int i;
  int j;
  int k;
  int newx;
  int newy;
  board[x][y] = move_num;
  if (move_num == (6 * 6))
  {
    ++solutions_counter;
  }
  else
  {
    for (i = 0; i < 2; ++i)
      for (j = 0; j < 2; ++j)
      for (k = 1; k < 3; ++k)
    {
      newx = x + (k * ((i * 2) - 1));
      newy = y + ((k - 3) * ((j * 2) - 1));
      if ((((newx >= 0) && (newx < 6)) && (newy >= 0)) && (newy < 6))
      {
        if (board[newx][newy] <= 0)
        {
          move(board, newx, newy, move_num + 1);
          board[newx][newy] = 0;
        }

      }

    }



  }


  while ((residue > tol) && (iter < iter_max))
  {
    residue = 0.0f;
    #pragma omp parallel
    {
      float my_residue = 0.f;
      int i;
      int j;
      #pragma omp for nowait
      for (j = 1; j < (n - 1); j++)
      {
        for (i = 1; i < (m - 1); i++)
        {
          Anew[(j * m) + i] = 0.25f * (((A[(j * m) + (i + 1)] + A[(j * m) + (i - 1)]) + A[((j - 1) * m) + i]) + A[((j + 1) * m) + i]);
          my_residue = fmaxf(my_residue, fabsf(Anew[(j * m) + i] - A[(j * m) + i]));
        }

      }

      #pragma omp critical
      {
        residue = fmaxf(my_residue, residue);
      }
    }
    int i;
    int j;
    for (j = 0; j < (n - 1); j++)
    {
      for (i = 1; i < (m - 1); i++)
      {
        A[(j * m) + i] = Anew[(j * m) + i];
      }

    }

    if ((rank == 0) && ((iter % 100) == 0))
      printf("%5d, %0.6f\n", iter, residue);

    iter++;
  }

}

