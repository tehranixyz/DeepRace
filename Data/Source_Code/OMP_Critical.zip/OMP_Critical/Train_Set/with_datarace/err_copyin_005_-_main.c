static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int org;
int prvt;
#pragma omp threadprivate(prvt);
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt = (org = 1);
  #pragma omp parallel
  {
    {
      if (prvt != org)
      {
        errors += 1;
      }

    }
  }
  printf("err_copyin 005 : FAILED, can not compile this program.\n");
  return 1;
}

