static char rcsid[] = "$Id$";
int errors = 0;
int thds;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  #pragma omp parallel
  {
    static int *heap;
    #pragma omp single
    {
      heap = (int *) malloc(sizeof(int));
      if (heap == 0)
      {
        printf("can not allocate memory.\n");
      }

      *heap = 0;
    }
    *heap += 1;
    #pragma omp barrier
    if ((*heap) != thds)
    {
      errors += 1;
    }

  }
  #pragma omp parallel
  func();
  if (errors == 0)
  {
    printf("attribute 004 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("attribute 004 : FAILED\n");
    return 1;
  }

}

