int main(void)
{
  int A = 0;
  omp_set_nested(1);
  omp_set_max_active_levels(8);
  omp_set_dynamic(0);
  omp_set_num_threads(2);
  #pragma omp parallel
  {
    printf("Hello world from thread %d\n", omp_get_thread_num());
    omp_set_num_threads(3);
    #pragma omp parallel
    {
      A++;
      omp_set_num_threads(4);
      {
        printf("Inner: max_act_lev=%d, num_thds=%d, max_thds=%d, thread_id= %d, parent =%d\n", omp_get_max_active_levels(), omp_get_num_threads(), omp_get_max_threads(), omp_get_thread_num(), omp_get_ancestor_thread_num(1));
      }
    }
    #pragma omp barrier
    printf(" After inner section A = %d \n", A);
    {
      A++;
      printf("Outer: max_act_lev=%d, num_thds=%d, max_thds=%d, thread_id= %d, parent =%d\n", omp_get_max_active_levels(), omp_get_num_threads(), omp_get_max_threads(), omp_get_thread_num(), omp_get_ancestor_thread_num(1));
    }
  }
  printf(" Final A = %d \n", A);
  return 0;

  long int glob_sum = 0;
  int size = 100000;
  int array[size];
  for (int i = 0; i < size; i++)
  {
    array[i] = 2;
  }

  #pragma omp parallel
  {
    int num_threads = omp_get_num_threads();
    int t_num = omp_get_thread_num();
    long int loc_sum = 0;
    for (int i = t_num; i < size; i += num_threads)
    {
      loc_sum += array[i];
    }

    #pragma omp critical
    {
      glob_sum += loc_sum;
    }
  }
  printf("Sum: %ld\n", glob_sum);
}

