static char rcsid[] = "$Id$";
int errors = 0;
int thds;
struct x
{
  int i;
  double d;
};
struct x prvt;
void func(int t)
{
  int i;
  #pragma omp for schedule(static,1) lastprivate (prvt)
  for (i = 0; i < thds; i++)
  {
    prvt.i = i;
    prvt.d = i + 1;
    barrier(t);
    if (prvt.i != i)
    {
      errors += 1;
    }

    if (prvt.d != (i + 1))
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(struct x)))
    {
      errors += 1;
    }

    if (i == 0)
    {
      waittime(1);
    }

    prvt.i = i;
    prvt.d = i + 1;
  }

  if (prvt.i != (thds - 1))
  {
    errors += 1;
  }

  if (prvt.d != ((thds - 1) + 1))
  {
    errors += 1;
  }

}

