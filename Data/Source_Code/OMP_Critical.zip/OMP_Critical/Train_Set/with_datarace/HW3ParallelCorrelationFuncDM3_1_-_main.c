int main()
{
  printf("FIRST of MAIN\n");
  long int i;
  long int j;
  int chunk;
  double dec_to_rad = (2. * 3.14159621234161928) / 360.;
  double deg_to_rad = (2. * 3.14159621234161928) / 360.;
  const int num_bins = 15;
  double logrNOTSQ_min = -1.0;
  double logrNOTSQ_max = 1.3011;
  double logr_min = log10(pow(pow(10., logrNOTSQ_min), 2.));
  double logr_max = log10(pow(pow(10., logrNOTSQ_max), 2.));
  long int errorcounts = 0;
  long int distance_counts[15] = {0};
  long int randdistance_counts[15] = {0};
  double Xi_func[15] = {0.0};
  int dist_index;
  long int FILELENGTHDM = 50000;
  long int FILELENGTHDMrand = 100000;
  static const char DM_datafile[] = "/home/chasonn/LargeScaleHW/HW3Codes/DMCorrelationFunctionParallel/DM.dat";
  FILE *myfile = fopen(DM_datafile, "r");
  if (myfile == 0)
  {
    printf("input_file.txt not opened, exiting...\n");
    exit(0);
  }

  printf("Opened file - Begining assignment.\n");
  long int N_data = FILELENGTHDM;
  double X_LIST[N_data];
  double Y_LIST[N_data];
  double Z_LIST[N_data];
  for (i = 0; i < N_data; i++)
  {
    fscanf(myfile, "%lf", &X_LIST[i]);
    fscanf(myfile, "%lf", &Y_LIST[i]);
    fscanf(myfile, "%lf", &Z_LIST[i]);
    if (i >= (N_data - 2))
    {
      printf("Close or exceeded N_data limit. X: %lf \n", X_LIST[i]);
    }

  }

  fclose(myfile);
  printf("Closing File.\n");
  printf("Beginning Nested Loops...\n");
  printf("Note: using Distance Squared to avoid taking SQRT for index rank.\n");
  double D;
  double logD;
  double r = 0;
  double x1 = 0;
  double y1 = 0;
  double z1 = 0;
  double rj = 0;
  double x2 = 0;
  double y2 = 0;
  double z2 = 0;
  chunk = 50;
  #pragma omp parallel shared( Z_LIST, Y_LIST, X_LIST, N_data, chunk) private (D, logD, x1, y1, z1, x2, y2, z2, dist_index, i, j )
  {
    omp_set_num_threads(32);
    long int sum_local_counts[15];
    memset(sum_local_counts, 0, 15 * (sizeof(sum_local_counts[0])));
    #pragma omp for schedule(guided, chunk)
    for (i = 0; i < (N_data - 1); ++i)
    {
      x1 = X_LIST[i];
      y1 = Y_LIST[i];
      z1 = Z_LIST[i];
      for (j = 0; j < (N_data - 1); ++j)
      {
        if (j != i)
        {
          x2 = X_LIST[j];
          y2 = Y_LIST[j];
          z2 = Z_LIST[j];
          D = (((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2))) + ((z1 - z2) * (z1 - z2));
          logD = log10(D);
          dist_index = (int) floor((logD - logr_min) * (15 / (logr_max - logr_min)));
          if ((dist_index >= 0) && (dist_index < 15))
          {
            if (dist_index >= 15)
              printf("YELLING!");

            sum_local_counts[dist_index] += 1;
          }

        }

      }

    }

    {
      for (i = 0; i < 15; ++i)
      {
        distance_counts[i] += sum_local_counts[i];
      }

    }
  }
  printf("\n*");
  printf("\n   *");
  printf("\n     *");
  printf("\n       *");
  printf("\n      *");
  printf("\n     *");
  printf("\n    *");
  printf("\n   *        *");
  printf("\n   *");
  printf("\n     *");
  printf("\n      *");
  printf("\n       **");
  printf("\n        * *");
  printf("\n        * * *");
  printf("\n       * * * *\n");
  printf("****************************\n");
  printf("FINISHED PRAGMA OMP CRITICAL\n");
  printf("****************************\n");
  printf("FINISHED DM NESTED LOOP. \n");
  printf("Dividing Counts by two to correct double counting...");
  printf("Counts: ");
  for (i = 0; i < 15; ++i)
  {
    distance_counts[i] = (long long) floor(distance_counts[i] / 2.);
    printf("%ld ", distance_counts[i]);
  }

  printf("\n");
  static const char random_datafile[] = "/home/chasonn/LargeScaleHW/HW3Codes/DMCorrelationFunctionParallel/DM_random.dat";
  long int N_rand = FILELENGTHDMrand;
  FILE *myrandfile = fopen(random_datafile, "r");
  if (myrandfile == 0)
  {
    printf("input_file.txt not opened, exiting...\n");
    exit(0);
  }

  double randX_LIST[N_rand];
  double randY_LIST[N_rand];
  double randZ_LIST[N_rand];
  for (i = 0; i < N_rand; ++i)
  {
    fscanf(myrandfile, "%lf", &randX_LIST[i]);
    fscanf(myrandfile, "%lf", &randY_LIST[i]);
    fscanf(myrandfile, "%lf", &randZ_LIST[i]);
    if (i >= (N_rand - 2))
    {
      printf("Close or exceeded N_data limit. X: %lf \n", randX_LIST[i]);
    }

  }

  fclose(myrandfile);
  printf("Closing File.\n");
  printf("Beginning Random Nested Loops...\n");
  #pragma omp parallel shared( randZ_LIST, randY_LIST, randX_LIST, N_rand,chunk) private (D, logD, x1, y1, z1, x2, y2, z2, dist_index, i, j )
  {
    omp_set_num_threads(32);
    long int sum_local_counts[15];
    memset(sum_local_counts, 0, 15 * (sizeof(sum_local_counts[0])));
    #pragma omp for schedule(guided, chunk)
    for (i = 0; i < (N_rand - 1); ++i)
    {
      x1 = randX_LIST[i];
      y1 = randY_LIST[i];
      z1 = randZ_LIST[i];
      for (j = 0; j < (N_rand - 1); ++j)
      {
        if (j != i)
        {
          x2 = randX_LIST[j];
          y2 = randY_LIST[j];
          z2 = randZ_LIST[j];
          D = (((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2))) + ((z1 - z2) * (z1 - z2));
          logD = log10(D);
          dist_index = (int) floor((logD - logr_min) * (15 / (logr_max - logr_min)));
          if ((dist_index >= 0) && (dist_index < 15))
          {
            if (dist_index >= 15)
              printf("YELLING!");

            sum_local_counts[dist_index] += 1;
          }

        }

      }

    }

    {
      for (i = 0; i < 15; ++i)
      {
        randdistance_counts[i] += sum_local_counts[i];
      }

    }
  }
  printf("FINISHED RANDOM NESTED LOOPS! \n");
  printf("Counts: ");
  for (i = 0; i < 15; ++i)
  {
    randdistance_counts[i] = (long long) floor(randdistance_counts[i] / 2.);
    printf("%ld ", randdistance_counts[i]);
  }

  printf("\n");
  printf("Calculating DM Correlation Function...\n");
  double ratio = ((double) N_rand) / ((double) N_data);
  for (i = 0; i < 15; i++)
  {
    Xi_func[i] = ((ratio * ratio) * (((double) distance_counts[i]) / ((double) randdistance_counts[i]))) - 1.0;
    printf("%.2lf ", Xi_func[i]);
  }

  printf("\n");
  printf("Saving DM counts to file.\n");
  FILE *fp_out;
  fp_out = fopen("output_DMcounts.txt", "w");
  if (fp_out == 0)
  {
    printf("output_file.txt not opened, exiting...\n");
    exit(0);
  }

  for (i = 0; i < 15; i++)
  {
    fprintf(fp_out, "%ld \n", distance_counts[i]);
  }

  fclose(fp_out);
  printf("Saving Random counts to file.\n");
  fp_out = fopen("output_counts_DMrandom.txt", "w");
  if (fp_out == 0)
  {
    printf("output_file.txt not opened, exiting...\n");
    exit(0);
  }

  for (i = 0; i < 15; i++)
  {
    fprintf(fp_out, "%ld \n", randdistance_counts[i]);
  }

  fclose(fp_out);
  printf("Saving Xi-DM to file.\n");
  fp_out = fopen("output_Xi_DM.txt", "w");
  if (fp_out == 0)
  {
    printf("output_file.txt not opened, exiting...\n");
    exit(0);
  }

  for (i = 0; i < 15; i++)
  {
    fprintf(fp_out, "%f \n", Xi_func[i]);
  }

  fclose(fp_out);
  return 0;
}

