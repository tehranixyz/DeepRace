{
  double init;
  double end;
  struct task *next;
  struct task *prev;
} task;
{
  int size;
  struct task *front;
  struct task *tail;
} queue;
queue *q;
int terminated = 0;
int *idle;
void sendResult(double result, double *sum)
{
  {
    *sum = (*sum) + result;
  }
}

