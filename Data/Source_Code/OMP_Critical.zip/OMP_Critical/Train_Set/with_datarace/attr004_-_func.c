static char rcsid[] = "$Id$";
int errors = 0;
int thds;
void func()
{
  static int *heap;
  #pragma omp single
  {
    heap = (int *) malloc(sizeof(int));
    *heap = 0;
  }
  *heap += 1;
  #pragma omp barrier
  if ((*heap) != thds)
  {
    errors += 1;
  }

}

