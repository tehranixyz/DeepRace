struct cell_t
{
  int row;
  int col;
  int *list;
  int *base_array;
  int n_allowed;
  int value;
};
int is_allowed(cell_t *this, int val);
int add_allowed(cell_t *, int);
int remove_allowed(cell_t *this, int val);
int set_value(cell_t *, int);
struct pool_t;
struct pool_t
{
  cell_t **arr_boards;
  int sz_alloc;
  int sz;
};
workpool_t *workpool;
board_store_t *store;
cell_t *solved_board;
int solved;
cell_t *pop_mem(board_store_t *pool)
{
  cell_t *ret_val = 0;
  if (omp_in_parallel() != 0)
  {
    {
      if (not_empty(pool))
      {
        pool->sz--;
        ret_val = pool->arr_boards[pool->sz];
      }

    }
  }
  else
  {
    if (not_empty(pool))
    {
      pool->sz--;
      ret_val = pool->arr_boards[pool->sz];
    }

  }

  if (ret_val != 0)
    return ret_val;

  cell_t *newboard;
  newboard = init_board(newboard);
  return newboard;
}

