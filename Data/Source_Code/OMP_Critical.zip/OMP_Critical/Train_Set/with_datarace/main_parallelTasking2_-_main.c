{
  long nodeCount;
  struct SigNode *firstNode;
  struct SigNode *lastNode;
} SigHead;
{
  int col;
  int keyIndexes[4];
  long signature;
  struct SigNode *nextNode;
  struct SigNode *nextCollisionNode;
  struct SigNode *prevCollisionNode;
  struct SigNode *nextCollisionHead;
} SigNode;
int main()
{
  int numThreads = 4;
  int idealSigNodesPerThread = 50000;
  int rowsDM = 4400;
  int colsDM = 500;
  double **ptrDataMatrix = (double **) malloc((sizeof(double)) * rowsDM);
  for (int i = 0; i < rowsDM; i++)
  {
    ptrDataMatrix[i] = (double *) malloc((sizeof(double)) * colsDM);
  }

  long *ptrKeysDatabase = (long *) malloc((sizeof(long)) * rowsDM);
  int *ptrKeysMap = (int *) malloc((sizeof(int)) * rowsDM);
  for (int i = 0; i < rowsDM; i++)
  {
    ptrKeysMap[i] = i;
  }

  float dia = 0.000001;
  int blockSize = 4;
  struct SigHead *ptrAllSigNodes = initSigHead(ptrAllSigNodes);
  struct SigHead *ptrCollisionSigNodes = initSigHead(ptrCollisionSigNodes);
  struct timeval startTime;
  struct timeval initTime;
  struct timeval blockGenTime;
  struct timeval endTime;
  double execTimeInit;
  double execTimeBlockGen;
  double execTimeEnd;
  gettimeofday(&startTime, 0);
  initDataMatrix(ptrDataMatrix);
  initKeysDatabase(ptrKeysDatabase);
  gettimeofday(&initTime, 0);
  execTimeInit = ((((initTime.tv_sec - startTime.tv_sec) * 1000000) + initTime.tv_usec) - startTime.tv_usec) / 1.e6;
  printf("\nExecution time for initialisation = %10.6f seconds\n\n", execTimeInit);
  double *ptrSortedCol = (double *) malloc((sizeof(double)) * rowsDM);
  int *ptrSortedKeysMap = (int *) malloc((sizeof(int)) * rowsDM);
  int *ptrHighestNeighbours = (int *) malloc((sizeof(int)) * rowsDM);
  long blockCount = 0;
  long newBlocks = 0;
  long collisionCount = 0;
  long newCollisions = 0;
  for (int j = 0; j < colsDM; j++)
  {
    for (int i = 0; i < rowsDM; i++)
    {
      ptrSortedCol[i] = ptrDataMatrix[i][j];
    }

    memcpy(ptrSortedKeysMap, ptrKeysMap, (sizeof(int)) * rowsDM);
    quickSort(ptrSortedCol, ptrSortedKeysMap, 0, rowsDM - 1);
    int highIndex;
    int prevHighIndex = -1;
    int numNeighbourhoods = 0;
    for (int lowIndex = 0; lowIndex < rowsDM; lowIndex++)
    {
      if (lowIndex > (rowsDM - blockSize))
      {
        ptrHighestNeighbours[lowIndex] = -1;
      }
      else
      {
        highIndex = findHighestNeighbourIndex(ptrSortedCol, blockSize, dia, lowIndex);
        if (highIndex > prevHighIndex)
        {
          numNeighbourhoods++;
          ptrHighestNeighbours[lowIndex] = highIndex;
          prevHighIndex = highIndex;
        }
        else
        {
          ptrHighestNeighbours[lowIndex] = -1;
        }

      }

    }

    omp_set_num_threads(numThreads);
    int lowIndex = 0;
    int pivot = -1;
    highIndex = -1;
    prevHighIndex = -1;
    int neighbourhoodSize;
    long numSigNodes;
    long redundantSigNodes;
    long numThreadSigNodes;
    bool isSubTask = 0;
    int taskPivot;
    int numLowToPiv;
    #pragma omp parallel
    {
      #pragma omp master
      {
        while (lowIndex < rowsDM)
        {
          highIndex = ptrHighestNeighbours[lowIndex];
          if (highIndex != (-1))
          {
            if (prevHighIndex >= lowIndex)
            {
              pivot = prevHighIndex + 1;
            }
            else
            {
              pivot = lowIndex;
            }

            neighbourhoodSize = (highIndex - lowIndex) + 1;
            numLowToPiv = pivot - lowIndex;
            numSigNodes = combos(neighbourhoodSize, blockSize);
            if (numLowToPiv >= blockSize)
            {
              redundantSigNodes = combos(numLowToPiv, blockSize);
              numSigNodes = numSigNodes - redundantSigNodes;
            }

            if (numSigNodes > idealSigNodesPerThread)
            {
              taskPivot = highIndex;
              isSubTask = 1;
            }
            else
            {
              numThreadSigNodes = numSigNodes;
              taskPivot = pivot;
              isSubTask = 0;
            }

            prevHighIndex = highIndex;
            while (taskPivot >= pivot)
            {
              if (isSubTask == 1)
              {
                numLowToPiv = taskPivot - lowIndex;
                numSigNodes = combos((highIndex - lowIndex) + 1, blockSize);
                redundantSigNodes = combos(numLowToPiv, blockSize);
                numThreadSigNodes = numSigNodes - redundantSigNodes;
                while (1)
                {
                  if (numThreadSigNodes >= idealSigNodesPerThread)
                  {
                    break;
                  }

                  ;
                  taskPivot--;
                  numLowToPiv = taskPivot - lowIndex;
                  redundantSigNodes = combos(numLowToPiv, blockSize);
                  numThreadSigNodes = numSigNodes - redundantSigNodes;
                  if (taskPivot == pivot)
                  {
                    break;
                  }

                }

              }

              #pragma omp task firstprivate(lowIndex, taskPivot, highIndex, numThreadSigNodes)
              {
                struct timeval threadStartTime;
                struct timeval threadEndTime;
                double threadExecTime;
                gettimeofday(&threadStartTime, 0);
                int *ptrThreadBlock = (int *) malloc((sizeof(int)) * blockSize);
                struct SigHead *ptrThreadNodes = initSigHead(ptrThreadNodes);
                genNewBlockSignatures(j, highIndex, lowIndex, blockSize, blockSize, taskPivot, ptrThreadBlock, ptrSortedKeysMap, ptrKeysDatabase, ptrAllSigNodes, ptrThreadNodes, ptrCollisionSigNodes);
                gettimeofday(&threadEndTime, 0);
                threadExecTime = ((((threadEndTime.tv_sec - threadStartTime.tv_sec) * 1000000) + threadEndTime.tv_usec) - threadStartTime.tv_usec) / 1.e6;
                printf("Col %d: thread %d -> n = %ld, l = %d, p = %d, h = %d, time = %10.6f\n", j, omp_get_thread_num(), numThreadSigNodes, lowIndex, taskPivot, highIndex, threadExecTime);
                {
                  ptrAllSigNodes->nodeCount = ptrAllSigNodes->nodeCount + ptrThreadNodes->nodeCount;
                  if (ptrAllSigNodes->firstNode == 0)
                  {
                    ptrAllSigNodes->firstNode = ptrThreadNodes->firstNode;
                  }
                  else
                  {
                    ptrAllSigNodes->lastNode->nextNode = ptrThreadNodes->firstNode;
                  }

                  ptrAllSigNodes->lastNode = ptrThreadNodes->lastNode;
                }
              }
              if (taskPivot == pivot)
              {
                break;
              }
              else
              {
                highIndex = taskPivot - 1;
                taskPivot = highIndex;
              }

            }

          }

          lowIndex++;
        }

      }
    }
    newBlocks = ptrAllSigNodes->nodeCount - blockCount;
    blockCount = ptrAllSigNodes->nodeCount;
    newCollisions = ptrCollisionSigNodes->nodeCount - collisionCount;
    collisionCount = ptrCollisionSigNodes->nodeCount;
    printf("Column %d has %d neighbourhoods and %ld blocks and %ld collisions.\n", j, numNeighbourhoods, newBlocks, newCollisions);
  }

  gettimeofday(&blockGenTime, 0);
  execTimeBlockGen = ((((blockGenTime.tv_sec - initTime.tv_sec) * 1000000) + blockGenTime.tv_usec) - initTime.tv_usec) / 1.e6;
  printf("\nExecution time for block generation = %10.6f seconds\n\n", execTimeBlockGen);
  if (ptrCollisionSigNodes->nodeCount > 0)
  {
    printf("Printing all %ld collisions...\n\n", ptrCollisionSigNodes->nodeCount);
    SigNode *currentCollisionHead = ptrCollisionSigNodes->firstNode;
    SigNode *currentCollisionNode;
    long collisionCount = 1;
    while (1)
    {
      currentCollisionNode = currentCollisionHead;
      printf("            Collision %ld:\n", collisionCount);
      while (1)
      {
        printf("Col %d: [", currentCollisionNode->col);
        for (int i = 0; i < blockSize; i++)
        {
          printf(" %d ", currentCollisionNode->keyIndexes[i]);
        }

        printf("] -> %ld\n", currentCollisionNode->signature);
        if (currentCollisionNode->nextCollisionNode == 0)
        {
          break;
        }

        currentCollisionNode = currentCollisionNode->nextCollisionNode;
      }

      printf("\n");
      collisionCount++;
      if (currentCollisionHead->nextCollisionHead == 0)
      {
        break;
      }

      currentCollisionHead = currentCollisionHead->nextCollisionHead;
    }

    printf("\n\n");
  }
  else
  {
    printf("There are no collisions.\n\n");
  }

}

