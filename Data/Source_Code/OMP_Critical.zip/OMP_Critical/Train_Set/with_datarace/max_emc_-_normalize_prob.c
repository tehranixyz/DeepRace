static double *u;
static double *max_exp_p;
static double *max_exp;
static double *p_sum;
static double *info;
static double *likelihood;
static int *rmax;
static struct timeval t1;
static struct timeval t2;
static void allocate_memory(double ***);
static double calculate_rescale();
static void calculate_prob(int, double **, double *, int *, double *);
static void normalize_prob(double **, double *, int *);
static void update_tomogram(int, double *, double *, double **, double *);
static void merge_tomogram(int, double *, double **, double *, double *);
static void combine_information_omp(double *, double *, double *);
static double combine_information_mpi();
static void save_output();
static void print_time(char *, char *, int);
static void free_memory(double **);
void normalize_prob(double **prob, double *priv_max, int *priv_rmax)
{
  int r;
  int d;
  int omp_rank = omp_get_thread_num();
  double *priv_sum = malloc(frames->tot_num_data * (sizeof(double)));
  {
    for (d = 0; d < frames->tot_num_data; ++d)
      if (priv_max[d] > max_exp_p[d])
    {
      max_exp_p[d] = priv_max[d];
      rmax[d] = priv_rmax[d];
    }


  }
  #pragma omp barrier
  if (omp_rank == 0)
  {
    MPI_Allreduce(max_exp_p, max_exp, frames->tot_num_data, MPI_DOUBLE, MPI_MAX, MPI_COMM_WORLD);
    for (d = 0; d < frames->tot_num_data; ++d)
      if ((max_exp[d] != max_exp_p[d]) || (max_exp_p[d] == (-DBL_MAX)))
      rmax[d] = -1;


    MPI_Allreduce(MPI_IN_PLACE, rmax, frames->tot_num_data, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
  }

  #pragma omp barrier
  #pragma omp for schedule(static,1)
  for (r = 0; r < quat->num_rot_p; ++r)
    for (d = 0; d < frames->tot_num_data; ++d)
    if (frames->type < 2)
    priv_sum[d] += exp(param.beta * (prob[r][d] - max_exp[d]));
  else
    priv_sum[d] += exp(((param.beta * (prob[r][d] - max_exp[d])) / 2.) / param.sigmasq);



  {
    for (d = 0; d < frames->tot_num_data; ++d)
      p_sum[d] += priv_sum[d];

  }
  #pragma omp barrier
  if (omp_rank == 0)
    MPI_Allreduce(MPI_IN_PLACE, p_sum, frames->tot_num_data, MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);

  #pragma omp barrier
  free(priv_max);
  free(priv_rmax);
  free(priv_sum);
}

