static char rcsid[] = "$Id$";
int errors = 0;
int thds;
struct x
{
  int i;
  double d;
};
struct x prvt;
int main()
{
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi threads.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  prvt.i = 100;
  prvt.d = 100 + 1;
  #pragma omp parallel firstprivate (prvt)
  {
    int id = omp_get_thread_num();
    if (prvt.i != 100)
    {
      errors += 1;
    }

    if (prvt.d != (100 + 1))
    {
      errors += 1;
    }

    prvt.i = id;
    prvt.d = id - 1;
    #pragma omp barrier
    if (prvt.i != id)
    {
      errors += 1;
    }

    if (prvt.d != (id - 1))
    {
      errors += 1;
    }

    if ((sizeof(prvt)) != (sizeof(struct x)))
    {
      errors += 1;
    }

  }
  prvt.i = 100 * 2;
  prvt.d = (100 * 2) + 1;
  #pragma omp parallel firstprivate (prvt)
  func1(100 * 2, &prvt);
  prvt.i = 100 * 3;
  prvt.d = (100 * 3) + 1;
  #pragma omp parallel firstprivate (prvt)
  func2(100 * 3);
  if (errors == 0)
  {
    printf("firstprivate 013 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("firstprivate 013 : FAILED\n");
    return 1;
  }

}

