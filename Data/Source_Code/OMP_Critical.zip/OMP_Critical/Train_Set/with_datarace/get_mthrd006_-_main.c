static char rcsid[] = "$Id$";
int main()
{
  int thds;
  int i;
  int errors = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("omp_get_max_threads return 1.\n");
    printf("please, run this program on multi thread environment.\n");
    exit(0);
  }

  omp_set_dynamic(0);
  omp_set_nested(1);
  if (omp_get_nested() == 0)
  {
    printf("nested parallism is not supported.\n");
    goto END;
  }

  #pragma omp parallel
  {
    #pragma omp parallel
    {
      if (omp_get_max_threads() != thds)
      {
        errors += 1;
      }

    }
  }
  for (i = 1; i <= thds; i++)
  {
    omp_set_num_threads(i);
    #pragma omp parallel
    {
      #pragma omp parallel
      {
        if (omp_get_max_threads() != i)
        {
          errors += 1;
        }

      }
    }
  }

  END:
  if (errors == 0)
  {
    printf("omp_get_max_threads 006 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("omp_get_max_threads 006 : FAILED\n");
    return 1;
  }


}

