int checkerOMP(int rank, char *buffer, size_t bufferSize)
{
  int usableCoordinates = 0;
  #pragma omp parallel
  {
    float distance = 0;
    int a;
    int temp = 0;
    #pragma omp for schedule(static,1) private(a, distance)
    for (a = 0; a < (bufferSize / 10); a = a + 3)
    {
      char nLine1[BITS_LINE];
      char nLine2[BITS_LINE];
      char nLine3[BITS_LINE];
      float value[3];
      strncpy(nLine1, buffer + ((a * BITS_LINE) + (BITS_LINE * 0)), BITS_LINE - 1);
      strncpy(nLine2, buffer + ((a * BITS_LINE) + (BITS_LINE * 1)), BITS_LINE - 1);
      strncpy(nLine3, buffer + ((a * BITS_LINE) + (BITS_LINE * 2)), BITS_LINE - 1);
      nLine1[BITS_LINE - 1] = '\0';
      nLine2[BITS_LINE - 1] = '\0';
      nLine3[BITS_LINE - 1] = '\0';
      value[0] = atof(nLine1);
      value[1] = atof(nLine2);
      value[2] = atof(nLine3);
      distance = sqrtf(((value[0] * value[0]) + (value[1] * value[1])) + (value[2] * value[2]));
      if ((distance >= DOWNLIMIT) && (distance <= UPLIMIT))
      {
        temp++;
      }

      distance = 0;
    }

    usableCoordinates = usableCoordinates + temp;
  }
  return usableCoordinates;
  return usableCoordinates;
}

