void methode1(int *);
void methode2(int *);
void methode2(int *tab)
{
  int i;
  int max = 0;
  #pragma omp parallel num_threads(MAXTHREADS)
  {
    for (i = 0; i < 2048; i++)
    {
      if (tab[i] > max)
      {
        {
          if (tab[i] > max)
          {
            max = tab[i];
            printf("Thread n°%d, val max = %d\n", omp_get_thread_num(), max);
          }

        }
      }

    }

  }
  printf("Maximum : %d\n", max);

  #pragma omp parallel for
  for (linha = 0; linha < M1L; linha++)
  {
    #pragma omp critical
    for (coluna = 0; coluna < M2C; coluna++)
    {
      somaprod = 0;
      for (i = 0; i < M1L; i++)
      {
        somaprod += mat1[linha][i] * mat2[i][coluna];
      }

      mat3[linha][coluna] = somaprod;
    }

  }

}

