int main(int argc, char *argv[])
{
  int nt = omp_get_max_threads();
  if (nt != 2)
    omp_set_num_threads(2);

  int iterations = (argc > 1) ? (atoi(argv[1])) : (1000000);
  printf("thread ping-pong benchmark\n");
  printf("num threads  = %d\n", omp_get_max_threads());
  printf("iterations   = %d\n", iterations);
  printf("memory model = %s\n", "acq-rel");
  fflush(stdout);
  int left_ready = -1;
  int right_ready = -1;
  int left_payload = 0;
  int right_payload = 0;
  #pragma omp parallel
  {
    int me = omp_get_thread_num();
    bool parity = (me % 2) == 0;
    int junk = 0;
    #pragma omp barrier
    double t0 = omp_get_wtime();
    for (int i = 0; i < iterations; ++i)
    {
      if (parity)
      {
        left_payload = i;
        #pragma omp atomic write
        left_ready = i;
        while (1)
        {
          #pragma omp flush
          int temp;
          #pragma omp atomic read
          temp = i;
          if (temp == right_ready)
            break;

        }

        junk += right_payload;
      }
      else
      {
        while (1)
        {
          #pragma omp flush
          int temp;
          #pragma omp atomic read
          temp = i;
          if (temp == left_ready)
            break;

        }

        junk += left_payload;
        right_payload = i;
        #pragma omp atomic write
        right_ready = i;
      }

    }

    #pragma omp barrier
    double t1 = omp_get_wtime();
    double dt = t1 - t0;
    {
      printf("total time elapsed = %lf\n", dt);
      printf("time per iteration = %e\n", dt / iterations);
      printf("%d\n", junk);
    }
  }
  return 0;
}

