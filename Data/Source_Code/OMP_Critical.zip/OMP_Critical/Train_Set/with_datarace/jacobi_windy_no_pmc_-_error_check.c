double time1;
double time2;
void driver(void);
void initialize(void);
void jacobi(void);
void error_check(void);
int n;
int m;
int mits;
double tol;
double relax = 1.0;
double alpha = 0.0543;
double u[16][16];
double f[16][16];
double uold[16][16];
double dx;
double dy;
void error_check()
{
  int i;
  int j;
  double xx;
  double yy;
  double temp;
  static double error;
  dx = 2.0 / (n - 1);
  dy = 2.0 / (m - 1);
  error = 0.0;
  {
    #pragma omp parallel for private(xx,yy,temp,j,i)
    for (i = 0; i < n; i++)
    {
      for (j = 0; j < m; j++)
      {
        xx = (-1.0) + (dx * (i - 1));
        yy = (-1.0) + (dy * (j - 1));
        temp = u[i][j] - ((1.0 - (xx * xx)) * (1.0 - (yy * yy)));
        {
          error = error + (temp * temp);
        }
      }

    }

  }
  error = sqrt(error) / (n * m);
  printf("Solution Error :%E \n", error);
}

