static char rcsid[] = "$Id$";
int main()
{
  int thds;
  int *buf;
  int errors = 0;
  thds = omp_get_max_threads();
  if (thds == 1)
  {
    printf("should be run this program on multi thread.\n");
    exit(0);
  }

  buf = (int *) malloc((sizeof(int)) * (thds + 1));
  if (buf == 0)
  {
    printf("can not allocate memory.\n");
    exit(1);
  }

  omp_set_dynamic(0);
  omp_set_nested(1);
  if (omp_get_nested() == 0)
  {
    printf("nested parallelism is not imprelment.\n");
    goto END;
  }

  omp_set_num_threads(1);
  #pragma omp parallel
  {
    int i;
    int j;
    if (omp_get_num_threads() != 1)
    {
      errors += 1;
    }

    if (omp_get_thread_num() != 0)
    {
      errors += 1;
    }

    for (i = 1; i <= thds; i++)
    {
      memset(buf, 0, (sizeof(int)) * (thds + 1));
      omp_set_num_threads(i);
      #pragma omp parallel
      {
        int id = omp_get_thread_num();
        if (omp_get_num_threads() != i)
        {
          errors += 1;
        }

        buf[id] += 1;
      }
      for (j = 0; j < i; j++)
      {
        if (buf[j] != 1)
        {
          errors += 1;
        }

      }

      for (j = i; j <= thds; j++)
      {
        if (buf[j] != 0)
        {
          errors += 1;
        }

      }

    }

  }
  END:
  if (errors == 0)
  {
    printf("omp_get_nested 003 : SUCCESS\n");
    return 0;
  }
  else
  {
    printf("omp_get_nested 003 : FAILED\n");
    return 1;
  }


}

