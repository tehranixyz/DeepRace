double calc_patch_area_in_grid(double curMinX, double curMinY, double curMaxX, double curMaxY, double cellMaxX, double cellMaxY, double cellMinX, double cellMinY, double cell_res);
struct fire_object **construct_patch_fire_grid(struct world_object *world, struct command_line_object *command_line, struct fire_default def)
{
  static int err;
  int id = omp_get_thread_num();
  int i;
  for (i = 0; i < 1024; i++)
  {
    prvt[i] = id + i;
  }

  err = 0;
  #pragma omp barrier
  for (i = 0; i < 1024; i++)
  {
    if (prvt[i] != (id + i))
    {
      #pragma omp critical
      err += 1;
    }

  }

  #pragma omp barrier
  #pragma omp master
  if (err != ((thds - 1) * 1024))
  {
    #pragma omp critical
    errors++;
  }

  if ((sizeof(prvt)) != ((sizeof(int)) * 1024))
  {
    #pragma omp critical
    errors += 1;
  }


  struct patch_fire_object **fire_grid;
  struct patch_object *patch;
  int b;
  int h;
  int p;
  int z;
  int i;
  int j;
  int k;
  double maxx;
  double maxy;
  double minx;
  double miny;
  double tmp;
  double halfSideLength;
  double curMinX;
  double curMinY;
  double curMaxX;
  double curMaxY;
  double cell_res;
  maxx = -10000;
  minx = -10000;
  maxy = -10000;
  miny = -10000;
  int grid_dimX;
  int grid_dimY;
  cell_res = command_line[0].fire_grid_res;
  if (def.n_rows == (-1))
  {
    for (b = 0; b < world[0].num_basin_files; ++b)
    {
      for (h = 0; h < world[0].basins[b][0].num_hillslopes; ++h)
      {
        for (z = 0; z < world[0].basins[b][0].hillslopes[h][0].num_zones; ++z)
        {
          tmp = world[0].basins[b][0].hillslopes[h][0].zones[z][0].aspect;
          for (p = 0; p < world[0].basins[b][0].hillslopes[h][0].zones[z][0].num_patches; ++p)
          {
            patch = world[0].basins[b][0].hillslopes[h][0].zones[z][0].patches[p];
            halfSideLength = sqrt(patch[0].area) / 2;
            curMinX = patch[0].x - halfSideLength;
            curMaxX = patch[0].x + halfSideLength;
            curMinY = patch[0].y - halfSideLength;
            curMaxY = patch[0].y + halfSideLength;
            if (minx > (-10000))
            {
              if (curMinX < minx)
                minx = curMinX;

            }
            else
              minx = curMinX;

            if (maxx > (-10000))
            {
              if (curMaxX > maxx)
                maxx = curMaxX;

            }
            else
              maxx = curMaxX;

            if (miny > (-10000))
            {
              if (curMinY < miny)
                miny = curMinY;

            }
            else
              miny = curMinY;

            if (maxy > (-10000))
            {
              if (curMaxY > maxy)
                maxy = curMaxY;

            }
            else
              maxy = curMaxY;

          }

        }

      }

    }

    int minXpix;
    int maxXpix;
    int minYpix;
    int maxYpix;
    double cellMinX;
    double cellMaxX;
    double cellMinY;
    double cellMaxY;
    double areaPatchInGrid;
    minx = minx - (cell_res / 100);
    miny = miny - (cell_res / 100);
    maxx = maxx + (cell_res / 100);
    maxy = maxy + (cell_res / 100);
    grid_dimX = ceil((maxx - minx) / cell_res);
    grid_dimY = ceil((maxy - miny) / cell_res);
    maxx = minx + (grid_dimX * cell_res);
    maxy = miny + (grid_dimY * cell_res);
    fire_grid = (struct patch_fire_object **) malloc(grid_dimY * (sizeof(struct patch_fire_object *)));
    for (i = 0; i < grid_dimY; i++)
      fire_grid[i] = (struct patch_fire_object *) malloc(grid_dimX * (sizeof(struct patch_fire_object)));

    #pragma omp parallel for
    for (int i = 0; i < grid_dimX; i++)
    {
      for (int j = 0; j < grid_dimY; j++)
      {
        fire_grid[j][i].occupied_area = 0;
        fire_grid[j][i].num_patches = 0;
        fire_grid[j][i].tmp_patch = 0;
        fire_grid[j][i].elev = 0;
      }

    }

    world[0].num_fire_grid_row = grid_dimY;
    world[0].num_fire_grid_col = grid_dimX;
    for (b = 0; b < world[0].num_basin_files; ++b)
    {
      #pragma omp parallel for
      for (int h = 0; h < world[0].basins[b][0].num_hillslopes; ++h)
      {
        for (int z = 0; z < world[0].basins[b][0].hillslopes[h][0].num_zones; ++z)
        {
          double tmp = world[0].basins[b][0].hillslopes[h][0].zones[z][0].aspect;
          for (int p = 0; p < world[0].basins[b][0].hillslopes[h][0].zones[z][0].num_patches; ++p)
          {
            struct patch_object *patch = world[0].basins[b][0].hillslopes[h][0].zones[z][0].patches[p];
            double halfSideLength = sqrt(patch[0].area) / 2;
            double curMinX = patch[0].x - halfSideLength;
            double curMaxX = patch[0].x + halfSideLength;
            double curMinY = patch[0].y - halfSideLength;
            double curMaxY = patch[0].y + halfSideLength;
            double minXpix = floor((curMinX - minx) / cell_res);
            double maxXpix = ceil((curMaxX - minx) / cell_res);
            double maxYpix = grid_dimY - floor((curMinY - miny) / cell_res);
            double minYpix = grid_dimY - ceil((curMaxY - miny) / cell_res);
            if (minXpix == maxXpix)
              maxXpix = maxXpix + 1;

            if (minYpix == maxYpix)
              maxYpix = maxYpix + 1;

            for (int i = minXpix; i < maxXpix; i++)
            {
              for (int j = minYpix; j < maxYpix; j++)
              {
                fire_grid[j][i].num_patches = fire_grid[j][i].num_patches + 1;
              }

            }

          }

        }

      }

    }

    #pragma omp parallel for
    for (int i = 0; i < grid_dimX; i++)
    {
      for (int j = 0; j < grid_dimY; j++)
      {
        fire_grid[j][i].patches = (struct patch_object **) malloc(fire_grid[j][i].num_patches * (sizeof(struct patch_object *)));
        fire_grid[j][i].prop_patch_in_grid = (double *) malloc(fire_grid[j][i].num_patches * (sizeof(double)));
        fire_grid[j][i].prop_grid_in_patch = (double *) malloc(fire_grid[j][i].num_patches * (sizeof(double)));
        for (int k = 0; k < fire_grid[j][i].num_patches; k++)
        {
          fire_grid[j][i].prop_grid_in_patch[k] = 0;
          fire_grid[j][i].prop_patch_in_grid[k] = 0;
        }

      }

    }

    for (b = 0; b < world[0].num_basin_files; ++b)
    {
      for (h = 0; h < world[0].basins[b][0].num_hillslopes; ++h)
      {
        for (z = 0; z < world[0].basins[b][0].hillslopes[h][0].num_zones; ++z)
        {
          tmp = world[0].basins[b][0].hillslopes[h][0].zones[z][0].aspect;
          for (p = 0; p < world[0].basins[b][0].hillslopes[h][0].zones[z][0].num_patches; ++p)
          {
            patch = world[0].basins[b][0].hillslopes[h][0].zones[z][0].patches[p];
            halfSideLength = sqrt(patch[0].area) / 2;
            curMinX = patch[0].x - halfSideLength;
            curMaxX = patch[0].x + halfSideLength;
            curMinY = patch[0].y - halfSideLength;
            curMaxY = patch[0].y + halfSideLength;
            minXpix = floor((curMinX - minx) / cell_res);
            maxXpix = ceil((curMaxX - minx) / cell_res);
            maxYpix = grid_dimY - floor((curMinY - miny) / cell_res);
            minYpix = grid_dimY - ceil((curMaxY - miny) / cell_res);
            if (minXpix == maxXpix)
              maxXpix = maxXpix + 1;

            if (minYpix == maxYpix)
              maxYpix = maxYpix + 1;

            if ((minXpix < 0) || (minYpix < 0))
              #pragma omp parallel for

            for (int i = minXpix; i < maxXpix; i++)
            {
              for (int j = minYpix; j < maxYpix; j++)
              {
                fire_grid[j][i].patches[fire_grid[j][i].tmp_patch] = patch;
                double cellMinX = (i * cell_res) + minx;
                double cellMaxY = maxy - (j * cell_res);
                double cellMaxX = ((i + 1) * cell_res) + minx;
                double cellMinY = maxy - ((j + 1) * cell_res);
                double areaPatchInGrid = calc_patch_area_in_grid(curMinX, curMinY, curMaxX, curMaxY, cellMaxX, cellMaxY, cellMinX, cellMinY, cell_res);
                fire_grid[j][i].occupied_area = fire_grid[j][i].occupied_area + areaPatchInGrid;
                fire_grid[j][i].prop_grid_in_patch[fire_grid[j][i].tmp_patch] = areaPatchInGrid / patch[0].area;
                fire_grid[j][i].prop_patch_in_grid[fire_grid[j][i].tmp_patch] = areaPatchInGrid;
                fire_grid[j][i].tmp_patch++;
              }

            }

          }

        }

      }

    }

    #pragma omp parallel for
    for (int i = 0; i < grid_dimX; i++)
    {
      for (int j = 0; j < grid_dimY; j++)
      {
        if (fire_grid[j][i].occupied_area > 0)
        {
          for (int k = 0; k < fire_grid[j][i].num_patches; k++)
            fire_grid[j][i].prop_patch_in_grid[k] = fire_grid[j][i].prop_patch_in_grid[k] / fire_grid[j][i].occupied_area;

        }

      }

    }

  }
  else
  {
    printf("reading patch raster structure\n");
    grid_dimX = def.n_cols;
    grid_dimY = def.n_rows;
    fire_grid = (struct patch_fire_object **) malloc(grid_dimY * (sizeof(struct patch_fire_object *)));
    #pragma omp parallel for
    for (int i = 0; i < grid_dimY; i++)
      fire_grid[i] = (struct patch_fire_object *) malloc(grid_dimX * (sizeof(struct patch_fire_object)));

    printf("allocate the fire grid\n");
    #pragma omp parallel for
    for (int i = 0; i < grid_dimX; i++)
    {
      for (int j = 0; j < grid_dimY; j++)
      {
        fire_grid[j][i].occupied_area = 0;
        fire_grid[j][i].num_patches = 0;
        fire_grid[j][i].tmp_patch = 0;
      }

    }

    world[0].num_fire_grid_row = grid_dimY;
    world[0].num_fire_grid_col = grid_dimX;
    printf("Rows: %d Cols: %d\n", world[0].num_fire_grid_row, world[0].num_fire_grid_col);
    int tmpPatchID;
    FILE *patchesIn;
    patchesIn = fopen("auxdata/patchGrid.txt", "r");
    for (i = 0; i < grid_dimY; i++)
    {
      for (j = 0; j < grid_dimX; j++)
      {
        tmpPatchID = -9999;
        fscanf(patchesIn, "%d\t", &tmpPatchID);
        if (tmpPatchID >= 0)
        {
          fire_grid[i][j].num_patches = 1;
          fire_grid[i][j].patches = (struct patch_object **) malloc(fire_grid[i][j].num_patches * (sizeof(struct patch_object *)));
          fire_grid[i][j].prop_patch_in_grid = (double *) malloc(fire_grid[i][j].num_patches * (sizeof(double)));
          fire_grid[i][j].prop_grid_in_patch = (double *) malloc(fire_grid[i][j].num_patches * (sizeof(double)));
          for (b = 0; b < world[0].num_basin_files; ++b)
          {
            for (h = 0; h < world[0].basins[b][0].num_hillslopes; ++h)
            {
              for (z = 0; z < world[0].basins[b][0].hillslopes[h][0].num_zones; ++z)
              {
                tmp = world[0].basins[b][0].hillslopes[h][0].zones[z][0].aspect;
                for (p = 0; p < world[0].basins[b][0].hillslopes[h][0].zones[z][0].num_patches; ++p)
                {
                  patch = world[0].basins[b][0].hillslopes[h][0].zones[z][0].patches[p];
                  if (patch[0].ID == tmpPatchID)
                  {
                    fire_grid[i][j].patches[0] = patch;
                    fire_grid[i][j].occupied_area = cell_res * cell_res;
                    fire_grid[i][j].prop_grid_in_patch[0] = (cell_res * cell_res) / patch[0].area;
                    fire_grid[i][j].prop_patch_in_grid[0] = 1;
                  }

                }

              }

            }

          }

        }

      }

    }

    fclose(patchesIn);
    printf("assigning dem\n");
    FILE *demIn;
    demIn = fopen("auxdata/DemGrid.txt", "r");
    for (i = 0; i < grid_dimY; i++)
    {
      for (j = 0; j < grid_dimX; j++)
      {
        fscanf(demIn, "%lf\t", &fire_grid[i][j].elev);
      }

    }

    fclose(demIn);
    printf("done assigning dem\n");
  }

  return fire_grid;
}

