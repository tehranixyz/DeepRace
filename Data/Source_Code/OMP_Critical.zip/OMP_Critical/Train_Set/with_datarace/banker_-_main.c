int available[3];
int allocation[5][3];
int need[5][3];
bool unavail[5] = {0};
bool finish[5] = {0};
int main(int argc, char *argv[])
{
  if ((argc - 1) == 3)
  {
    for (int i = 1; i < argc; i++)
    {
      available[i - 1] = atoi(argv[i]);
      if (available[i - 1] < 5)
      {
        printf("Too few resources to complete tasks.\n");
        return 0;
      }

    }

  }
  else
  {
    printf("Invalid number of resource types.\n");
    return 0;
  }

  srand(time(0));
  int resources[3];
  #pragma omp parallel
  {
    int cust = omp_get_thread_num();
    need[cust][0] = rand() % 5;
    need[cust][1] = rand() % 5;
    need[cust][2] = rand() % 5;
    int funCall;
    while (1)
    {
      bool done = 1;
      for (int j = 0; j < 3; j++)
      {
        if (need[cust][j] > 0)
        {
          done = 0;
        }

      }

      if (done)
      {
        printf("Release. Thread: %d, resource 1: %d, resource 2: %d, resource 3: %d, safe/accepted: %d\n", cust, allocation[cust][0], allocation[cust][1], allocation[cust][2], release_res(cust, allocation[cust]));
        break;
      }

      if (!unavail[cust])
      {
        int req1 = rand() % (5 + 1);
        int req2 = rand() % (5 + 1);
        int req3 = rand() % (5 + 1);
        resources[0] = req1;
        resources[1] = req2;
        resources[2] = req3;
        funCall = rand() % 4;
      }

      {
      }
    }

  }
  return 0;
}

