int inCircle = 0;
int point = 0;
int count = 0;
int thread[10];
int i;
int main(int argc, char *argv[])
{
  help();
  if (argc != 2)
  {
    printf("ERROR: command error\n");
    return -1;
  }

  point = atoi(argv[1]);
  if (point <= 0)
  {
    printf("ERROR: sample points must be positive\n");
    return -1;
  }

  #pragma omp parallel for
  for (i = 0; i < point; i++)
  {
    double x = ((double) ((rand() % 2000) - 1000)) / 1000;
    double y = ((double) ((rand() % 2000) - 1000)) / 1000;
    double dis = sqrt((x * x) + (y * y));
    {
      count++;
      if (dis < 1)
        inCircle++;

      int t = omp_get_thread_num();
      thread[t]++;
    }
  }

  for (i = 0; i < 10; i++)
    printf("Thread %d: %d\n", i, thread[i]);

  double pi = 4 * (((double) inCircle) / ((double) count));
  printf("Sample points = %d\n", count);
  printf("In circle points = %d\n", inCircle);
  printf("PI = %f\n", pi);
  return 0;
}

