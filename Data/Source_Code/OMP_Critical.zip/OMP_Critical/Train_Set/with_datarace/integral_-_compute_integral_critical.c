double compute_integral_critical(double (*function)(double), double segment_begin, double segment_end, size_t subsegments_number)
{
  double h = (segment_end - segment_begin) / subsegments_number;
  double result = (h * (function(segment_begin) + function(segment_end))) / 2;
  #pragma omp parallel shared(result)
  {
    #pragma omp for
    for (size_t i = 1; i <= (subsegments_number - 1); ++i)
    {
      {
        result += h * function(segment_begin + (h * i));
      }
    }

  }
  return result;
}

