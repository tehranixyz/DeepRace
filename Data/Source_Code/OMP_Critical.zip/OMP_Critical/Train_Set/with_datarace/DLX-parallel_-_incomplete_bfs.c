{
  int left;
  int right;
  int up;
  int down;
  int ch;
} Node;
{
  int (* const sudoku)(byte [][9]);
} DLX_namespace;
const DLX_namespace DLX = {DLX_sudoku};
{
  byte b[9][9];
  bool r[9][9];
  bool c[9][9];
  bool g[9][9];
} Board;
int incomplete_bfs(int g[][9])
{
  Board origin;
  int n = 9;
  int A[81][2];
  int m = 0;
  board_init(&origin);
  for (int i = 0; i < n; i++)
  {
    for (int j = 0; j < n; j++)
    {
      if (g[i][j])
      {
        board_fill(&origin, i, j, g[i][j]);
      }
      else
      {
        A[m][0] = i, A[m][1] = j, m++;
      }

    }

  }

  static Board Q[2][8192 * 9];
  int Qcnt[2] = {};
  int Qflag = 0;
  Q[Qflag][Qcnt[Qflag]] = origin, Qcnt[Qflag]++;
  for (int it = 0; it < m; it++)
  {
    const int x = A[it][0];
    const int y = A[it][1];
    Qcnt[!Qflag] = 0;
    #pragma omp parallel for
    for (int i = 0; i < Qcnt[Qflag]; i++)
    {
      for (int j = 1; j <= 9; j++)
      {
        if (!board_test(&Q[Qflag][i], x, y, j))
          continue;

        int pIdx;
        {
          pIdx = Qcnt[!Qflag]++;
        }
        Q[!Qflag][pIdx] = Q[Qflag][i];
        board_fill(&Q[!Qflag][pIdx], x, y, j);
      }

    }

    if (Qcnt[!Qflag] >= 8192)
    {
      int ret = 0;
      #pragma omp parallel for reduction(+:ret)
      for (int i = 0; i < Qcnt[Qflag]; i++)
      {
        ret += DLX.sudoku(Q[Qflag][i].b);
      }

      return ret;
    }

    Qflag = !Qflag;
  }

  return Qcnt[Qflag];
}

