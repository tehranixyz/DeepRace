{
  int nid;
  double lon;
  double lat;
} Node;
{
  int eid;
  int source;
  int target;
  int dir;
  double capacity;
  double speed_kmh;
  double length_km;
  double cost_time_hour;
  double weight;
  double vol;
  int xid;
} Edge;
{
  int *nid;
  double *cost;
  size_t len;
  size_t capacity;
} Heap;
{
  size_t number_of_nodes;
  size_t number_of_edges;
  int *i;
  int *j;
  Edge *eij;
  int min_nid;
  int max_nid;
} Graph;
{
  int number_of_nodes;
  double *dist;
  int *pred;
  char *done;
  Heap heap;
} Dijkstra;
{
  int source;
  int target;
  double vol;
  char is_ok;
} MatODEdge;
{
  size_t number_of_nodes;
  size_t number_of_edges;
  size_t number_of_sources;
  int *sources;
  int *i;
  int *j;
  MatODEdge *eij;
} MatOD;
void shortestpaths(Graph *G, MatOD *M, Dijkstra *dijkstra, double *x)
{
  #pragma omp parallel
  {
    Edge *edge;
    MatODEdge *travel;
    size_t ntravel;
    int i;
    int j;
    int source;
    int target;
    int pred;
    double vol;
    double *x_local;
    int tid = omp_get_thread_num();
    int num_threads = omp_get_num_threads();
    x_local = (double *) malloc((sizeof(double)) * G->number_of_edges);
    if (x_local == 0)
    {
      printf("The vector x_local could not be allocated.\n");
      exit(1);
    }

    for (i = 0; i < G->number_of_edges; i++)
    {
      x_local[i] = 0.0;
    }

    for (i = tid; i < G->number_of_edges; i += num_threads)
    {
      x[i] = 0.0;
    }

    for (i = tid; i < M->number_of_sources; i += num_threads)
    {
      source = M->sources[i];
      dijkstra_apply(&dijkstra[tid], G, source);
      matod_vertex_edges(M, source, &travel, &ntravel);
      for (j = 0; j < ntravel; j++)
      {
        vol = travel[j].vol;
        target = travel[j].target;
        while (target != source)
        {
          pred = dijkstra[tid].pred[target];
          edge = graph_edge(G, pred, target);
          x_local[edge->xid] += vol;
          target = pred;
        }

      }

    }

    {
      for (i = 0; i < G->number_of_edges; i++)
      {
        x[i] += x_local[i];
      }

    }
    free(x_local);
  }

  printf("FIRST line of MAIN\n");
  long int i;
  long int j;
  printf("argc: %d\n", argc);
  if (argc != 2)
  {
    printf("Usage: bash %s arg1\n", argv[0]);
    printf("where arg1 is the NUM_OF_THREADS (integer <= 32)\n");
    exit(0);
  }

  int k = 1;
  int temp_value = 0;
  int num_threads_set = 0;
  if (argc > 1)
  {
    temp_value = atoi(argv[k]);
    if ((temp_value > 0) && (temp_value < 64))
    {
      num_threads_set = atoi(argv[k]);
    }

  }
  else
  {
    num_threads_set = 32;
  }

  int chunk;
  int tid;
  int nthreads;
  double dec_to_rad = (2. * 3.14159621234161928) / 360.;
  double deg_to_rad = (2. * 3.14159621234161928) / 360.;
  const int num_bins = 15;
  double logrNOTSQUARED_min = -1.0;
  double logrNOTSQUARED_max = 1.3011;
  double logr_min = log10(pow(pow(10., logrNOTSQUARED_min), 2.));
  double logr_max = log10(pow(pow(10., logrNOTSQUARED_max), 2.));
  long int errorcounts = 0;
  long int distance_counts[15] = {0};
  long int randdistance_counts[15] = {0};
  double Xi_func[15] = {0.0};
  int dist_index;
  long int FILELENGTHDM = 66659;
  long int FILELENGTHDMrand = 100000;
  static const char random_datafile[] = "/home/chasonn/LargeScaleHW/HW3Codes/DMCorrelationFunctionParallel/DM_random.dat";
  long int N_rand = FILELENGTHDMrand;
  FILE *myrandfile = fopen(random_datafile, "r");
  if (myrandfile == 0)
  {
    printf("DM_random.dat not opened, trying local filepath...\n");
    static const char random_datafile[] = "./DM_random.dat";
    myrandfile = fopen(random_datafile, "r");
    if (myrandfile == 0)
    {
      printf("DM_random.dat not opened, exiting...\n");
      exit(0);
    }

  }

  double randX_LIST[N_rand];
  double randY_LIST[N_rand];
  double randZ_LIST[N_rand];
  double D;
  double logD;
  double r = 0;
  double x1 = 0;
  double y1 = 0;
  double z1 = 0;
  double rj = 0;
  double x2 = 0;
  double y2 = 0;
  double z2 = 0;
  chunk = 100;
  for (i = 0; i < N_rand; ++i)
  {
    fscanf(myrandfile, "%lf", &randX_LIST[i]);
    fscanf(myrandfile, "%lf", &randY_LIST[i]);
    fscanf(myrandfile, "%lf", &randZ_LIST[i]);
    if (i >= (N_rand - 1))
    {
      printf("Close or exceeded N_data limit. X: %lf \n", randX_LIST[i]);
    }

  }

  fclose(myrandfile);
  printf("Closing File.\n");
  printf("Beginning Random Nested Loops...\n");
  #pragma omp parallel shared( randZ_LIST, randY_LIST, randX_LIST, N_rand,chunk, num_threads_set) private (D, logD, x1, y1, z1, x2, y2, z2, dist_index, i, j )
  {
    omp_set_num_threads(num_threads_set);
    long int sum_local_counts[15];
    memset(sum_local_counts, 0, 15 * (sizeof(sum_local_counts[0])));
    #pragma omp for schedule(guided, chunk)
    for (i = 0; i < (N_rand - 1); ++i)
    {
      x1 = randX_LIST[i];
      y1 = randY_LIST[i];
      z1 = randZ_LIST[i];
      for (j = 0; j < (N_rand - 1); ++j)
      {
        if (j != i)
        {
          x2 = randX_LIST[j];
          y2 = randY_LIST[j];
          z2 = randZ_LIST[j];
          D = (((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2))) + ((z1 - z2) * (z1 - z2));
          logD = log10(D);
          dist_index = (int) floor((logD - logr_min) * (15 / (logr_max - logr_min)));
          if ((dist_index >= 0) && (dist_index < 15))
          {
            sum_local_counts[dist_index] += 1;
          }

        }

      }

    }

    #pragma omp critical
    {
      for (i = 0; i < 15; ++i)
      {
        randdistance_counts[i] += sum_local_counts[i];
      }

    }
  }
  printf("\n*");
  printf("\n   *");
  printf("\n     *");
  printf("\n       *");
  printf("\n      *");
  printf("\n     *");
  printf("\n    *");
  printf("\n   *        *");
  printf("\n   *");
  printf("\n     *");
  printf("\n      *");
  printf("\n       **");
  printf("\n        * *");
  printf("\n        * * *");
  printf("\n       * * * *\n");
  printf("************************************\n");
  printf("FINISHED DM RAND PRAGMA OMP CRITICAL\n");
  printf("************************************\n");
  printf("FINISHED RANDOM NESTED LOOPS! \n");
  printf("Counts: ");
  #pragma simd
  for (i = 0; i < 15; ++i)
  {
    randdistance_counts[i] = (long long) floor(randdistance_counts[i] / 2.);
  }

  printf("\n");
  char DM_datafile[100];
  int filenum = 0;
  int max_filenum = 3;
  for (filenum = 0; filenum < max_filenum; filenum++)
  {
    sprintf(DM_datafile, "/scratch/chasonnscr/HOSTSpositdirHPC/PositionXYZdatafileHOSTS%d.dat", filenum);
    FILE *myfile = fopen(DM_datafile, "r");
    if (myfile == 0)
    {
      printf("DM.dat not opened, trying local filepath...DM.dat\n");
      static const char DM_datafile[] = "./DM.dat";
      myfile = fopen(DM_datafile, "r");
      if (myfile == 0)
      {
        printf("DM.dat not opened, exiting...\n");
        exit(0);
      }

    }

    printf("Opened file - Begining assignment.\n");
    long int N_data = FILELENGTHDM;
    double X_LIST[N_data];
    double Y_LIST[N_data];
    double Z_LIST[N_data];
    i = 0;
    while ((i < N_data) && (!feof(myfile)))
    {
      fscanf(myfile, "%lf", &X_LIST[i]);
      fscanf(myfile, "%lf", &Y_LIST[i]);
      fscanf(myfile, "%lf", &Z_LIST[i]);
      if (i >= (N_data - 1))
      {
        printf("Close or exceeded N_data limit. X: %lf \n", X_LIST[i]);
      }

      ++i;
    }

    fclose(myfile);
    printf("Closing File.\n");
    printf("correcting N_data size, due to different datafile. N_data: %ld i: %ld\n", N_data, i);
    N_data = i;
    printf("Beginning Nested Loops...\n");
    printf("Note: using Distance Squared to avoid taking SQRT for index rank.\n");
    #pragma omp parallel shared( Z_LIST, Y_LIST, X_LIST, N_data, chunk, num_threads_set) private (D, logD, x1, y1, z1, x2, y2, z2, dist_index, i, j, tid)
    {
      omp_set_num_threads(num_threads_set);
      long int sum_local_counts[15];
      memset(sum_local_counts, 0, 15 * (sizeof(sum_local_counts[0])));
      tid = omp_get_thread_num();
      if (tid == 0)
      {
        nthreads = omp_get_num_threads();
        printf("thread id: %d, num threads: %d \n", tid, nthreads);
      }

      #pragma omp for schedule(guided, chunk)
      for (i = 0; i < (N_data - 1); ++i)
      {
        x1 = X_LIST[i];
        y1 = Y_LIST[i];
        z1 = Z_LIST[i];
        for (j = 0; j < (N_data - 1); ++j)
        {
          if (j != i)
          {
            x2 = X_LIST[j];
            y2 = Y_LIST[j];
            z2 = Z_LIST[j];
            D = (((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2))) + ((z1 - z2) * (z1 - z2));
            logD = log10(D);
            dist_index = (int) floor((logD - logr_min) * (15 / (logr_max - logr_min)));
            if ((dist_index >= 0) && (dist_index < 15))
            {
              if (dist_index >= 15)
                printf("YELLING!");

              sum_local_counts[dist_index] += 1;
            }

          }

        }

      }

      #pragma omp critical
      {
        for (i = 0; i < 15; ++i)
        {
          distance_counts[i] += sum_local_counts[i];
        }

      }
    }
    printf("\n*");
    printf("\n   *");
    printf("\n     *");
    printf("\n       *");
    printf("\n      *");
    printf("\n     *");
    printf("\n    *");
    printf("\n   *        *");
    printf("\n   *");
    printf("\n     *");
    printf("\n      *");
    printf("\n       **");
    printf("\n        * *");
    printf("\n        * * *");
    printf("\n       * * * *\n");
    printf("****************************\n");
    printf("FINISHED DM PRAGMA OMP CRITICAL\n");
    printf("****************************\n");
    printf("FINISHED DM NESTED LOOP. \n");
    printf("Dividing Counts by two to correct double counting...");
    printf("Counts: ");
    #pragma simd
    for (i = 0; i < 15; ++i)
    {
      distance_counts[i] = (long long) floor(distance_counts[i] / 2.);
    }

    printf("\n");
    printf("Calculating DM Correlation Function...\n");
    double ratio = ((double) N_rand) / ((double) N_data);
    #pragma simd
    for (i = 0; i < 15; i++)
    {
      Xi_func[i] = ((ratio * ratio) * (((double) distance_counts[i]) / ((double) randdistance_counts[i]))) - 1.0;
    }

    printf("\n");
    printf("Saving DM counts to file.\n");
    FILE *fp_out;
    fp_out = fopen("output_DMcountsVariable.txt", "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 15; i++)
    {
      fprintf(fp_out, "%ld \n", distance_counts[i]);
    }

    fclose(fp_out);
    printf("Saving logr counts to file.\n");
    fp_out = fopen("output_logr.txt", "w");
    if (fp_out == 0)
    {
      printf("output_logr.txt not opened, exiting...\n");
      exit(0);
    }

    fprintf(fp_out, "%lf %lf %d \n", logrNOTSQUARED_min, logrNOTSQUARED_max, 15);
    fclose(fp_out);
    printf("Saving Random counts to file.\n");
    fp_out = fopen("output_counts_DMrandom.txt", "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 15; i++)
    {
      fprintf(fp_out, "%ld \n", randdistance_counts[i]);
    }

    fclose(fp_out);
    printf("Saving Xi-DM to file.\n");
    char Xifilename[50];
    sprintf(Xifilename, "output_Xi_DM_%d.txt", filenum);
    fp_out = fopen(Xifilename, "w");
    if (fp_out == 0)
    {
      printf("output_file.txt not opened, exiting...\n");
      exit(0);
    }

    for (i = 0; i < 15; i++)
    {
      fprintf(fp_out, "%f \n", Xi_func[i]);
    }

    fclose(fp_out);
  }

  return 0;
}

