int main(int argc, char *argv[])
{
  int i;
  #pragma omp parallel for
  for (i = 0; i < omp_get_num_threads(); i++)
  {
    int tid = omp_get_thread_num();
    printf("tid: %d, tid address: %p\n", tid, (void *) (&tid));
  }

}

