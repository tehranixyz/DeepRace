double multiply(double a[], double b[], int n);
int main(int argc, const char *argv[])
{
  double sum;
  if (argc != 2)
  {
    printf("Please hand te vector size as a command line argument\n");
    return 1;
  }

  int n = atoi(argv[1]);
  double a[n];
  double b[n];
  int i;
  #pragma omp parallel
  {
    printf("Hello, World! from Thread %d\n", omp_get_thread_num());
    for (i = 0; i < n; i++)
    {
      a[i] = i * 0.25;
      b[i] = i * 1.5;
    }

  }
  sum = 0.0;
  #pragma omp parallel
  {
    double local_sum = 0.0;
    local_sum = multiply(a, b, n);
    {
      printf("Thread Nr. %d accessing critical section\n", omp_get_thread_num());
      sum += local_sum;
    }
  }
  printf("Snippet#2: sum =  %f \n", sum);
  sum = 0.0;
  #pragma omp parallel default(shared) reduction(+:sum)
  {
    sum += multiply(a, b, n);
  }
  printf("Snippet#3: sum =  %f \n", sum);
  return 0;
}

