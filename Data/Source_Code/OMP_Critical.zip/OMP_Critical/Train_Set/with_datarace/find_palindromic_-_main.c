double start_time;
double end_time;
char *reverse_string(char *str);
int main(int argc, char *argv[])
{
  struct stat fs;
  int fd;
  char *filepath;
  char *addr;
  char *word[500000];
  char *pivot;
  char *buffer;
  int i;
  int j;
  int wCount = 0;
  int pCount = 0;
  if (argc < 2)
  {
    fprintf(stderr, "Argument 1 need to be path to file");
  }

  filepath = argv[1];
  fd = open(filepath, O_RDWR);
  if (fd == (-1))
  {
    perror("open");
    return 1;
  }

  FILE *fp;
  fp = fopen("palindromes", "w");
  if (fp == 0)
  {
    perror("fopen");
    return 1;
  }

  int maxthreads = omp_get_max_threads();
  int numWorkers;
  numWorkers = (argc > 2) ? (atoi(argv[2])) : (maxthreads);
  if (numWorkers > maxthreads)
    numWorkers = maxthreads;

  omp_set_dynamic(0);
  omp_set_num_threads(numWorkers);
  fstat(fd, &fs);
  addr = (char *) mmap(0, fs.st_size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
  if (addr == ((void *) (-1)))
  {
    perror("mmap");
    return 1;
  }

  close(fd);
  buffer = strtok(addr, "\n");
  while (buffer != 0)
  {
    word[wCount] = buffer;
    wCount++;
    buffer = strtok(0, "\n");
  }

  printf("Word Count: %d\n", wCount);
  start_time = omp_get_wtime();
  #pragma omp parallel for schedule(dynamic,2) private(j,pivot)
  for (i = 0; i < wCount; i++)
  {
    pivot = (char *) malloc(strlen(word[i]) + 1);
    memcpy((void *) pivot, word[i], strlen(word[i]) + 1);
    pivot = reverse_string(pivot);
    for (j = i; j < wCount; j++)
    {
      if (0 == strcmp(pivot, word[j]))
      {
        if (i == j)
        {
          fputs(word[i], fp);
          fputs("\n", fp);
          pCount = pCount + 1;
        }
        else
        {
          fputs(word[i], fp);
          fputs("\n", fp);
          fputs(word[j], fp);
          fputs("\n", fp);
          pCount = pCount + 2;
        }

        break;
      }

    }

    free(pivot);
  }

  printf("Palindromes: %d\n", pCount);
  end_time = omp_get_wtime();
  printf("it took %f seconds\n", end_time - start_time);
  fclose(fp);
}

