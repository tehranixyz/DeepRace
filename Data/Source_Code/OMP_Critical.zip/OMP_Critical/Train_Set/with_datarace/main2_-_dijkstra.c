struct direct_edge_struct;
struct direct_edge_struct
{
  int vertexSize;
  int globalVertex2;
  int globalVertex;
  int meshSize;
  int tri = 0;
  int i = 0;
  int j = 0;
  double f = -4;
  double g = 1;
  double vertices[3][2] = {{0}};
  double localW[3][3] = {{0}};
  double localB[3] = {1};
  FILE *meshFile = fopen(fileP, "r");
  FILE *vertexFile = fopen(fileT, "r");
  vertexSize = lineCount(vertexFile);
  meshSize = lineCount(meshFile);
  double startIO = omp_get_wtime();
  clock_t startIOCPU = clock();
  double *meshPoints = readMatrixFile(meshFile, lineCount(meshFile), 2);
  double *vertexNumbers = readMatrixFile(vertexFile, lineCount(vertexFile), 3);
  double ioTime = omp_get_wtime() - startIO;
  double ioTimeCPU = (((double) (clock() - startIOCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double startZeros = omp_get_wtime();
  clock_t startZerosCPU = clock();
  double *w = zeros(meshSize * meshSize);
  double *b = zeros(meshSize);
  double zerosTime = omp_get_wtime() - startZeros;
  double zerosTimeCPU = (((double) (clock() - startZerosCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double startComputation = omp_get_wtime();
  clock_t startComputationCPU = clock();
  #pragma omp parallel for private(tri, i, j, globalVertex, globalVertex2, vertices, localW, localB) schedule(dynamic)
  for (tri = 0; tri < vertexSize; tri++)
  {
    for (i = 0; i < 3; i++)
    {
      globalVertex = ((int) (*((vertexNumbers + (tri * 3)) + i))) - 1;
      vertices[i][0] = *((meshPoints + (globalVertex * 2)) + 0);
      vertices[i][1] = *((meshPoints + (globalVertex * 2)) + 1);
    }

    localStiffnessMatrix(vertices, localW);
    localVector(vertices, f, localB);
    for (i = 0; i < 3; i++)
    {
      globalVertex = ((int) (*((vertexNumbers + (tri * 3)) + i))) - 1;
      #pragma omp critical
      b[globalVertex] += localB[i];
      for (j = 0; j < 3; j++)
      {
        globalVertex2 = ((int) (*((vertexNumbers + (tri * 3)) + j))) - 1;
        #pragma omp critical
        *((w + (globalVertex * meshSize)) + globalVertex2) += localW[i][j];
      }

    }

  }

  double assemblingTime = omp_get_wtime() - startComputation;
  double assemblingTimeCPU = (((double) (clock() - startComputationCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double startDirichlet = omp_get_wtime();
  clock_t startDirichletCPU = clock();
  assignDirichletCondition(meshSize, g, meshPoints, w, b);
  double dirichletTime = omp_get_wtime() - startDirichlet;
  double dirichletTimeCPU = (((double) (clock() - startDirichletCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double startGauss = omp_get_wtime();
  clock_t startGaussCPU = clock();
  gaussianElimination(meshSize, w, b);
  double gaussTime = omp_get_wtime() - startGauss;
  double gaussTimeCPU = (((double) (clock() - startGaussCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double startBack = omp_get_wtime();
  clock_t startBackCPU = clock();
  double *u = backSubstitution(meshSize, w, b);
  double backTime = omp_get_wtime() - startBack;
  double backTimeCPU = (((double) (clock() - startBackCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  double computationTime = omp_get_wtime() - startComputation;
  double computationTimeCPU = (((double) (clock() - startComputationCPU)) / CLOCKS_PER_SEC) / omp_get_max_threads();
  printf("Vertex number: %d.\n", meshSize);
  printf("Elapsed time for computation: %lf seconds.\n", computationTime);
  printf("Elapsed time for computation in CPU: %lf seconds.\n", computationTimeCPU);
  printf("Elapsed time for IO: %lf seconds.\n", ioTime);
  printf("Elapsed time for IO in CPU: %lf seconds.\n", ioTimeCPU);
  printf("Elapsed time for zeros: %lf seconds.\n", zerosTime);
  printf("Elapsed time for zeros in CPU: %lf seconds.\n", zerosTimeCPU);
  printf("Elapsed time for assembling: %lf seconds.\n", assemblingTime);
  printf("Elapsed time for assembling in CPU: %lf seconds.\n", assemblingTimeCPU);
  printf("Elapsed time for dirichlet: %lf seconds.\n", dirichletTime);
  printf("Elapsed time for dirichlet in CPU: %lf seconds.\n", dirichletTimeCPU);
  printf("Elapsed time for gaussian elimination: %lf seconds.\n", gaussTime);
  printf("Elapsed time for gaussian elimination in CPU: %lf seconds.\n", gaussTimeCPU);
  printf("Elapsed time for back substitution: %lf seconds.\n", backTime);
  printf("Elapsed time for back substitution in CPU: %lf seconds.\n", backTimeCPU);
  fprintf(result, "%d; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf; %lf\n", meshSize, computationTime, ioTime, zerosTime, assemblingTime, dirichletTime, gaussTime, backTime, computationTimeCPU, ioTimeCPU, zerosTimeCPU, assemblingTimeCPU, dirichletTimeCPU, gaussTimeCPU, backTimeCPU);
  fclose(meshFile);
  fclose(vertexFile);
  free(meshPoints);
  free(vertexNumbers);
  free(w);
  free(b);
  free(u);
  return u;

  int destination_node;
  int weight;
  struct direct_edge_struct *next;
};
int num_nodes;
int num_edges;
struct direct_edge_struct *edges;
int edge_counter = 0;
struct direct_edge_struct **nodes;
int *min_distance;
char *tree;
int main(int argc, char **argv);
void read_graph(char *filename);
double dijkstra();
double dijkstra()
{
  int shortest_dist;
  int nearest_node;
  double start;
  double stop;
  start = get_time();
  tree[0] = 1;
  #pragma omp parallel for num_threads(NBTHREAD)
  for (int i = 1; i < num_nodes; i++)
    tree[i] = 0;

  #pragma omp parallel for num_threads(NBTHREAD)
  for (int i = 0; i < num_nodes; i++)
    min_distance[i] = get_distance(0, i);

  for (int step = 1; step < num_nodes; step++)
  {
    shortest_dist = 1 << 30;
    nearest_node = -1;
    #pragma omp parallel for num_threads(NBTHREAD)
    for (int i = 0; i < num_nodes; i++)
    {
      if ((!tree[i]) && (min_distance[i] < shortest_dist))
      {
        {
          shortest_dist = min_distance[i];
          nearest_node = i;
        }
      }

    }

    if (nearest_node == (-1))
    {
      fprintf(stderr, "Warning: Search ended early, the graph might not be connected.\n");
      break;
    }

    tree[nearest_node] = 1;
    int d;
    #pragma omp parallel for num_threads(NBTHREAD) private(d)
    for (int i = 0; i < num_nodes; i++)
      if (!tree[i])
    {
      d = get_distance(nearest_node, i);
      if (d < (1 << 30))
        if ((min_distance[nearest_node] + d) < min_distance[i])
        min_distance[i] = min_distance[nearest_node] + d;


    }


  }

  stop = get_time();
  return stop - start;
}

