struct pathNode
{
  int nodeNumber;
  struct pathNode *next;
};
struct path
{
  struct pathNode *head;
  int lastNode;
};
struct tour
{
  int cityCount;
  struct path *thePath;
  int totalCost;
};
struct AdjListNode
{
  int dest;
  int cost;
  struct AdjListNode *next;
};
struct AdjList
{
  struct AdjListNode *head;
};
struct Graph
{
  int V;
  struct AdjList *array;
};
{
  int capacity;
  int size;
  struct tour *elements;
} Stack;
int minCost = 32767;
int TreeSearch(struct Graph *graph, int src, int V, int *costMatrix)
{
  double x;
  x = omp_get_wtime();
  struct tour temp3;
  Stack *s = createStack(1000);
  struct tour bestTour;
  struct tour t = {0, 0, 0};
  struct pathNode *temp11 = 0;
  struct tour temp = {0, 0, 0};
  addCity(&t, src, V, costMatrix);
  push(s, t);
  t = pop(s);
  int i = 0;
  for (i = V - 1; i > 0; i--)
  {
    if (feasible(&t, i))
    {
      addCity(&t, i, V, costMatrix);
      temp3.thePath = 0;
      temp3.totalCost = t.totalCost;
      temp11 = t.thePath->head;
      while (temp11->next != 0)
      {
        addCity(&temp3, temp11->nodeNumber, V, costMatrix);
        temp11 = temp11->next;
      }

      addCity(&temp3, temp11->nodeNumber, V, costMatrix);
      temp3.cityCount = t.cityCount;
      push(s, temp3);
      removeLastCity(&t, costMatrix, V);
    }

  }

  struct pathNode *temp44 = t.thePath->head;
  struct pathNode *temp55 = temp44;
  while (temp44 != 0)
  {
    temp44 = temp44->next;
    free(temp55);
    temp55 = temp44;
  }

  free(t.thePath);
  #pragma omp parallel private(t,temp3,temp11) reduction(min:minCost)
  {
    int flag = 0;
    int count = 0;
    while (!isEmpty(s))
    {
      flag = 0;
      {
        if (!isEmpty(s))
        {
          flag = 1;
          t = pop(s);
        }

      }
      if (flag == 1)
      {
        if (t.cityCount == V)
        {
          int lastCost = *((costMatrix + (V * t.thePath->lastNode)) + t.thePath->head->nodeNumber);
          if ((t.totalCost + lastCost) < minCost)
          {
            minCost = t.totalCost + lastCost;
          }

          struct pathNode *temp44 = t.thePath->head;
          struct pathNode *temp55 = temp44;
          while (temp44 != 0)
          {
            temp44 = temp44->next;
            free(temp55);
            temp55 = temp44;
          }

          free(t.thePath);
        }
        else
        {
          int i = 0;
          for (i = V - 1; i > 0; i--)
          {
            if (feasible(&t, i))
            {
              addCity(&t, i, V, costMatrix);
              temp3.thePath = 0;
              temp3.totalCost = t.totalCost;
              temp11 = t.thePath->head;
              while (temp11->next != 0)
              {
                addCity(&temp3, temp11->nodeNumber, V, costMatrix);
                temp11 = temp11->next;
              }

              addCity(&temp3, temp11->nodeNumber, V, costMatrix);
              temp3.cityCount = t.cityCount;
              removeLastCity(&t, costMatrix, V);
              {
                push(s, temp3);
              }
            }

          }

          struct pathNode *temp44 = t.thePath->head;
          struct pathNode *temp55 = temp44;
          while (temp44 != 0)
          {
            temp44 = temp44->next;
            free(temp55);
            temp55 = temp44;
          }

          free(t.thePath);
        }

      }

    }

  }
  return minCost;

  check_offloading();
  long cpuExec = 0;
  #pragma omp target map(tofrom: cpuExec)
  {
    cpuExec = omp_is_initial_device();
  }
  if (!cpuExec)
  {
    int *x = (int *) malloc((sizeof(int)) * nb);
    int *y = (int *) malloc((sizeof(int)) * nb);
    for (int ii = 0; ii < nb; ++ii)
    {
      x[ii] = X_VAL;
      y[ii] = Y_VAL;
    }

    #pragma omp target map(tofrom: x[:nb], y[:nb])
    #pragma omp teams num_teams(nb) thread_limit(bs)
    #pragma omp distribute parallel for
    for (int ii = 0; ii < (nb * bs); ++ii)
    {
      #pragma omp critical
      {
        const int identity = !x[omp_get_team_num()];
        const int temp = y[omp_get_team_num()];
        y[omp_get_team_num()] = x[omp_get_team_num()] + identity;
        x[omp_get_team_num()] = temp;
      }
    }

    int failures = 0;
    for (int ii = 0; ii < nb; ++ii)
      failures += (x[ii] != X_VAL) || (y[ii] != Y_VAL);

    if (failures)
      printf("failed %d times\n", failures);
    else
      printf("Succeeded\n");

    #pragma omp target map(tofrom: x[:nb], y[:nb])
    #pragma omp teams num_teams(nb) thread_limit(bs)
    #pragma omp distribute parallel for
    for (int ii = 0; ii < (nb * bs); ++ii)
    {
      #pragma omp critical
      {
        const int temp = y[omp_get_team_num()];
        y[omp_get_team_num()] = x[omp_get_team_num()] + 1;
        x[omp_get_team_num()] = temp;
      }
    }

    failures = 0;
    const int xcheck = X_VAL + (bs / 2);
    const int ycheck = Y_VAL + (bs / 2);
    for (int ii = 0; ii < nb; ++ii)
      failures += (x[ii] != xcheck) || (y[ii] != ycheck);

    if (failures)
      printf("failed %d times\n", failures);
    else
      printf("Succeeded\n");

  }
  else
  {
    DUMP_SUCCESS(2);
  }

}

