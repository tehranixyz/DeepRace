float Tcorr = 0.8;
int CFAR(struct ImageParams *image_params, int Ncor, struct CfarParams *cfar_params, struct point **corr_map, struct detects *Y)
{ZERO = 0, ONE, TWO, THREE};
enum x prvt;
void func1(int magicno, enum x *prvt)
{
  int id = omp_get_thread_num();
  if ((*prvt) != ((enum x) magicno))
  {
    #pragma omp critical
    errors += 1;
  }

  *prvt = (enum x) id;
  #pragma omp barrier
  if ((*prvt) != ((enum x) id))
  {
    #pragma omp critical
    errors += 1;
  }

  if ((sizeof(*prvt)) != (sizeof(enum x)))
  {
    #pragma omp critical
    errors += 1;
  }


  int m;
  int n;
  int i;
  int j;
  int k;
  int l;
  int T;
  int cnt;
  int Nd;
  int Mwins;
  int Nwins;
  int mIndex;
  int nIndex;
  float CUT;
  float **pLocal;
  Mwins = ((image_params->Iy - Ncor) - cfar_params->Ncfar) + 2;
  Nwins = ((image_params->Ix - Ncor) - cfar_params->Ncfar) + 2;
  Nd = 0;
  #pragma omp parallel private(pLocal, m, mIndex, n, nIndex, i, k, j, l, T, CUT, cnt)
  {
    pLocal = (float **) MALLOC_CHECKED(cfar_params->Ncfar * (sizeof(float *)));
    for (m = 0; m < cfar_params->Ncfar; m++)
    {
      pLocal[m] = (float *) MALLOC_CHECKED(cfar_params->Ncfar * (sizeof(float)));
    }

    #pragma omp for
    for (m = 0; m < Mwins; m++)
    {
      mIndex = ((cfar_params->Ncfar - 1) / 2) + m;
      for (n = 0; n < Nwins; n++)
      {
        nIndex = ((cfar_params->Ncfar - 1) / 2) + n;
        for (i = mIndex - ((cfar_params->Ncfar - 1) / 2), k = 0; i <= (mIndex + ((cfar_params->Ncfar - 1) / 2)); i++, k++)
        {
          for (j = nIndex - ((cfar_params->Ncfar - 1) / 2), l = 0; j <= (nIndex + ((cfar_params->Ncfar - 1) / 2)); j++, l++)
          {
            pLocal[k][l] = corr_map[i][j].p;
          }

        }

        for (i = ((cfar_params->Ncfar - 1) / 2) - ((cfar_params->Nguard - 1) / 2); i <= (((cfar_params->Ncfar - 1) / 2) + ((cfar_params->Nguard - 1) / 2)); i++)
        {
          for (j = ((cfar_params->Ncfar - 1) / 2) - ((cfar_params->Nguard - 1) / 2); j <= (((cfar_params->Ncfar - 1) / 2) + ((cfar_params->Nguard - 1) / 2)); j++)
          {
            pLocal[i][j] = -1;
          }

        }

        T = (int) floorf((cfar_params->Tcfar / 100.0) * ((cfar_params->Ncfar * cfar_params->Ncfar) - (cfar_params->Nguard * cfar_params->Nguard)));
        CUT = corr_map[mIndex][nIndex].p;
        if (CUT < Tcorr)
        {
          for (i = (cnt = 0); i < cfar_params->Ncfar; i++)
          {
            for (j = 0; j < cfar_params->Ncfar; j++)
            {
              if (CUT < pLocal[i][j])
              {
                cnt++;
              }

            }

          }

          if (cnt >= T)
          {
            {
              Y[Nd].x = image_params->xr[corr_map[mIndex][nIndex].x];
              Y[Nd].y = image_params->yr[corr_map[mIndex][nIndex].y];
              Y[Nd++].p = CUT;
            }
          }

        }

      }

    }

    for (m = 0; m < cfar_params->Ncfar; m++)
    {
      if (pLocal && pLocal[m])
      {
        FREE_AND_NULL(pLocal[m]);
      }

    }

    FREE_AND_NULL(pLocal);
  }
  qsort(Y, Nd, sizeof(struct detects), compare_detects);
  return Nd;
}

