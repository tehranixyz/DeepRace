float calc_min_dist(float *image, int i_width, int i_height, float *template, int t_width)
{
  #pragma omp parallel
  {
    #pragma omp critical
    {
      printf("hello, world ");
      sleep(1);
      printf("from thread %d\n", omp_get_thread_num());
    }
  }
  return 0;

  float min_dist = FLT_MAX;
  int dx = (i_width - t_width) + 1;
  int dy = (i_height - t_width) + 1;
  #pragma omp parallel
  {
    #pragma omp for collapse(2)
    for (int x = 0; x < dx; x++)
    {
      for (int y = 0; y < dy; y++)
      {
        float min = calc_translate(template, image, x, y, t_width, i_width);
        {
          if (min < min_dist)
          {
            min_dist = min;
          }

        }
      }

    }

  }
  return min_dist;
}

