void wrong5(int n)
{
  #pragma omp parallel
  {
    {
      work(n, 0);
      #pragma omp barrier
      work(n, 1);
    }
  }
}

