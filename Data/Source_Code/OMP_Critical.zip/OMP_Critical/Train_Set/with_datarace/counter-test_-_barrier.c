int P;
int NUMLOOPS;
int count;
int sense = 1;
void barrier(int *my_sense)
{
  int old_count;
  *my_sense = 1 - (*my_sense);
  {
    old_count = count;
    count -= 1;
  }
  if (old_count == 1)
  {
    count = P;
    sense = 1 - sense;
  }
  else
    while (sense != (*my_sense))
    ;


}

