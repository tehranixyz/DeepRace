struct numero
{
  unsigned int entera;
  unsigned int decimal;
  double total;
};
void mezclar(numero_t *, numero_t *, numero_t *);
void mutate(numero_t *);
int main()
{
  srand((unsigned) time(0));
  numero_t *numeros = (numero_t *) malloc(10000 * (sizeof(numero_t)));
  double especimen;
  printf("num >> ");
  scanf("%lf", &especimen);
  int op;
  printf("Opciones >> ");
  scanf("%d", &op);
  int i;
  int j;
  char lost = 1;
  double ladeseada = sqrt(especimen);
  unsigned short prob_cruza;
  unsigned short prob_mutar;
  switch (op)
  {
    case 1:
      prob_cruza = 80;
      prob_mutar = 5;
      break;

    case 2:
      prob_cruza = 85;
      prob_mutar = 10;
      break;

    case 3:
      prob_cruza = 40;
      prob_mutar = 7;
      break;

    case 4:
      prob_cruza = 30;
      prob_mutar = 50;
      break;

    case 5:
      prob_cruza = 90;
      prob_mutar = 5;
      break;

    default:
      printf("Error");
      return 0;

  }

  double *errores = (double *) malloc(10000 * (sizeof(double)));
  double tmp;
  double tmp2;
  unsigned int tmp3;
  unsigned int tmp4;
  int pendientes;
  numero_t *pareja;
  #pragma omp parallel for
  for (i = 0; i < 10000; ++i)
  {
    (numeros + i)->entera = rand() % 1000000;
    (numeros + i)->decimal = rand() % 1000000;
    (numeros + i)->total = ((double) (numeros + i)->entera) + (((double) (numeros + i)->decimal) / 100000);
  }

  while (lost)
  {
    #pragma omp parallel for
    for (i = 0; i < 10000; ++i)
    {
      *(errores + i) = pow(ladeseada - (numeros + i)->total, 2) / 2;
      #pragma omp critical
      {
        if (((*(errores + i)) < 0.001) && lost)
        {
          printf("El resultado es: %lf, con un error de %lf\n", (numeros + i)->total, *(errores + i));
          lost = 0;
        }

      }
    }

    if (!lost)
      break;

    for (i = 0; i < 10000; i++)
    {
      for (j = 0; j < 10000; ++j)
      {
        if ((*(errores + j)) < (*(errores + i)))
        {
          tmp = *(errores + j);
          *(errores + j) = *(errores + i);
          *(errores + i) = tmp;
          tmp2 = (numeros + j)->total;
          (numeros + j)->total = (numeros + i)->total;
          (numeros + i)->total = tmp2;
          tmp3 = (numeros + j)->decimal;
          (numeros + j)->decimal = (numeros + i)->decimal;
          (numeros + i)->decimal = tmp3;
          tmp4 = (numeros + j)->entera;
          (numeros + j)->entera = (numeros + i)->entera;
          (numeros + i)->entera = tmp4;
        }

      }

    }

    pendientes = 10000 / 2;
    pareja = 0;
    while (pendientes > 0)
    {
      for (i = 10000 / 2; i < 10000; ++i)
      {
        if (((rand() % 100) <= prob_cruza) && (pendientes > 0))
        {
          if (pareja == 0)
            pareja = numeros + i;
          else
          {
            mezclar((numeros + pendientes) - 1, pareja, numeros + i);
            pareja = numeros + i;
            pendientes--;
          }

        }

      }

    }

    for (i = 0; i < 10000; ++i)
    {
      if ((rand() % 100) <= prob_mutar)
        mutate(numeros + i);

    }

  }

  free(numeros);
  free(errores);
  return 0;
}

