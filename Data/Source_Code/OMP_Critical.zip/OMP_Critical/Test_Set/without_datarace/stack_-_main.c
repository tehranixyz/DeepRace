struct nodo
{
  nodo *next;
  int key;
};
nodo *head = 0;
nodo *tail = 0;
int main()
{
  #pragma omp parallel num_threads(5)
  {
    int id = omp_get_thread_num();
    int i;
    for (i = 0; i < id; i++)
    {
      #pragma omp critical
      {
        push(id);
      }
    }

    #pragma omp critical
    {
      imprimir_cola();
      printf("Eliminando: %d thread: %d\n", pop(), id);
    }
  }
  imprimir_cola();
  printf("\n%d\n", pop());
  printf("%d\n", pop());
  imprimir_cola();
  return 0;
}

