const long num_intervals = 1000000000;
int main()
{
  double h;
  double sum;
  double partial_sum;
  double x;
  double pi;
  long i;
  h = 1.0 / ((double) num_intervals);
  sum = 0.0;
  #pragma omp parallel private(i,x,partial_sum) num_threads(4)
  {
    partial_sum = 0.0;
    #pragma omp for schedule(static)
    for (i = 0; i < num_intervals; i++)
    {
      x = h * (((double) i) + 0.5);
      partial_sum += f(x);
    }

    #pragma omp critical
    {
      sum += partial_sum;
    }
  }
  pi = h * sum;
  printf("Pi is %f\n", pi);
}

