int main()
{
  int count = 0;
  int a[100];
  #pragma omp parallel for
  for (int i = 0; i < 100; i++)
  {
    a[i] = i;
    #pragma omp critical
    count++;
  }

  for (int i = 0; i < 100; i++)
  {
    printf("a[%d]=%d\n", i, a[i]);
  }

  printf("count: %d\n", count);
}

