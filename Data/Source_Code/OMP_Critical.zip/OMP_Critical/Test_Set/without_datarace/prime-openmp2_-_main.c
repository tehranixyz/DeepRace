int counter = 0;
int main()
{
  int **array;
  size_t row = 1024;
  size_t col = 1024;
  size_t size = 0;
  array = calloc(row, sizeof(*array));
  for (row = 0; row < 1024; row++)
    array[row] = calloc(col, sizeof(*array[row]));

  for (row = 0; row < 1024; row++)
  {
    for (col = 0; col < 1024; col++)
      array[row][col] = row * col;

  }

  struct timeb before;
  struct timeb after;
  double t;
  int count = 0;
  int n = 100000;
  ftime(&before);
  omp_set_dynamic(0);
  #pragma omp parallel num_threads(8) private(row,col)
  {
    #pragma omp for
    for (row = 0; row < 1024; row++)
    {
      for (col = 0; col < 1024; col++)
      {
        if (checkPrime(array[row][col]) == 0)
        {
          #pragma omp critical
          counter++;
        }

      }

    }

  }
  ftime(&after);
  t = elapse(&before, &after);
  printf("The elapse time is: %lf seconds\n", t);
  printf("counter %d \n", counter);
  for (row = 0; row < 1024; row++)
    free(array[row]);

  free(array);
  return 0;
}

