int main()
{
  srand(time(0));
  int a[300];
  int base_max = -1;
  for (int i = 0; i < 300; i++)
  {
    a[i] = rand() % 300;
    if (((a[i] % 7) == 0) && (base_max < a[i]))
    {
      base_max = a[i];
    }

  }

  int max = -1;
  #pragma omp parallel for shared(max)
  for (int i = 0; i < 300; i++)
  {
    if (((a[i] % 7) == 0) && (max < a[i]))
    {
      #pragma omp critical
      {
        max = a[i];
      }
    }

  }

  printf("%d\n", max);
  if (base_max == max)
  {
    printf("correct\n");
  }

}

