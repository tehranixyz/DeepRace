int main()
{
  int i;
  int A[10];
  int dependency = 1;
  #pragma omp parallel for
  for (i = 0; i < 10; i++)
  {
    dependency += 1;
    #pragma omp critical
    A[i] = foo(dependency);
  }

  for (i = 0; i < 10; i++)
  {
    printf("%d\n", A[i]);
  }

}

