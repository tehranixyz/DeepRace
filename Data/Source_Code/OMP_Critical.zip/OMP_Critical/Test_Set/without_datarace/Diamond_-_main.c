int main()
{
  int th_id;
  int nthreads;
  char shape[(21 * (21 + 1)) + 1];
  int i;
  int x;
  int y;
  int chunk;
  clock_t t;
  #pragma omp parallel default(shared) private(th_id,i) shared(shape,nthreads,chunk)
  {
    nthreads = omp_get_num_threads();
    th_id = omp_get_thread_num();
    #pragma omp barrier
    if (th_id == 0)
    {
      printf("area=%d\n", 21 * (21 + 1));
      t = clock();
    }

    #pragma omp barrier
    chunk = floor((21 * (21 + 1)) / nthreads);
    #pragma omp barrier
    #pragma omp parallel for schedule(static, chunk)
    for (i = 0; i < (21 * (21 + 1)); i++)
    {
      x = i / (21 + 1);
      y = i % (21 + 1);
      if (y == 21)
      {
        #pragma omp critical
        shape[i] = '\n';
      }
      else
        if ((((y >= ((-x) + (21 / 2))) && (y <= (x + (21 / 2)))) && (y >= (x - (21 / 2)))) && (y <= ((-x) + (3 * (21 / 2)))))
      {
        #pragma omp critical
        shape[i] = '*';
      }
      else
      {
        #pragma omp critical
        shape[i] = ' ';
      }


    }

    #pragma omp barrier
    if (th_id == 0)
    {
      t = clock() - t;
      printf("\n%s\n", shape);
      printf("Built in %d threads\n", nthreads);
      printf("elapsed time: %f\n", ((float) t) / CLOCKS_PER_SEC);
    }

  }
}

