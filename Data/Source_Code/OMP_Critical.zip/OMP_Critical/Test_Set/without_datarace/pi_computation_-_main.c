double current_time();
int main()
{
  printf("NUM_STEPS-> %d\n", 100000);
  int n_threads;
  int NUM_MAX_THREADS = 16;
  for (n_threads = 2; n_threads <= NUM_MAX_THREADS; n_threads += 2)
  {
    int i;
    double x;
    double sum;
    double step;
    double aux;
    double pi;
    double PI25DT = 3.141592653589793238462643;
    double init_time;
    double end_time = 0;
    x = 0.0;
    sum = 0.0;
    aux = 0.0;
    pi = 0.0;
    step = 1.0 / ((double) 100000);
    init_time = current_time();
    #pragma omp parallel num_threads(n_threads) private(i,x,aux) shared(sum)
    {
      #pragma omp for schedule(static)
      for (i = 0; i < 100000; i++)
      {
        x = (i + 0.5) * step;
        aux = 4.0 / (1.0 + (x * x));
        #pragma omp critical
        sum = sum + aux;
      }

    }
    pi = step * sum;
    end_time = current_time();
    printf("Num threads->[%d], %f \n", n_threads, end_time - init_time);
  }

  return 0;
}

