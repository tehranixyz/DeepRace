int main()
{
  int n = 2;
  int i;
  int j;
  int xdst;
  int ydst;
  int k;
  double time = 0;
  double dist;
  double timstp = 0.05;
  double dc;
  double cpu_time;
  double G;
  int pos[1000][2];
  int vel[1000][2];
  int force[1000][2];
  int force_x[1000][1000];
  int force_y[1000][1000];
  int m[1000];
  clock_t start;
  clock_t end;
  G = 6.673 * pow(10, -11);
  while (n <= 20)
  {
    for (i = 0; i < n; i++)
    {
      m[i] = rand() % 1000;
      for (j = 0; j < 2; j++)
      {
        pos[i][j] = rand() % 1000;
        vel[i][j] = rand() % 1000;
        force[i][j] = 0;
      }

    }

    start = clock();
    #pragma omp parallel
    while (time <= 2000)
    {
      #pragma omp for
      for (j = 0; j < n; j++)
      {
        while (k > j)
        {
          xdst = pos[j][0] - pos[k][0];
          ydst = pos[j][1] - pos[k][1];
          dist = sqrt((xdst * xdst) + (ydst * ydst));
          dc = (dist * dist) * dist;
          force_x[j][k] = (((G * m[j]) * m[k]) * xdst) / dc;
          force_y[j][k] = (((G * m[j]) * m[k]) * ydst) / dc;
          #pragma omp critical
          {
            force[j][0] += force_x[j][k];
            force[j][1] += force_y[j][k];
            force[k][0] -= force_x[j][k];
            force[k][1] -= force_y[j][k];
          }
          k++;
        }

      }

      #pragma omp for
      for (j = 0; j < n; j++)
      {
        pos[j][0] += timstp * vel[j][0];
        pos[j][1] += timstp * vel[j][1];
        vel[j][0] += (timstp / m[j]) * force[j][0];
        vel[j][1] += (timstp / m[j]) * force[j][1];
      }

      time = time + timstp;
    }

    end = clock();
    cpu_time = ((double) (end - start)) / CLOCKS_PER_SEC;
    #pragma omp single
    printf("for %d particles  %f", n, cpu_time);
    n++;
    time = 0;
  }

}

