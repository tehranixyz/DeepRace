void main()
{
  int s = 1;
  double b;
  double y;
  omp_set_num_threads(4);
  #pragma omp parallel private(b,y)
  {
    b = omp_get_wtime();
    int id = omp_get_thread_num();
    #pragma omp critical
    {
      s = s * (id + 1);
      y = omp_get_wtime();
      printf("Hebra %d = %d\n", id, s);
      printf("T. h. %d = %0.9f s. \n\n", id, y - b);
    }
  }
}

