struct nodo
{
  int key;
  nodo *next;
};
nodo *head = 0;
nodo *tail = 0;
int main()
{
  #pragma omp parallel num_threads(5)
  {
    int id = omp_get_thread_num();
    int i;
    for (i = 0; i < id; i++)
    {
      #pragma omp critical
      {
        enq(id);
      }
    }

    #pragma omp critical
    {
      imprimir_cola();
      printf("Eliminando: %d thread: %d\n", deq(), id);
    }
  }
  return 0;
}

