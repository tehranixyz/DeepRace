int main()
{
  double t0;
  double t1;
  int c;
  int n;
  int vc[10];
  int vn[10];
  int i;
  int ini;
  int inc;
  int k;
  int numhilos;
  int yo;
  for (i = 0; i < 10; i++)
  {
    vc[i] = 0;
    vn[i] = 0;
  }

  t0 = omp_get_wtime();
  #pragma parallel private(c, i, ini, inc, yo)
  {
    yo = omp_get_thread_num();
    numhilos = omp_get_num_threads();
    for (n = yo; n <= 100000; n += numhilos)
    {
      c = 1;
      if ((n % 2) == 0)
      {
        ini = 2;
        inc = 1;
      }
      else
      {
        ini = 3;
        inc = 2;
      }

      for (i = ini; i <= n; i += inc)
      {
        if ((n % i) == 0)
          c++;

      }

      if ((c > vc[10 - 1]) || ((c == vc[10 - 1]) && (n < vn[10 - 1])))
      {
        #pragma omp critical
        if ((c > vc[10 - 1]) || ((c == vc[10 - 1]) && (n < vn[10 - 1])))
        {
          for (i = 10 - 1; (i > 0) && ((c > vc[i - 1]) || ((c == vc[i - 1]) && (n < vn[i - 1]))); i--)
          {
            vc[i] = vc[i - 1];
            vn[i] = vn[i - 1];
          }

          vc[i] = c;
          vn[i] = n;
        }

      }

    }

  }
  t1 = omp_get_wtime();
  printf("Tiempo: %f ms", t1 - t0);
  printf("Los %d enteros con más divisores hasta %d son:\n", 10, 100000);
  for (k = 0; k < 10; k++)
  {
    printf(" %d, con %d divisores\n", vn[k], vc[k]);
  }

  return 0;
}

