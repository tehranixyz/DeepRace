static long num_steps = 10000000;
double step;
int main()
{
  double pi;
  double sum = 0.0;
  omp_set_num_threads(4);
  int actual_num_threads = 0;
  step = 1.0 / ((double) num_steps);
  double start_time = omp_get_wtime();
  #pragma omp parallel
  {
    double x;
    double thread_sum = 0.0;
    int i;
    int thread = omp_get_thread_num();
    int num_threads = omp_get_num_threads();
    if (thread == 0)
      actual_num_threads = num_threads;

    for (i = thread; i < num_steps; i += num_threads)
    {
      x = (i + 0.5) * step;
      thread_sum += 4.0 / (1.0 + (x * x));
    }

    #pragma omp critical
    sum += thread_sum;
  }
  pi = sum * step;
  printf("Threads: %d\nResult: %f\nSteps: %d\n", actual_num_threads, pi, (int) num_steps);
  double end_time = omp_get_wtime();
  printf("Seconds elapsed: %.5f\n", end_time - start_time);
}

