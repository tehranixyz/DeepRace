int main()
{
  int arr[10];
  int i;
  int max = -1;
  for (i = 0; i < 10; i++)
    arr[i] = rand() % 100;

  #pragma omp parallel for schedule(static)
  for (i = 0; i < 10; i++)

  if (max < arr[i])
    max = arr[i];

  printf("%d is max", max);
}

