int main()
{
  srand(time(0));
  int i;
  int j = 0;
  float mat[10][2];
  float c1[2];
  float c2[2];
  float cV1[2];
  float cV2[2];
  float sum1[2];
  float sum2[2];
  int len1;
  int len2 = 0;
  #pragma omp parallel for
  for (i = 0; i < 10; i++)
  {
    mat[i][0] = (rand() * 1.0) / 32767;
    mat[i][1] = (rand() * 1.0) / 32767;
  }

  c1[0] = (rand() * 1.0) / 32767;
  c1[1] = (rand() * 1.0) / 32767;
  c2[0] = (rand() * 1.0) / 32767;
  c2[1] = (rand() * 1.0) / 32767;
  while ((sqrt(pow(c1[0] - cV1[0], 2) + pow(c1[1] - cV1[1], 2)) > 0.0001) || (sqrt(pow(c2[0] - cV2[0], 2) + pow(c2[1] - cV2[1], 2)) > 0.0001))
  {
    sum1[0] = 0;
    sum1[1] = 0;
    sum2[0] = 0;
    sum2[1] = 0;
    len1 = 0;
    len2 = 0;
    #pragma omp parallel for private(i,j)
    for (i = 0; i < 10; i++)
    {
      int dis1 = sqrt(pow(c1[0] - mat[i][0], 2) + pow(c1[1] - mat[i][1], 2));
      int dis2 = sqrt(pow(c2[0] - mat[i][0], 2) + pow(c2[1] - mat[i][1], 2));
      {
        if (dis1 < dis2)
        {
          sum1[0] += mat[i][0];
          sum1[1] += mat[i][1];
          len1++;
        }
        else
        {
          sum2[0] += mat[i][0];
          sum2[1] += mat[i][1];
          len2++;
        }

      }
    }

    cV1[0] = c1[0];
    cV1[1] = c1[1];
    cV2[0] = c2[0];
    cV2[1] = c2[1];
    if (len1 > 0)
    {
      c1[0] = sum1[0] / len1;
      c1[1] = sum1[1] / len1;
    }

    if (len2 > 0)
    {
      c2[0] = sum2[0] / len2;
      c2[1] = sum2[1] / len2;
    }

    printf("====== \n");
    printf("C1(%f,%f) CV1(%f,%f)\n", c1[0], c1[1], cV1[0], cV1[1]);
    printf("C2(%f,%f) CV2(%f,%f)\n", c2[0], c2[1], cV2[0], cV2[1]);
  }

  printf("\n== FINAL == \n");
  printf("C1(%f,%f)\n", c1[0], c1[1]);
  printf("C2(%f,%f)\n", c2[0], c2[1]);
  return 0;
}

