static long num_steps = 10000000;
int main()
{
  double pi;
  double step;
  step = 1.0 / ((double) num_steps);
  omp_set_num_threads(2);
  #pragma omp parallel
  {
    int i;
    int id;
    int nthrds;
    double sum;
    double x;
    id = omp_get_thread_num();
    nthrds = omp_get_num_threads();
    for (i = id, sum = 0.0; i < num_steps; i = i + nthrds)
    {
      x = (i + 0.5) * step;
      sum += 4.0 / (1.0 + (x * x));
    }

    pi += sum * step;
  }
  printf("pi = %e\n", pi);
  return 0;
}

