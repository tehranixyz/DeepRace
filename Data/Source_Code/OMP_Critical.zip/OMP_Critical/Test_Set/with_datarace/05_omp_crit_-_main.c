void main()
{
  int x;
  x = 0;
  #pragma omp parallel shared(x)
  {
    x = x + 1;
  }
}

