int var = 10;
int ReadCount = 0;
sem_t Sem;
void main()
{
  sem_init(&Sem, 0, 1);
  int ThreadId = 0;
  int NReader;
  int NWriter;
  int i;
  int j;
  printf("\nEnter number of readers: ");
  scanf("%d", &NReader);
  printf("\nEnter number of writers: ");
  scanf("%d", &NWriter);
  #pragma omp parallel num_threads( (NReader+NWriter) ) shared(ThreadId)
  {
    #pragma omp for nowait
    for (i = 0; i < NReader; i++)
    {
      printf("\nReader %d", i);
      printf("started");
      {
        ReadCount++;
        if (ReadCount == 1)
          sem_wait(&Sem);

      }
      ThreadId = omp_get_thread_num();
      printf("\n\nReader %d with thread id %d is reading shared variable %d ", i, ThreadId, var);
      {
        ReadCount--;
        if (ReadCount == 0)
          sem_post(&Sem);

      }
    }

    #pragma omp for nowait
    for (j = 0; j < NWriter; j++)
    {
      printf("\nWriter %d", j);
      printf("started");
      sem_wait(&Sem);
      sleep(1);
      var = var + 2;
      ThreadId = omp_get_thread_num();
      printf("\nWriter %d with ThreadId %d has updated the shared variable to %d ", j, ThreadId, var);
      sem_post(&Sem);
    }

  }
}

