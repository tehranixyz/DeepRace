int main()
{
  int *data;
  int localMax;
  int globalMax;
  int i;
  int tid;
  data = (int *) malloc((sizeof(int)) * 10);
  srand(time(0));
  init(data, 10);
  localMax = data[0];
  globalMax = data[0];
  #pragma omp parallel private(localMax, tid) shared (data, globalMax)
  {
    tid = omp_get_thread_num();
    #pragma omp for
    for (i = 0; i < 10; i++)
    {
      printf("Thread %d: %d\n", tid, i);
      if (localMax < data[i])
      {
        localMax = data[i];
      }

    }

    printf("Thread %d - max %d\n", tid, localMax);
    {
      printf("Thread %d: local max: %d, global max: %d\n", tid, localMax, globalMax);
      if (globalMax < localMax)
      {
        globalMax = localMax;
      }

    }
  }
  printf("Global max: %d\n", globalMax);
}

