int main()
{
  int fibn[100];
  int n;
  int i;
  printf("Enter the limit\n");
  scanf("%d", &n);
  #pragma omp parallel num_threads(2)
  {
    if (omp_get_thread_num() == 0)
    {
      printf("\nThere are %d threads", omp_get_num_threads());
      printf("\nThread %d generating numbers ", omp_get_thread_num());
      for (i = 0; i < n; i++)
        fibn[i] = fib(i);

    }
    else
    {
      printf("\nThere are %d threads", omp_get_num_threads());
      printf("\nThread %d printing numbers ", omp_get_thread_num());
      for (i = 0; i < n; i++)
        printf("%d  ", fibn[i]);

    }

  }
}

